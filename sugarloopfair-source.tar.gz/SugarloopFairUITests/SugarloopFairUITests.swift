import XCTest

/// UI flows run with `--uitesting` (in-memory store, 100,000 coins) and `--fast` animations.
final class SugarloopFairUITests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    // MARK: Helpers

    @discardableResult
    private func launch(_ extra: [String] = [], fast: Bool = true, seed: Int = 7) -> XCUIApplication {
        app = XCUIApplication()
        app.launchArguments = ["--uitesting", "--seed=\(seed)"] + (fast ? ["--fast"] : []) + extra
        app.launch()
        return app
    }

    private func element(_ id: String) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: id).firstMatch
    }

    private func digits(_ text: String?) -> Int {
        Int((text ?? "").filter(\.isNumber)) ?? -1
    }

    private func balance(_ id: String = "balance") -> Int {
        digits(element(id).value as? String)
    }

    private func tapScrolling(_ id: String, file: StaticString = #filePath, line: UInt = #line) {
        let target = element(id)
        XCTAssertTrue(target.waitForExistence(timeout: 8), "Missing \(id)", file: file, line: line)
        var attempts = 0
        while !target.isHittable && attempts < 6 {
            app.swipeUp()
            attempts += 1
        }
        target.tap()
    }

    private func waitState(_ value: String, timeout: TimeInterval = 40, file: StaticString = #filePath, line: UInt = #line) {
        let exp = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value == %@", value), object: element("game_state"))
        XCTAssertEqual(XCTWaiter().wait(for: [exp], timeout: timeout), .completed, "Game never reached \(value)", file: file, line: line)
    }

    private func waitReady(timeout: TimeInterval = 40, file: StaticString = #filePath, line: UInt = #line) {
        waitState("Ready", timeout: timeout, file: file, line: line)
    }

    private func movesLeft() -> Int { digits(element("moves_status").value as? String) }

    private func boardSymbols() -> [String]? {
        let cells = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "candy_cell_")).allElementsBoundByIndex
        guard cells.count == 30 else { return nil }
        let ordered = cells.sorted {
            (Int($0.identifier.replacingOccurrences(of: "candy_cell_", with: "")) ?? 0)
                < (Int($1.identifier.replacingOccurrences(of: "candy_cell_", with: "")) ?? 0)
        }
        return ordered.map { String($0.label.split(separator: ",", maxSplits: 1).first ?? "") }
    }

    private static let specials = ["Lollipop", "Sprinkle Bomb"]

    /// Mirrors the game's rule: a swap is valid if it makes a connected 3+ group or moves a lollipop onto a candy.
    private func isValidSwap(_ symbols: [String], _ first: Int, _ second: Int) -> Bool {
        let a = symbols[first], b = symbols[second]
        if (a == "Lollipop" && !Self.specials.contains(b)) || (b == "Lollipop" && !Self.specials.contains(a)) { return true }
        var board = symbols
        board.swapAt(first, second)
        var visited = Set<Int>()
        for start in 0..<30 where !visited.contains(start) && !Self.specials.contains(board[start]) {
            var queue = [start]
            var group = Set([start])
            visited.insert(start)
            while let current = queue.popLast() {
                let row = current / 6, col = current % 6
                var neighbors: [Int] = []
                if col > 0 { neighbors.append(current - 1) }
                if col < 5 { neighbors.append(current + 1) }
                if row > 0 { neighbors.append(current - 6) }
                if row < 4 { neighbors.append(current + 6) }
                for next in neighbors where !visited.contains(next) && board[next] == board[start] {
                    visited.insert(next)
                    group.insert(next)
                    queue.append(next)
                }
            }
            if group.count >= 3 && (group.contains(first) || group.contains(second)) { return true }
        }
        return false
    }

    private func findSwap(valid: Bool) -> (Int, Int)? {
        guard let symbols = boardSymbols() else { return nil }
        for first in 0..<30 {
            let row = first / 6, col = first % 6
            let neighbors = [col < 5 ? first + 1 : -1, row < 4 ? first + 6 : -1].filter { $0 >= 0 }
            for second in neighbors where isValidSwap(symbols, first, second) == valid {
                return (first, second)
            }
        }
        return nil
    }

    /// Tap one candy, then its neighbour: the move plays immediately.
    private func playValidMove(file: StaticString = #filePath, line: UInt = #line) {
        guard let (first, second) = findSwap(valid: true) else {
            XCTFail("No valid candy swap found on the visible board", file: file, line: line)
            return
        }
        element("candy_cell_\(first)").tap()
        element("candy_cell_\(second)").tap()
        let exp = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value != %@", "Ready"), object: element("game_state"))
        _ = XCTWaiter().wait(for: [exp], timeout: 2)
        waitSettled(file: file, line: line)
    }

    /// Waits until the move has finished and any receipt or big-win overlay is out of the way.
    private func waitSettled(file: StaticString = #filePath, line: UInt = #line) {
        let deadline = Date().addingTimeInterval(40)
        while Date() < deadline {
            dismissReceiptIfShown()
            let value = element("game_state").value as? String
            if value == "Ready" || value == "Round complete" || value == "Done" { return }
            usleep(200_000)
        }
        XCTFail("Move never settled", file: file, line: line)
    }

    private func dismissReceiptIfShown() {
        let close = element("receipt_close")
        if close.waitForExistence(timeout: 0.5) {
            close.tap()
            XCTAssertTrue(waitGone(element("receipt")))
        }
    }

    private func waitGone(_ e: XCUIElement, timeout: TimeInterval = 5) -> Bool {
        let exp = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: e)
        return XCTWaiter().wait(for: [exp], timeout: timeout) == .completed
    }

    private func openGame() {
        tapScrolling("stall_play")
        XCTAssertTrue(element("game_screen").waitForExistence(timeout: 8))
    }

    private func closeSheet() {
        element("sheet_close").tap()
    }

    // MARK: Alley

    func testAlleyShowsBalanceAndEveryStall() {
        launch()
        XCTAssertTrue(element("alley").waitForExistence(timeout: 8))
        XCTAssertEqual(balance(), 100_000)
        for id in ["stall_play", "stall_bakeoff", "stall_jars", "stall_booths", "stall_tickets", "stall_howto", "stall_settings"] {
            XCTAssertTrue(element(id).exists, "Missing stall \(id)")
        }
    }

    func testEverySheetOpensAndCloses() {
        launch()
        let pairs = [("stall_bakeoff", "bakeoff_sheet"), ("stall_jars", "jars_sheet"), ("stall_booths", "booths_sheet"), ("stall_tickets", "tickets_sheet"),
                     ("stall_howto", "howto_sheet"), ("stall_settings", "settings_sheet")]
        for (stall, sheet) in pairs {
            tapScrolling(stall)
            XCTAssertTrue(element(sheet).waitForExistence(timeout: 6), "\(sheet) did not open")
            closeSheet()
            XCTAssertTrue(waitGone(element(sheet)), "\(sheet) did not close")
        }
    }

    func testWelcomeAppearsOnFirstLaunchAndDismisses() {
        launch(["--show-welcome"])
        let start = element("welcome_start")
        XCTAssertTrue(start.waitForExistence(timeout: 8))
        start.tap()
        XCTAssertTrue(element("alley").waitForExistence(timeout: 6))
        XCTAssertTrue(waitGone(start))
    }

    // MARK: Jars, booths, settings

    func testJarClaimAddsCoinsOnceThenWaits() {
        launch()
        tapScrolling("stall_jars")
        XCTAssertTrue(element("jars_sheet").waitForExistence(timeout: 6))
        let before = balance("jars_balance")
        element("jar_small").tap()
        XCTAssertTrue(element("jars_message").waitForExistence(timeout: 4))
        XCTAssertEqual(balance("jars_balance"), before + 400)
        XCTAssertFalse(element("jar_small").isEnabled, "A claimed jar must wait for its timer")
        closeSheet()
        XCTAssertEqual(balance(), before + 400)
    }

    func testBoothUnlockedByMovesCanBeSelected() {
        launch(["--spins=300"])
        tapScrolling("stall_booths")
        XCTAssertTrue(element("booths_sheet").waitForExistence(timeout: 6))
        element("booth_berry").tap()
        XCTAssertFalse(element("booth_berry").isEnabled, "The selected booth is shown as selected")
        XCTAssertTrue(element("booth_honey").isEnabled)
    }

    func testLockedBoothExplainsWhy() {
        launch()
        tapScrolling("stall_booths")
        XCTAssertTrue(element("booths_sheet").waitForExistence(timeout: 6))
        element("booth_mint").tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "Play 60 more moves")).firstMatch.waitForExistence(timeout: 4))
    }

    func testResetProgressRestoresStartingCoins() {
        launch()
        tapScrolling("stall_jars")
        XCTAssertTrue(element("jars_sheet").waitForExistence(timeout: 6))
        element("jar_small").tap()
        closeSheet()
        XCTAssertEqual(balance(), 100_400)

        tapScrolling("stall_settings")
        XCTAssertTrue(element("settings_sheet").waitForExistence(timeout: 6))
        element("reset_progress").tap()
        let confirm = app.buttons["Reset everything"].firstMatch
        XCTAssertTrue(confirm.waitForExistence(timeout: 4))
        confirm.tap()
        closeSheet()
        XCTAssertEqual(balance(), 10_000)
    }

    func testSettingsTogglesFlip() {
        launch()
        tapScrolling("stall_settings")
        XCTAssertTrue(element("settings_sheet").waitForExistence(timeout: 6))
        let toggle = app.switches["haptics_toggle"].exists ? app.switches["haptics_toggle"] : element("haptics_toggle")
        let before = toggle.value as? String
        toggle.tap()
        XCTAssertNotEqual(toggle.value as? String, before)
    }

    // MARK: Game

    func testGameOpensAndBackReturnsToTheAlley() {
        launch()
        openGame()
        waitReady()
        XCTAssertEqual(movesLeft(), 20)
        XCTAssertTrue(element("candy_cell_0").exists)
        XCTAssertTrue(element("order_card_0").exists && element("order_card_2").exists, "Three fair-goer orders are shown")
        element("game_close").tap()
        XCTAssertTrue(element("alley").waitForExistence(timeout: 6))
    }

    func testBetStepperChangesTheBet() {
        launch()
        openGame()
        let start = digits(element("bet_value").value as? String)
        element("bet_plus").tap()
        XCTAssertGreaterThan(digits(element("bet_value").value as? String), start)
        element("bet_minus").tap()
        element("bet_minus").tap()
        XCTAssertLessThan(digits(element("bet_value").value as? String), start)
    }

    func testTappingTwoNeighboursPlaysTheMove() {
        launch()
        openGame()
        let before = balance("game_balance")
        playValidMove()
        XCTAssertEqual(movesLeft(), 19)
        XCTAssertNotEqual(balance("game_balance"), before, "The move cost and its score settle at once")
    }

    func testSwipePlaysTheMove() {
        launch()
        openGame()
        guard let (first, second) = findSwap(valid: true) else { XCTFail("No valid swap found"); return }
        let from = element("candy_cell_\(first)"), to = element("candy_cell_\(second)")
        from.press(forDuration: 0.05, thenDragTo: to)
        waitSettled()
        XCTAssertEqual(movesLeft(), 19)
    }

    func testSeveralMovesStayConsistent() {
        launch()
        openGame()
        for _ in 0..<4 { playValidMove() }
        XCTAssertEqual(movesLeft(), 16)
        XCTAssertGreaterThan(balance("game_balance"), 0)
    }

    func testWithoutInputTheBoardStateDoesNotChange() {
        launch()
        openGame()
        waitReady()
        let before = balance("game_balance")
        let symbols = boardSymbols()
        sleep(2)
        XCTAssertEqual(balance("game_balance"), before)
        XCTAssertEqual(boardSymbols(), symbols)
        XCTAssertEqual(movesLeft(), 20)
    }

    func testInvalidSwapSlidesBackForFree() {
        launch()
        openGame()
        waitReady()
        let before = balance("game_balance")
        guard let (first, second) = findSwap(valid: false) else { XCTFail("No invalid swap found"); return }
        element("candy_cell_\(first)").tap()
        element("candy_cell_\(second)").tap()
        waitReady()
        XCTAssertEqual(movesLeft(), 20)
        XCTAssertEqual(balance("game_balance"), before)
    }

    func testBrokePlayerGetsARescueInsteadOfAnError() {
        launch(["--coins=5"])
        openGame()
        guard let (first, second) = findSwap(valid: true) else { XCTFail("No valid swap found"); return }
        element("candy_cell_\(first)").tap()
        element("candy_cell_\(second)").tap()
        waitSettled()
        XCTAssertGreaterThan(balance("game_balance"), 0)
    }

    func testMoveCostTooHighForBalanceShowsAHint() {
        launch(["--coins=60"])
        openGame()
        element("bet_plus").tap()
        element("bet_plus").tap()
        guard let (first, second) = findSwap(valid: true) else { XCTFail("No valid swap found"); return }
        element("candy_cell_\(first)").tap()
        element("candy_cell_\(second)").tap()
        XCTAssertTrue(element("toast").waitForExistence(timeout: 4))
        XCTAssertTrue(element("toast").label.contains("Not enough"))
        XCTAssertEqual(movesLeft(), 20)
    }

    func testCannonBlastsAColumnForFree() {
        launch(["--cannon-ready"])
        openGame()
        waitReady()
        let before = balance("game_balance")
        XCTAssertEqual(element("cannon_button").value as? String, "Ready")
        element("cannon_button").tap()
        XCTAssertEqual(element("cannon_button").value as? String, "Loaded")
        element("candy_cell_8").tap()
        waitSettled()
        XCTAssertEqual(movesLeft(), 20, "The cannon does not use a move")
        XCTAssertGreaterThanOrEqual(balance("game_balance"), before, "The cannon is free and its blast scores")
        XCTAssertNotEqual(element("cannon_button").value as? String, "Ready")
    }

    func testSugarRushGivesFreeMoves() {
        launch(["--meter-full"])
        openGame()
        waitReady()
        element("meter_button").tap()
        XCTAssertTrue(element("rush_badge").waitForExistence(timeout: 3))
        let before = balance("game_balance")
        playValidMove()
        XCTAssertGreaterThanOrEqual(balance("game_balance"), before, "Rush moves cost nothing")
        XCTAssertTrue(element("rush_badge").label.contains("2 free"))
    }

    func testFullRoundEndsWithASummaryAndANewRound() {
        launch()
        openGame()
        for _ in 0..<20 { playValidMove() }
        XCTAssertTrue(element("round_summary").waitForExistence(timeout: 10))
        XCTAssertTrue(element("summary_new_best").exists, "The first round is always a personal best")
        element("round_next").tap()
        XCTAssertTrue(waitGone(element("round_summary")))
        waitReady()
        XCTAssertEqual(movesLeft(), 20)
    }

    // MARK: Bake-Off, rank and fair card

    func testDailyBakeOffPlaysFifteenFreeMovesAndRecordsTheScore() {
        launch()
        let before = balance()
        tapScrolling("stall_bakeoff")
        XCTAssertTrue(element("bakeoff_sheet").waitForExistence(timeout: 6))
        element("bakeoff_start").tap()
        XCTAssertTrue(element("game_screen").waitForExistence(timeout: 8))
        XCTAssertTrue(element("bakeoff_day").exists)
        XCTAssertEqual(movesLeft(), 15)
        for _ in 0..<15 { playValidMove() }
        XCTAssertTrue(element("round_summary").waitForExistence(timeout: 10))
        XCTAssertGreaterThan(digits(element("summary_score").label), 0)
        element("round_exit").tap()
        XCTAssertTrue(element("alley").waitForExistence(timeout: 6))
        XCTAssertEqual(balance(), before, "The Bake-Off never touches coins")
        XCTAssertTrue(element("stall_bakeoff").label.contains("Bake-Off"))
    }

    func testRankBadgeAndFairCardShowLeaderboardNumbers() {
        launch(["--points=500"])
        XCTAssertTrue(element("rank_badge").waitForExistence(timeout: 6))
        XCTAssertEqual(element("rank_badge").label, "Fair rank: Lollipop Lieutenant")
        tapScrolling("stall_tickets")
        XCTAssertTrue(element("fair_card").waitForExistence(timeout: 6))
        XCTAssertTrue(app.staticTexts["Sugar Points"].exists)
        XCTAssertTrue(app.staticTexts["Best 20-move round"].exists)
    }

    func testFairNameIsEditableAndShownOnTheCard() {
        launch()
        tapScrolling("stall_settings")
        XCTAssertTrue(element("settings_sheet").waitForExistence(timeout: 6))
        let field = app.textFields["player_name"]
        XCTAssertTrue(field.waitForExistence(timeout: 4))
        field.tap()
        field.press(forDuration: 1.0)
        if app.menuItems["Select All"].waitForExistence(timeout: 2) { app.menuItems["Select All"].tap() }
        field.typeText(XCUIKeyboardKey.delete.rawValue)
        field.typeText("Taffy Tester\n")
        closeSheet()
        tapScrolling("stall_tickets")
        XCTAssertTrue(element("fair_card").waitForExistence(timeout: 6))
        XCTAssertTrue(app.staticTexts["Taffy Tester"].exists)
    }

    func testHowToCoversTheNewMechanics() {
        launch()
        tapScrolling("stall_howto")
        XCTAssertTrue(element("howto_sheet").waitForExistence(timeout: 6))
        var titles: Set<String> = []
        for _ in 0..<11 {
            for title in ["Lollipop Swirl", "Gummy Stampede", "Candy Cannon", "Sugar Rush", "Fair-goer Orders", "Daily Bake-Off"] where app.staticTexts[title].exists {
                titles.insert(title)
            }
            app.swipeLeft()
        }
        XCTAssertEqual(titles.count, 6, "Missing pages: \(titles)")
    }

    // MARK: Tour (screenshots for review and the site)

    private func snap(_ name: String) {
        let shot = XCTAttachment(screenshot: app.screenshot())
        shot.name = name
        shot.lifetime = .keepAlways
        add(shot)
    }

    func testTour() {
        launch(["--show-welcome", "--spins=250", "--points=900"], fast: false, seed: 11)
        XCTAssertTrue(element("welcome_start").waitForExistence(timeout: 8))
        snap("01-welcome")
        element("welcome_start").tap()
        XCTAssertTrue(element("alley").waitForExistence(timeout: 6))
        snap("02-alley")
        app.swipeUp()
        snap("03-alley-lower")
        app.swipeDown()

        for (stall, sheet, name) in [("stall_bakeoff", "bakeoff_sheet", "04-bakeoff"), ("stall_jars", "jars_sheet", "05-jars"),
                                     ("stall_booths", "booths_sheet", "06-booths"), ("stall_tickets", "tickets_sheet", "07-tickets"),
                                     ("stall_settings", "settings_sheet", "08-settings")] {
            tapScrolling(stall)
            XCTAssertTrue(element(sheet).waitForExistence(timeout: 6))
            snap(name)
            closeSheet()
            XCTAssertTrue(waitGone(element(sheet)))
        }

        tapScrolling("stall_howto")
        XCTAssertTrue(element("howto_sheet").waitForExistence(timeout: 6))
        for page in 0..<11 {
            snap("09-howto-\(String(format: "%02d", page))")
            app.swipeLeft()
        }
        closeSheet()
    }

    func testTourGameplay() {
        launch(["--autopilot", "--cannon-ready", "--meter-full"], fast: false, seed: 23)
        openGame()
        snap("20-game-ready")
        for i in 0..<14 {
            usleep(700_000)
            snap("21-play-\(String(format: "%02d", i))")
            dismissReceiptIfShown()
        }
    }

    func testTourPowerUps() {
        launch(["--cannon-ready", "--meter-full"], fast: false, seed: 31)
        openGame()
        waitReady()
        element("cannon_button").tap()
        snap("30-cannon-armed")
        element("candy_cell_9").tap()
        usleep(500_000)
        snap("31-cannon-blast")
        waitSettled()
        element("meter_button").tap()
        usleep(400_000)
        snap("32-sugar-rush")
    }
}

private extension XCUIElement {
    func tapIfExists() { if exists && isHittable { tap() } }
}
