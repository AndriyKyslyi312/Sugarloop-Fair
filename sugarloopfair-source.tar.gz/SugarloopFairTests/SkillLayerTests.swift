import Foundation
import Testing
@testable import SugarloopFair

/// A board with no 3-in-a-row anywhere: five symbols in a staggered pattern.
@MainActor
private func calmBoard() -> Board {
    let symbols: [Symbol] = [.mint, .lemon, .grape, .honey, .tart]
    return Board(cells: (0..<Board.count).map { index in
        Cell(symbol: symbols[(Board.row(of: index) * 2 + Board.col(of: index)) % symbols.count])
    })
}

@MainActor
struct LollipopSwirlTests {
    @Test func lollipopSwapIsAlwaysLegal() {
        var board = calmBoard()
        board[0] = Cell(symbol: .lollipop)
        #expect(SpinEngine.findMatches(on: board).isEmpty)
        #expect(SpinEngine.isValidSwap(on: board, 0, 1))
        #expect(SpinEngine.swirlSymbol(on: board, 0, 1) == board[1].symbol)
    }

    @Test func swirlClearsEveryCandyOfThatKind() throws {
        var board = calmBoard()
        board[0] = Cell(symbol: .lollipop)
        let target = board[1].symbol
        let count = board.count(of: target)
        var rng = SeededGenerator(seed: 4)
        let result = try #require(SpinEngine().resolveMove(on: board, swapping: 0, with: 1, bet: 100, using: &rng))
        guard case .swirl(let symbol, let cells) = result.steps[0].special else {
            Issue.record("First step should be a swirl")
            return
        }
        #expect(symbol == target)
        #expect(cells.count == count + 1, "All of that kind plus the lollipop itself")
        #expect(result.steps[0].payout > 0)
    }

    @Test func twoSpecialsDoNotSwirl() {
        var board = calmBoard()
        board[0] = Cell(symbol: .lollipop)
        board[1] = Cell(symbol: .sprinkle, multiplier: 2)
        #expect(SpinEngine.swirlSymbol(on: board, 0, 1) == nil)
        #expect(!SpinEngine.isValidSwap(on: board, 0, 1))
    }
}

@MainActor
struct MatchStampedeTests {
    @Test func fourGummiesTrampleTheirRow() {
        var board = calmBoard()
        for col in 0..<4 { board[Board.index(col: col, row: 4)] = Cell(symbol: .fox) }
        var rng = SeededGenerator(seed: 8)
        let result = SpinEngine().runCascades(from: board, opening: nil, bet: 100, jam: [], using: &rng)
        let stampede = result.steps.first?.stampede
        #expect(stampede?.symbol == .fox)
        #expect(stampede?.row == 4)
        let removed = Set(result.steps[0].clusters.flatMap(\.cells))
        for col in 0..<Board.cols { #expect(removed.contains(Board.index(col: col, row: 4))) }
    }

    @Test func threeGummiesAreJustAMatch() {
        var board = calmBoard()
        for col in 0..<3 { board[Board.index(col: col, row: 4)] = Cell(symbol: .bear) }
        var rng = SeededGenerator(seed: 8)
        let result = SpinEngine().runCascades(from: board, opening: nil, bet: 100, jam: [], using: &rng)
        #expect(result.steps.first?.stampede == nil)
    }
}

@MainActor
struct MatchCannonTests {
    @Test func cannonClearsTheWholeColumnAndPays() throws {
        let board = calmBoard()
        var rng = SeededGenerator(seed: 2)
        let result = try #require(SpinEngine().fireCannon(on: board, column: 3, bet: 100, using: &rng))
        guard case .cannon(let column, let cells) = result.steps[0].special else {
            Issue.record("First step should be the cannon")
            return
        }
        #expect(column == 3)
        #expect(cells.count == Board.rows)
        #expect(result.totalPayout > 0)
        #expect(result.cannonColumn == 3)
    }

    @Test func offBoardColumnIsRejected() {
        var rng = SeededGenerator(seed: 2)
        #expect(SpinEngine().fireCannon(on: calmBoard(), column: 9, bet: 100, using: &rng) == nil)
    }
}

@MainActor
struct MoveAdvisorTests {
    @Test func advisorOnlySuggestsLegalMoves() {
        var rng = SeededGenerator(seed: 12)
        for _ in 0..<40 {
            let board = GameViewModel.playableBoard(using: &rng)
            let move = MoveAdvisor.bestMove(on: board)
            #expect(move != nil)
            if let move { #expect(SpinEngine.isValidSwap(on: board, move.0, move.1)) }
        }
    }

    @Test func playableBoardsStartQuietButSolvable() {
        var rng = SeededGenerator(seed: 13)
        for _ in 0..<40 {
            let board = GameViewModel.playableBoard(using: &rng)
            #expect(SpinEngine.findMatches(on: board).isEmpty)
            #expect(SpinEngine.hasAnyMove(on: board))
        }
    }

    @Test func smartPlayBeatsRandomPlayButStaysNearEven() {
        func rtp(greedy: Bool) -> Double {
            var rng = SeededGenerator(seed: 77)
            var board = GameViewModel.playableBoard(using: &rng)
            var spent = 0.0, won = 0.0
            for _ in 0..<1_500 {
                let moves = MoveAdvisor.validMoves(on: board)
                guard !moves.isEmpty else { board = GameViewModel.playableBoard(using: &rng); continue }
                let move = greedy ? MoveAdvisor.bestMove(on: board)! : moves[Int.random(in: 0..<moves.count, using: &rng)]
                guard let r = SpinEngine().resolveMove(on: board, swapping: move.0, with: move.1, bet: 100, using: &rng) else { continue }
                spent += 100
                won += r.totalPayout
                board = r.finalBoard
            }
            return won / spent
        }
        let random = rtp(greedy: false), smart = rtp(greedy: true)
        #expect(smart > random, "Skill should pay: smart \(smart) vs random \(random)")
        #expect(random > 0.3 && random < 1.0, "Random play return \(random)")
        #expect(smart < 1.3, "Smart play return \(smart)")
    }
}

@MainActor
struct OrderTests {
    private func outcome(_ f: (inout ServeOutcome) -> Void) -> ServeOutcome {
        var o = ServeOutcome()
        f(&o)
        return o
    }

    @Test func goalsMatchTheirOutcomes() {
        #expect(OrderGoal.cluster(symbol: .frog, size: 4).isMet(by: outcome { $0.clusters = [.init(symbol: .frog, size: 5)] }))
        #expect(!OrderGoal.cluster(symbol: .frog, size: 4).isMet(by: outcome { $0.clusters = [.init(symbol: .fox, size: 9)] }))
        #expect(OrderGoal.cascades(count: 3).isMet(by: outcome { $0.cascades = 3 }))
        #expect(!OrderGoal.cascades(count: 3).isMet(by: outcome { $0.cascades = 2 }))
        #expect(OrderGoal.stampede.isMet(by: outcome { $0.stampedes = 1 }))
        #expect(OrderGoal.swirl.isMet(by: outcome { $0.swirls = 1 }))
        #expect(OrderGoal.winMultiple(multiple: 2).isMet(by: outcome { $0.multiple = 2.5 }))
        #expect(OrderGoal.jam(count: 6).isMet(by: outcome { $0.jamHits = 6 }))
        #expect(OrderGoal.sprinkles(total: 2).isMet(by: outcome { $0.appliedSprinkles = 3 }))
    }

    @Test func completedOrdersAreReplaced() {
        var rng = SeededGenerator(seed: 5)
        var orders = OrderBook.fresh(using: &rng)
        orders[1].goal = .stampede
        let result = OrderBook.resolve(orders, with: outcome { $0.stampedes = 1 }, using: &rng)
        #expect(result.completed.contains { $0.id == orders[1].id })
        #expect(result.next.count == OrderBook.slots)
        #expect(!result.next.contains { $0.id == orders[1].id })
    }

    @Test func ordersOnTheBoardNeverRepeatAGoal() {
        var rng = SeededGenerator(seed: 31)
        for _ in 0..<200 {
            let goals = OrderBook.fresh(using: &rng).map(\.goal)
            #expect(Set(goals.map(\.text)).count == goals.count)
        }
    }

    @Test func ordersSurviveJSON() throws {
        var rng = SeededGenerator(seed: 6)
        let orders = OrderBook.fresh(using: &rng)
        let data = try JSONEncoder().encode(orders)
        #expect(try JSONDecoder().decode([FairOrder].self, from: data) == orders)
    }
}

@MainActor
struct RankAndBakeOffRuleTests {
    @Test func ranksClimbWithPoints() {
        #expect(FairRank.level(for: 0) == 0)
        #expect(FairRank.title(for: 0) == "Taffy Trainee")
        #expect(FairRank.level(for: 150) == 1)
        #expect(FairRank.level(for: 1_000_000) == FairRank.titles.count - 1)
        #expect(FairRank.progress(for: 1_000_000) == 1)
        #expect(FairRank.progress(for: 75) == 0.5)
    }

    @Test func skillfulMovesEarnMorePoints() {
        let plain = FairRank.points(for: ServeOutcome(cascades: 1, multiple: 0.2))
        let big = FairRank.points(for: ServeOutcome(cascades: 4, stampedes: 1, swirls: 1, multiple: 5))
        #expect(big > plain)
    }

    @Test func bakeOffDayIsTheSameForEveryone() {
        let date = Date(timeIntervalSince1970: 1_800_000_000)
        let a = BakeOffDay.on(date), b = BakeOffDay(key: BakeOffDay.key(for: date))
        #expect(a == b)
        var ga = a.generator(), gb = b.generator()
        #expect(GameViewModel.playableBoard(using: &ga) == GameViewModel.playableBoard(using: &gb))
        #expect(BakeOffDay(key: "2026-11-16").seed != BakeOffDay(key: "2026-11-17").seed)
    }

    @Test func bakeOffPointsAreHundredPerMultiple() {
        #expect(BakeOffDay.points(forPayout: 250) == 250)
        #expect(BakeOffDay.points(forPayout: 0) == 0)
    }

    @Test func previousDayCrossesMonthAndYear() {
        #expect(ProfileStore.previousKey("2026-03-01") == "2026-02-28")
        #expect(ProfileStore.previousKey("2027-01-01") == "2026-12-31")
        #expect(ProfileStore.previousKey("nonsense") == "")
    }
}

@MainActor
struct SkillLayerStoreTests {
    final class Clock {
        var date = Date(timeIntervalSince1970: 1_800_000_000)
    }

    private func store(_ clock: Clock, storage: ProfileStorage) -> ProfileStore {
        ProfileStore(storage: storage, now: { clock.date }, seed: 99)
    }

    private func store() -> ProfileStore { store(Clock(), storage: .inMemory()) }

    private func store(_ clock: Clock) -> ProfileStore { store(clock, storage: .inMemory()) }

    private func store(storage: ProfileStorage) -> ProfileStore { store(Clock(), storage: storage) }

    @Test func newPlayersGetAGuestNameAndThreeOrders() {
        let s = store()
        #expect(s.playerName.hasPrefix("Guest-"))
        #expect(s.orders.count == OrderBook.slots)
    }

    @Test func namesAreSanitisedAndCapped() {
        #expect(ProfileStore.sanitizedName("  Candy   <b>  Queen!! ") == "Candy b Queen")
        #expect(ProfileStore.sanitizedName(String(repeating: "a", count: 40)).count == ProfileStore.nameLimit)
        let s = store()
        s.setPlayerName("   ")
        #expect(s.playerName.hasPrefix("Guest-"))
        s.setPlayerName("Taffy Tester")
        #expect(s.playerName == "Taffy Tester")
    }

    @Test func servingAnOrderPaysCoinsAndPoints() {
        let s = store()
        let before = s.coins
        let target = s.orders[0]
        let outcome: ServeOutcome
        switch target.goal {
        case .cluster(let symbol, let size): outcome = ServeOutcome(clusters: [.init(symbol: symbol, size: size)])
        case .cascades(let n): outcome = ServeOutcome(cascades: n)
        case .stampede: outcome = ServeOutcome(stampedes: 1)
        case .swirl: outcome = ServeOutcome(swirls: 1)
        case .winMultiple(let m): outcome = ServeOutcome(multiple: Double(m))
        case .jam(let n): outcome = ServeOutcome(jamHits: n)
        case .sprinkles(let t): outcome = ServeOutcome(appliedSprinkles: t)
        }
        let rewards = s.applyServe(outcome, bet: 100)
        #expect(rewards.completed.contains { $0.id == target.id })
        #expect(rewards.orderCoins >= Int(100 * target.rewardMultiple))
        #expect(s.coins == before + rewards.orderCoins)
        #expect(s.profile.sugarPoints == rewards.points)
        #expect(s.profile.ordersCompleted >= 1)
        #expect(s.orders.count == OrderBook.slots)
    }

    @Test func sugarRushNeedsAFullMeter() {
        let s = store()
        #expect(!s.startSugarRush())
        s.seed(meterFull: true)
        #expect(s.startSugarRush())
        #expect(s.rushMoves == ProfileStore.rushMovesPerRush)
        #expect(s.meter == 0)
        s.useRushMove()
        #expect(s.rushMoves == ProfileStore.rushMovesPerRush - 1)
    }

    @Test func roundsTrackPersonalBest() {
        let s = store()
        #expect(s.recordRound(score: 500))
        #expect(!s.recordRound(score: 300))
        #expect(s.recordRound(score: 900))
        #expect(s.profile.bestRoundScore == 900)
        #expect(s.profile.roundsPlayed == 3)
    }

    @Test func bakeOffKeepsBestScoreAndStreak() {
        let clock = Clock()
        let s = store(clock)
        let day1 = s.todayBakeOff
        let first = s.recordBakeOff(score: 400, day: day1)
        #expect(first.isTodayBest && first.isAllTimeBest && first.streak == 1)
        let second = s.recordBakeOff(score: 300, day: day1)
        #expect(!second.isTodayBest)
        #expect(s.bakeOffBest(for: day1) == 400)
        #expect(s.bakeOffAttempts(for: day1) == 2)

        clock.date = clock.date.addingTimeInterval(86_400)
        let day2 = s.todayBakeOff
        #expect(s.bakeOffBest(for: day2) == 0)
        #expect(s.recordBakeOff(score: 100, day: day2).streak == 2)

        clock.date = clock.date.addingTimeInterval(86_400 * 3)
        #expect(s.liveBakeOffStreak == 0, "A missed day breaks the streak")
        #expect(s.recordBakeOff(score: 50, day: s.todayBakeOff).streak == 1)
        #expect(s.profile.bakeOffAllTimeBest == 400)
    }

    @Test func snapshotCarriesEveryLeaderboardCategory() throws {
        let s = store()
        s.setPlayerName("Board Topper")
        s.recordRound(score: 1_234)
        let snapshot = s.snapshot()
        #expect(snapshot.playerName == "Board Topper")
        #expect(Set(snapshot.values.keys) == Set(LeaderboardCategory.allCases.map(\.rawValue)))
        #expect(snapshot.value(.bestRound) == 1_234)
        let data = try JSONEncoder().encode(snapshot)
        #expect(try JSONDecoder().decode(LeaderboardSnapshot.self, from: data) == snapshot)
    }

    @Test func resetKeepsIdentity() {
        let s = store()
        s.setPlayerName("Keeper")
        let id = s.profile.playerID
        s.recordRound(score: 99)
        s.resetProgress()
        #expect(s.playerName == "Keeper")
        #expect(s.profile.playerID == id)
        #expect(s.profile.bestRoundScore == 0)
    }

    @Test func progressPersistsThroughTheSaveFile() {
        let storage = ProfileStorage.inMemory()
        let first = store(storage: storage)
        first.setPlayerName("Saver")
        first.recordRound(score: 777)
        let second = store(storage: storage)
        #expect(second.playerName == "Saver")
        #expect(second.profile.bestRoundScore == 777)
    }

    @Test func olderSaveFilesStillLoad() throws {
        let legacy = #"{"profile":{"coins":4321,"betIndex":2},"records":[]}"#
        let file = try JSONDecoder().decode(SaveFile.self, from: Data(legacy.utf8))
        #expect(file.profile.coins == 4_321)
        #expect(file.profile.betIndex == 2)
        #expect(file.profile.sugarPoints == 0)
        #expect(!file.profile.playerID.isEmpty)
    }
}
