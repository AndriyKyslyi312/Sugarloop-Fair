import Testing
@testable import SugarloopFair

struct PayTableTests {
    @Test func matchPayUsesConnectedGroupTiers() {
        #expect(PayTable.matchMultiplier(for: .mint, size: 2) == 0)
        #expect(PayTable.matchMultiplier(for: .mint, size: 3) == PayTable.matchMultiplier(for: .mint, size: 4))
        #expect(PayTable.matchMultiplier(for: .mint, size: 5) > PayTable.matchMultiplier(for: .mint, size: 4))
        #expect(PayTable.matchMultiplier(for: .frog, size: 3) > PayTable.matchMultiplier(for: .mint, size: 3))
        #expect(PayTable.matchMultiplier(for: .sprinkle, size: 10) == 0)
    }

    @Test func tiersFollowClusterSize() {
        #expect(PayTable.tier(forSize: 7) == -1)
        #expect(PayTable.tier(forSize: 8) == 0)
        #expect(PayTable.tier(forSize: 9) == 0)
        #expect(PayTable.tier(forSize: 10) == 1)
        #expect(PayTable.tier(forSize: 12) == 2)
        #expect(PayTable.tier(forSize: 15) == 2)
        #expect(PayTable.tier(forSize: 16) == 3)
    }

    @Test func smallClustersPayNothing() {
        #expect(PayTable.multiplier(for: .bear, size: 7) == 0)
        #expect(PayTable.multiplier(for: .bear, size: 8) > 0)
    }

    @Test func rarerSymbolsPayMore() {
        #expect(PayTable.multiplier(for: .frog, size: 8) > PayTable.multiplier(for: .mint, size: 8))
        #expect(PayTable.multiplier(for: .mint, size: 16) > PayTable.multiplier(for: .mint, size: 8))
    }

    @Test func specialsNeverPay() {
        #expect(PayTable.multiplier(for: .lollipop, size: 20) == 0)
        #expect(PayTable.multiplier(for: .sprinkle, size: 20) == 0)
    }
}

struct MatchThreeTests {
    private func boardForSwap() -> Board {
        let symbols: [Symbol] = [.mint, .lemon, .grape, .honey, .tart]
        var board = Board(cells: (0..<Board.count).map { index in
            let row = Board.row(of: index), col = Board.col(of: index)
            return Cell(symbol: symbols[(row * 2 + col) % symbols.count])
        })
        board[0] = Cell(symbol: .mint)
        board[1] = Cell(symbol: .lemon)
        board[2] = Cell(symbol: .mint)
        board[7] = Cell(symbol: .mint)
        return board
    }

    @Test func onlyConnectedGroupsOfThreeOrMoreMatch() {
        let board = boardForSwap()
        #expect(SpinEngine.findMatches(on: board).isEmpty)
        #expect(SpinEngine.hasValidMove(on: board))
        var swapped = board
        swapped.cells.swapAt(1, 7)
        let matches = SpinEngine.findMatches(on: swapped)
        #expect(matches.contains { $0.symbol == .mint && $0.cells.count == 3 })
    }

    @Test func chosenSwapCreatesCascadeAndChargesTheSelectedSymbols() throws {
        let board = boardForSwap()
        var rng = SeededGenerator(seed: 41)
        let result = try #require(SpinEngine().resolveMove(on: board, swapping: 1, with: 7, bet: 50, using: &rng))
        #expect(result.startBoard[1].symbol == .mint)
        #expect(result.startBoard[7].symbol == .lemon)
        #expect(!result.steps.isEmpty)
        #expect(result.steps[0].clusters.contains { $0.symbol == .mint && $0.cells.count == 3 })
        #expect(result.totalPayout > 0)
    }

    @Test func invalidAndNonAdjacentSwapsAreRejected() throws {
        var board = boardForSwap()
        board[1] = Cell(symbol: .honey)
        let invalid = (0..<Board.count).flatMap { first in
            Board.neighbours(of: first).filter { $0 > first }.map { (first, $0) }
        }.first { first, second in
            var swapped = board
            swapped.cells.swapAt(first, second)
            return SpinEngine.findMatches(on: swapped).isEmpty
        }
        let pair = try #require(invalid)
        var rng = SeededGenerator(seed: 9)
        #expect(SpinEngine().resolveMove(on: board, swapping: pair.0, with: pair.1, bet: 50, using: &rng) == nil)
        #expect(SpinEngine().resolveMove(on: board, swapping: 0, with: 29, bet: 50, using: &rng) == nil)
    }
}

struct ClusterTests {
    @Test func sevenIsNotACluster() {
        var board = Board(filledWith: .mint)
        for index in 0..<23 { board[index] = Cell(symbol: index % 2 == 0 ? .lemon : .grape) }
        // 7 mints remain, lemons and grapes are 12 and 11.
        #expect(board.count(of: .mint) == 7)
        let symbols = SpinEngine.findClusters(on: board).map(\.symbol)
        #expect(!symbols.contains(.mint))
        #expect(symbols.contains(.lemon))
    }

    @Test func clustersPayAnywhereWithoutAdjacency() {
        var board = Board(filledWith: .grape)
        // Scatter 8 mints on alternating cells so none touch.
        let spots = [0, 2, 4, 7, 9, 11, 12, 14]
        for index in spots { board[index] = Cell(symbol: .mint) }
        let mint = SpinEngine.findClusters(on: board).first { $0.symbol == .mint }
        #expect(mint?.cells == spots)
    }

    @Test func scattersAndBombsNeverCluster() {
        var board = Board(filledWith: .lollipop)
        for index in 0..<10 { board[index] = Cell(symbol: .sprinkle, multiplier: 2) }
        #expect(SpinEngine.findClusters(on: board).isEmpty)
    }
}

struct TumbleTests {
    @Test func survivorsDropAndGapsRefill() {
        var board = Board(filledWith: .mint)
        board[Board.index(col: 0, row: 3)] = Cell(symbol: .bear)
        var rng = SeededGenerator(seed: 1)
        let after = SpinEngine().refilled(board, removing: [Board.index(col: 0, row: 4)], using: &rng)
        #expect(after[Board.index(col: 0, row: 4)].symbol == .bear)
        // Other columns are untouched.
        for row in 0..<Board.rows {
            #expect(after[Board.index(col: 1, row: row)] == board[Board.index(col: 1, row: row)])
        }
    }
}

struct SyrupTideTests {
    @Test func levelsClimbAndCap() {
        #expect(SpinEngine.syrupLevel(forCascade: 0) == 0)
        #expect(SpinEngine.syrupLevel(forCascade: 3) == 3)
        #expect(SpinEngine.syrupLevel(forCascade: 99) == SpinEngine.syrupFactors.count - 1)
    }

    @Test func factorsNeverDecrease() {
        let factors = SpinEngine.syrupFactors
        for (a, b) in zip(factors, factors.dropFirst()) { #expect(b >= a) }
    }
}

struct StickyJamTests {
    @Test func jamDoublesThePayoutAndIsConsumed() {
        var rng = SeededGenerator(seed: 5)
        let board = Board(filledWith: .mint)
        let plain = SpinEngine().spin(bet: 100, startingFrom: board, using: &rng)
        var rng2 = SeededGenerator(seed: 5)
        let jammed = SpinEngine().spin(bet: 100, jam: [0], startingFrom: board, using: &rng2)

        let first = plain.steps[0].payout
        #expect(first > 0)
        #expect(jammed.steps[0].payout == first * SpinEngine.jamFactor)
        #expect(jammed.steps[0].clusters[0].jamConsumed == [0])
        // Spent jam is gone, every other winning cell leaves new jam.
        #expect(!jammed.steps[0].jamAfter.contains(0))
        #expect(jammed.steps[0].jamAfter.count == Board.count - 1)
    }

    @Test func winningCellsLeaveJam() {
        var rng = SeededGenerator(seed: 9)
        let result = SpinEngine().spin(bet: 10, startingFrom: Board(filledWith: .lemon), using: &rng)
        #expect(result.steps[0].jamAfter.count == Board.count)
    }
}

struct SprinkleBombTests {
    @Test func multiplierOnlyAppliesToWinningChains() {
        var rng = SeededGenerator(seed: 2026)
        let engine = SpinEngine()
        var sawBombWin = false
        for _ in 0..<3000 {
            let r = engine.spin(bet: 10, using: &rng)
            if r.steps.isEmpty {
                #expect(r.totalPayout == 0)
            } else {
                #expect(r.totalPayout == r.chainPayout * Double(max(r.bombMultiplier, 1)))
                if r.bombMultiplier > 0 { sawBombWin = true }
            }
        }
        #expect(sawBombWin)
    }

    @Test func bombsSumAcrossTheBoard() {
        var board = Board(filledWith: .mint)
        board[0] = Cell(symbol: .sprinkle, multiplier: 5)
        board[1] = Cell(symbol: .sprinkle, multiplier: 10)
        var rng = SeededGenerator(seed: 3)
        let r = SpinEngine().spin(bet: 10, startingFrom: board, using: &rng)
        // Bombs sit still in the first cascade's row 0 and may fall; the sum is read from the final board.
        let finalSum = r.finalBoard.cells.reduce(0) { $0 + ($1.symbol == .sprinkle ? $1.multiplier : 0) }
        #expect(r.bombMultiplier == finalSum)
    }
}

struct GummyStampedeTests {
    @Test func herdOfThreeConvertsItsRow() {
        var board = Board(filledWith: .mint)
        for col in 0..<3 { board[Board.index(col: col, row: 4)] = Cell(symbol: .bear) }
        let result = SpinEngine.stampede(on: board)
        let event = try? #require(result.event)
        #expect(event?.symbol == .bear)
        #expect(event?.row == 4)
        for col in 0..<Board.cols {
            #expect(result.board[Board.index(col: col, row: 4)].symbol == .bear)
        }
        #expect(result.board[Board.index(col: 0, row: 3)].symbol == .mint)
    }

    @Test func pairsDoNotStampede() {
        var board = Board(filledWith: .mint)
        board[Board.index(col: 0, row: 4)] = Cell(symbol: .fox)
        board[Board.index(col: 1, row: 4)] = Cell(symbol: .fox)
        #expect(SpinEngine.stampede(on: board).event == nil)
    }

    @Test func separatedGummiesDoNotCount() {
        var board = Board(filledWith: .mint)
        for index in [0, 2, 4] { board[index] = Cell(symbol: .frog) }
        #expect(SpinEngine.stampede(on: board).event == nil)
    }

    @Test func scattersAndBombsSurviveTheCharge() {
        var board = Board(filledWith: .mint)
        for col in 0..<3 { board[Board.index(col: col, row: 4)] = Cell(symbol: .fox) }
        board[Board.index(col: 4, row: 4)] = Cell(symbol: .lollipop)
        let result = SpinEngine.stampede(on: board)
        #expect(result.board[Board.index(col: 4, row: 4)].symbol == .lollipop)
    }
}

struct CandyCannonTests {
    @Test func cannonGuaranteesAClusterAndFillsTheColumn() {
        for seed in 1...60 {
            var rng = SeededGenerator(seed: UInt64(seed))
            let board = SpinEngine().randomBoard(using: &rng)
            let shot = SpinEngine.applyCannon(to: board, column: seed % Board.cols, using: &rng)
            let column = (0..<Board.rows).map { shot[Board.index(col: seed % Board.cols, row: $0)].symbol }
            #expect(Set(column).count == 1)
            let symbol = column[0]
            #expect(shot.count(of: symbol) >= PayTable.minCluster)
        }
    }

    @Test func cannonSpinPaysAndJamsTheColumn() {
        var rng = SeededGenerator(seed: 11)
        let r = SpinEngine().spin(bet: 100, cannonColumn: 2, using: &rng)
        #expect(r.cannonColumn == 2)
        #expect(!r.steps.isEmpty)
        #expect(r.totalPayout > 0)
    }

    @Test func invalidColumnIsIgnored() {
        var rng = SeededGenerator(seed: 11)
        let r = SpinEngine().spin(bet: 100, cannonColumn: 99, using: &rng)
        #expect(r.startBoard.cells.count == Board.count)
    }
}

struct FairRunTests {
    @Test func roundCountsFollowScatters() {
        #expect(FairRun.startingRounds(forScatters: 3) == 8)
        #expect(FairRun.startingRounds(forScatters: 5) == 12)
        #expect(FairRun.retriggerRounds(forScatters: 2) == 0)
        #expect(FairRun.retriggerRounds(forScatters: 3) == 4)
        #expect(FairRun.retriggerRounds(forScatters: 5) == 6)
    }

    @Test func runFinishesAndMultipliersOnlyGrow() {
        var rng = SeededGenerator(seed: 77)
        var run = FairRun(rounds: 8)
        var lastMultiplier = 0
        var paid = 0.0
        while !run.isFinished && run.roundsPlayed < 500 {
            let outcome = run.playRound(bet: 10, using: &rng)
            #expect(outcome.accumulatedMultiplier >= lastMultiplier)
            lastMultiplier = outcome.accumulatedMultiplier
            if outcome.result.chainPayout == 0 { #expect(outcome.payout == 0) }
            paid += outcome.payout
        }
        #expect(run.isFinished)
        #expect(run.roundsPlayed >= 8)
        #expect(abs(run.totalWon - paid) < 0.0001)
    }
}

struct DeterminismAndBalanceTests {
    @Test func sameSeedGivesSameSpin() {
        var a = SeededGenerator(seed: 123)
        var b = SeededGenerator(seed: 123)
        let r1 = SpinEngine().spin(bet: 50, using: &a)
        let r2 = SpinEngine().spin(bet: 50, using: &b)
        #expect(r1.startBoard == r2.startBoard)
        #expect(r1.totalPayout == r2.totalPayout)
    }

    @Test func virtualReturnStaysInASaneBand() {
        var rng = SeededGenerator(seed: 2026)
        let engine = SpinEngine()
        let spins = 60_000
        var paid = 0.0
        for _ in 0..<spins {
            let r = engine.spin(bet: 100, using: &rng)
            paid += r.totalPayout
            if r.scatterCount >= 3 {
                var run = FairRun(rounds: FairRun.startingRounds(forScatters: r.scatterCount))
                while !run.isFinished && run.roundsPlayed < 300 { _ = run.playRound(bet: 100, using: &rng) }
                paid += run.totalWon
            }
        }
        let rtp = paid / Double(spins * 100)
        #expect(rtp > 0.75 && rtp < 1.15, "RTP was \(rtp)")
    }
}
