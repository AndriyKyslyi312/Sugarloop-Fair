import Foundation
import Testing
import UIKit
@testable import SugarloopFair

@MainActor
final class TestClock {
    var date = Date(timeIntervalSince1970: 1_800_000_000)
    func advance(_ seconds: TimeInterval) { date = date.addingTimeInterval(seconds) }
}

@MainActor
private func makeStore(clock providedClock: TestClock? = nil) throws -> (ProfileStore, ProfileStorage) {
    let clock = providedClock ?? TestClock()
    let container = ProfileStorage.inMemory()
    let store = ProfileStore(storage: container, now: { clock.date })
    return (store, container)
}

private func summary(bet: Int = 50, payout: Int = 0, cascades: Int = 0, fairRounds: Int = 0) -> SpinSummary {
    SpinSummary(bet: bet, payout: payout, cascades: cascades, jamHits: 0, stampedes: 0, bombTotal: 0, fairRounds: fairRounds, usedCannon: false)
}

@MainActor
struct ProfileStoreTests {
    @Test func freshProfileHasStartingBalanceAndBet() throws {
        let (store, _) = try makeStore()
        #expect(store.coins == 10_000)
        #expect(store.bet == 50)
    }

    @Test func betStaysInsideTheLadder() throws {
        let (store, _) = try makeStore()
        for _ in 0..<20 { store.raiseBet() }
        #expect(store.bet == ProfileStore.bets.last)
        for _ in 0..<20 { store.lowerBet() }
        #expect(store.bet == ProfileStore.bets.first)
    }

    @Test func debitAndCredit() throws {
        let (store, _) = try makeStore()
        try store.debit(2_500)
        #expect(store.coins == 7_500)
        store.credit(100)
        #expect(store.coins == 7_600)
    }

    @Test func debitRefusesWhenBroke() throws {
        let (store, _) = try makeStore()
        #expect(throws: ProfileError.insufficientCoins) { try store.debit(10_001) }
        #expect(store.coins == 10_000)
    }

    @Test func rescueOnlyWhenBelowLowestBet() throws {
        let (store, _) = try makeStore()
        #expect(store.rescueIfBroke() == nil)
        store.seed(coins: 5)
        #expect(store.rescueIfBroke() == ProfileStore.rescueGrant)
        #expect(store.coins == 5 + ProfileStore.rescueGrant)
    }

    @Test func settleUpdatesStatsAndHistory() throws {
        let (store, _) = try makeStore()
        let gained = store.settle(summary(bet: 50, payout: 400, cascades: 3))
        #expect(store.coins == 10_400)
        #expect(store.profile.totalSpins == 1)
        #expect(store.profile.totalWagered == 50)
        #expect(store.profile.biggestWin == 400)
        #expect(store.profile.bestMultipleTimes10 == 80)
        #expect(store.profile.bestCascadeChain == 3)
        #expect(gained.contains(.firstWin))
        #expect(store.recentRecords().count == 1)
    }

    @Test func rosettesAreEarnedOnlyOnce() throws {
        let (store, _) = try makeStore()
        #expect(store.settle(summary(payout: 10)).contains(.firstWin))
        #expect(!store.settle(summary(payout: 10)).contains(.firstWin))
    }

    @Test func bigWinRosettesFollowTheMultiple() throws {
        let (store, _) = try makeStore()
        let gained = store.settle(summary(bet: 100, payout: 2_000))
        #expect(gained.contains(.bigWin))
        #expect(!gained.contains(.megaWin))
        #expect(store.settle(summary(bet: 100, payout: 10_000)).contains(.megaWin))
    }

    @Test func historyIsTrimmed() throws {
        let clock = TestClock()
        let (store, _) = try makeStore(clock: clock)
        for _ in 0..<(ProfileStore.historyLimit + 15) {
            clock.advance(1)
            store.settle(summary(payout: 1))
        }
        #expect(store.recentRecords(limit: 500).count == ProfileStore.historyLimit)
    }

    @Test func fairRunsAreCounted() throws {
        let (store, _) = try makeStore()
        let gained = store.settle(summary(payout: 500, fairRounds: 8))
        #expect(store.profile.fairRuns == 1)
        #expect(gained.contains(.fairRun))
    }

    @Test func progressSurvivesANewStoreOnTheSameContainer() throws {
        let (store, container) = try makeStore()
        try store.debit(1_000)
        store.raiseBet()
        let reopened = ProfileStore(storage: container)
        #expect(reopened.coins == 9_000)
        #expect(reopened.bet == 100)
    }

    @Test func resetRestoresDefaultsAndClearsHistory() throws {
        let (store, _) = try makeStore()
        store.settle(summary(payout: 5_000))
        store.resetProgress()
        #expect(store.coins == 10_000)
        #expect(store.profile.totalSpins == 0)
        #expect(store.recentRecords().isEmpty)
        #expect(store.welcomeSeen)
    }
}

@MainActor
struct MeterAndCannonTests {
    @Test func progressIsClamped() throws {
        let (store, _) = try makeStore()
        store.addProgress(meter: 999, cannon: 999)
        #expect(store.meter == ProfileStore.meterMax)
        #expect(store.meterIsFull)
        #expect(store.cannonCharge == ProfileStore.cannonMax)
        #expect(store.cannonIsReady)
    }

    @Test func spendingResetsAndCounts() throws {
        let (store, _) = try makeStore()
        store.addProgress(meter: 999, cannon: 999)
        store.spendCannon()
        store.spendMeter()
        #expect(store.cannonCharge == 0)
        #expect(store.meter == 0)
        #expect(store.profile.cannonShots == 1)
        #expect(store.earnedAchievements.contains(.cannonFire))
        #expect(store.earnedAchievements.contains(.sweetTooth))
    }
}

@MainActor
struct JarTests {
    @Test func claimPaysThenWaits() throws {
        let clock = TestClock()
        let (store, _) = try makeStore(clock: clock)
        #expect(store.secondsUntilReady(.small) == 0)
        let paid = try store.claim(.small)
        #expect(paid == Jar.small.reward)
        #expect(store.coins == 10_000 + Jar.small.reward)
        #expect(store.secondsUntilReady(.small) == Int(Jar.small.cooldown))
        #expect(throws: ProfileError.jarNotReady(seconds: Int(Jar.small.cooldown))) { try store.claim(.small) }
    }

    @Test func jarsAreIndependentAndRefill() throws {
        let clock = TestClock()
        let (store, _) = try makeStore(clock: clock)
        try store.claim(.small)
        #expect(store.secondsUntilReady(.medium) == 0)
        clock.advance(Jar.small.cooldown + 1)
        #expect(store.secondsUntilReady(.small) == 0)
        #expect(throws: Never.self) { try store.claim(.small) }
    }

    @Test func countdownFormatting() {
        #expect(Formatters.countdown(59) == "0m 59s")
        #expect(Formatters.countdown(3_600) == "1h 0m")
        #expect(Formatters.countdown(90_000) == "1d 1h")
    }
}

@MainActor
struct BoothTests {
    @Test func lockedUntilEnoughSpins() throws {
        let (store, _) = try makeStore()
        #expect(store.isUnlocked(.honey))
        #expect(!store.isUnlocked(.mint))
        #expect(throws: ProfileError.boothLocked(spinsNeeded: Booth.mint.unlockSpins)) { try store.select(.mint) }
        store.seed(spins: Booth.berry.unlockSpins)
        try store.select(.berry)
        #expect(store.booth == .berry)
    }
}

@MainActor
struct SettingsStoreTests {
    @Test func defaultsAndPersistence() throws {
        let suite = "SugarloopFair.tests.\(UUID().uuidString)"
        let defaults = try #require(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }

        let first = SettingsStore(defaults: defaults)
        #expect(first.soundEnabled && first.hapticsEnabled && !first.quickSpin)
        first.soundEnabled = false
        first.quickSpin = true

        let second = SettingsStore(defaults: defaults)
        #expect(!second.soundEnabled)
        #expect(second.hapticsEnabled)
        #expect(second.quickSpin)
    }
}

struct FormatterAndRNGTests {
    @Test func coinsAreGroupedWithCommas() {
        #expect(Formatters.coins(1_234_567) == "1,234,567")
        #expect(Formatters.coins(12.6) == "13")
    }

    @Test func multipleFormatting() {
        #expect(Formatters.multiple(250, bet: 50) == "x5.0")
        #expect(Formatters.multiple(5_000, bet: 50) == "x100")
        #expect(Formatters.multiple(10, bet: 0) == "x0")
    }

    @Test func seededRNGIsRepeatable() {
        var a = GameRNG(seed: 99)
        var b = GameRNG(seed: 99)
        for _ in 0..<10 { #expect(a.next() == b.next()) }
    }
}

struct AssetTests {
    /// actool can silently mangle asset names, so every generated name is looked up for real.
    @Test func everyGeneratedAssetLoads() {
        let names = Symbol.allCases.map(\.assetName)
            + Booth.allCases.map(\.assetName)
            + Jar.allCases.map(\.assetName)
            + ["bg_fair_day", "bg_fair_dusk", "logo_wordmark", "icon_coin", "icon_cannon", "tile_cell", "tile_jam",
               "stall_play", "stall_jars", "stall_booths", "stall_tickets", "stall_howto", "stall_settings",
               "mech_cluster", "mech_match", "mech_syrup", "mech_jam", "mech_sprinkle", "mech_stampede", "mech_cannon", "mech_meter"]
        for name in names {
            #expect(UIImage(named: name) != nil, "Missing asset \(name)")
        }
    }

    @Test func everySoundEffectIsBundled() {
        for effect in SoundEffect.allCases {
            #expect(Bundle.main.url(forResource: "sfx_\(effect.rawValue)", withExtension: "wav") != nil, "Missing sound \(effect.rawValue)")
        }
    }
}
