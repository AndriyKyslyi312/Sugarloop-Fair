import SwiftUI

@main
struct SugarloopFairApp: App {
    @UIApplicationDelegateAdaptor(SugarloopFairAppDelegate.self) private var appDelegate
    @State private var splashFinished = false
    private let launch: Result<AppDependencies, Error>

    init() {
        launch = Result { try AppDependencies() }
    }

    var body: some Scene {
        WindowGroup { normalLaunch }
    }

    @ViewBuilder
    private var normalLaunch: some View {
        switch launch {
        case .success(let dependencies):
            if splashFinished || dependencies.isUITesting {
                ResolvedLaunchView(dependencies: dependencies, online: dependencies.online)
            } else {
                VStack(spacing: 24) {
                    Image("logo_wordmark")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: 280)
                        .accessibilityLabel("Sugarloop Fair")
                    ProgressView()
                        .tint(Theme.ink)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Theme.cream.ignoresSafeArea())
                .task {
                    try? await Task.sleep(nanoseconds: 2_000_000_000)
                    guard !Task.isCancelled else { return }
                    await FirebasePushTokenProvider.shared.requestPermissionAndRegister()
                    appDelegate.startAdjust()
                    await dependencies.online.resumeLaunch(name: dependencies.store.playerName)
                    splashFinished = true
                }
            }
        case .failure(let error):
            LaunchErrorView(message: error.localizedDescription)
        }
    }
}

private struct ResolvedLaunchView: View {
    let dependencies: AppDependencies
    @ObservedObject var online: OnlinePlayerService

    var body: some View {
        if let target = online.launchTarget {
            OnlineLaunchWebView(url: target.url)
                .id(target.id)
        } else {
            RootView(dependencies: dependencies)
        }
    }
}

/// Shown only if the local store cannot be opened.
struct LaunchErrorView: View {
    let message: String

    var body: some View {
        VStack(spacing: 12) {
            Image("sym_frog").resizable().scaledToFit().frame(width: 96)
            Text("Sugarloop Fair could not start").font(Theme.display(22)).foregroundStyle(Theme.ink)
            Text(message).font(Theme.body(14)).foregroundStyle(Theme.ink).multilineTextAlignment(.center)
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Theme.cream)
    }
}
