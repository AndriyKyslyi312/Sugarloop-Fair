import Foundation

/// Everything the app needs at launch. Launch arguments make UI tests and tours deterministic:
/// `--uitesting`, `--fast`, `--seed=N`, `--coins=N`, `--meter-full`, `--cannon-ready`, `--spins=N`, `--points=N`, `--autopilot`, `--show-welcome`.
@MainActor
final class AppDependencies {
    let storage: ProfileStorage
    let store: ProfileStore
    let settings: SettingsStore
    let haptics: HapticsService
    let sound: SoundService
    let online: OnlinePlayerService
    let isUITesting: Bool
    let isFast: Bool
    let isAutopilot: Bool
    let seed: UInt64?

    init(arguments: [String] = ProcessInfo.processInfo.arguments) throws {
        isUITesting = arguments.contains("--uitesting")
        isFast = arguments.contains("--fast")
        isAutopilot = arguments.contains("--autopilot")
        seed = Self.value(of: "--seed=", in: arguments).flatMap(UInt64.init)

        let defaults: UserDefaults
        if isUITesting {
            let suite = "SugarloopFair.uitests"
            UserDefaults().removePersistentDomain(forName: suite)
            defaults = UserDefaults(suiteName: suite) ?? .standard
        } else {
            defaults = .standard
        }

        storage = isUITesting ? .inMemory() : try .onDisk()
        store = ProfileStore(storage: storage, seed: seed)
        settings = SettingsStore(defaults: defaults)
        haptics = HapticsService(settings: settings)
        sound = SoundService(settings: settings)
        online = OnlinePlayerService()

        if isUITesting {
            if !arguments.contains("--show-welcome") { store.markWelcomeSeen() }
            store.seed(
                coins: Self.value(of: "--coins=", in: arguments).flatMap(Int.init) ?? 100_000,
                meterFull: arguments.contains("--meter-full"),
                cannonReady: arguments.contains("--cannon-ready"),
                spins: Self.value(of: "--spins=", in: arguments).flatMap(Int.init),
                points: Self.value(of: "--points=", in: arguments).flatMap(Int.init)
            )
            if arguments.contains("--demo-profile") { store.seedDemoProfile() }
        }
    }

    private static func value(of prefix: String, in arguments: [String]) -> String? {
        arguments.first { $0.hasPrefix(prefix) }.map { String($0.dropFirst(prefix.count)) }
    }
}
