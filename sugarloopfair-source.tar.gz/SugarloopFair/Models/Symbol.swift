import Foundation

/// Every piece that can land on the fair board.
enum Symbol: Int, CaseIterable, Codable, Sendable {
    case mint, lemon, grape      // low tier drops
    case honey, tart             // mid tier treats
    case bear, fox, frog         // gummy animals (they can stampede)
    case lollipop                // scatter: opens Fair Rounds
    case sprinkle                // bomb: carries a multiplier

    /// Symbols that form paying clusters.
    var isPaying: Bool { self != .lollipop && self != .sprinkle }

    /// Gummy animals take part in Gummy Stampede.
    var isAnimal: Bool { self == .bear || self == .fox || self == .frog }

    static let payingSymbols: [Symbol] = Symbol.allCases.filter(\.isPaying)

    /// Asset-catalog name of the generated sprite.
    var assetName: String { "sym_\(name)" }

    var name: String {
        switch self {
        case .mint: "mint"
        case .lemon: "lemon"
        case .grape: "grape"
        case .honey: "honey"
        case .tart: "tart"
        case .bear: "bear"
        case .fox: "fox"
        case .frog: "frog"
        case .lollipop: "lollipop"
        case .sprinkle: "sprinkle"
        }
    }

    var displayName: String {
        switch self {
        case .mint: "Mint Drop"
        case .lemon: "Lemon Drop"
        case .grape: "Grape Drop"
        case .honey: "Honeycomb"
        case .tart: "Berry Tart"
        case .bear: "Gummy Bear"
        case .fox: "Gummy Fox"
        case .frog: "Gummy Frog"
        case .lollipop: "Lollipop"
        case .sprinkle: "Sprinkle Bomb"
        }
    }
}
