import Foundation

/// The single saved player: balance, bet, lifetime stats and unlocks.
/// Stored as JSON; every field has a default so older save files keep loading.
struct PlayerProfile: Codable, Equatable {
    var coins = 10_000
    var betIndex = 1
    var meter = 0
    var cannonCharge = 0

    var totalSpins = 0
    var totalWagered = 0
    var totalWon = 0
    var biggestWin = 0
    /// Best single payout as a multiple of the bet, stored x10 to avoid floating point.
    var bestMultipleTimes10 = 0
    var bestCascadeChain = 0
    var fairRuns = 0
    var stampedes = 0
    var cannonShots = 0
    var jamHits = 0
    var meterCashIns = 0
    var highestBombTotal = 0

    var playerID = UUID().uuidString
    var playerName = ""
    var sugarPoints = 0
    var ordersCompleted = 0
    var ordersJSON = ""
    var rushMoves = 0
    var roundsPlayed = 0
    var bestRoundScore = 0
    var bakeOffDay = ""
    var bakeOffTodayBest = 0
    var bakeOffAttemptsToday = 0
    var bakeOffAllTimeBest = 0
    var bakeOffDaysPlayed = 0
    var bakeOffStreak = 0

    var achievementsRaw: [String] = []
    var boothRaw = Booth.honey.rawValue
    var welcomeSeen = false

    var lastSmallJar: Date?
    var lastMediumJar: Date?
    var lastLargeJar: Date?

    init() {}

    private enum CodingKeys: String, CodingKey {
        case coins, betIndex, meter, cannonCharge, totalSpins, totalWagered, totalWon, biggestWin, bestMultipleTimes10,
             bestCascadeChain, fairRuns, stampedes, cannonShots, jamHits, meterCashIns, highestBombTotal, playerID,
             playerName, sugarPoints, ordersCompleted, ordersJSON, rushMoves, roundsPlayed, bestRoundScore, bakeOffDay,
             bakeOffTodayBest, bakeOffAttemptsToday, bakeOffAllTimeBest, bakeOffDaysPlayed, bakeOffStreak,
             achievementsRaw, boothRaw, welcomeSeen, lastSmallJar, lastMediumJar, lastLargeJar
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let d = PlayerProfile()
        func v<T: Decodable>(_ key: CodingKeys, _ fallback: T) -> T { (try? c.decodeIfPresent(T.self, forKey: key)) ?? fallback }
        coins = v(.coins, d.coins)
        betIndex = v(.betIndex, d.betIndex)
        meter = v(.meter, d.meter)
        cannonCharge = v(.cannonCharge, d.cannonCharge)
        totalSpins = v(.totalSpins, d.totalSpins)
        totalWagered = v(.totalWagered, d.totalWagered)
        totalWon = v(.totalWon, d.totalWon)
        biggestWin = v(.biggestWin, d.biggestWin)
        bestMultipleTimes10 = v(.bestMultipleTimes10, d.bestMultipleTimes10)
        bestCascadeChain = v(.bestCascadeChain, d.bestCascadeChain)
        fairRuns = v(.fairRuns, d.fairRuns)
        stampedes = v(.stampedes, d.stampedes)
        cannonShots = v(.cannonShots, d.cannonShots)
        jamHits = v(.jamHits, d.jamHits)
        meterCashIns = v(.meterCashIns, d.meterCashIns)
        highestBombTotal = v(.highestBombTotal, d.highestBombTotal)
        playerID = v(.playerID, d.playerID)
        playerName = v(.playerName, d.playerName)
        sugarPoints = v(.sugarPoints, d.sugarPoints)
        ordersCompleted = v(.ordersCompleted, d.ordersCompleted)
        ordersJSON = v(.ordersJSON, d.ordersJSON)
        rushMoves = v(.rushMoves, d.rushMoves)
        roundsPlayed = v(.roundsPlayed, d.roundsPlayed)
        bestRoundScore = v(.bestRoundScore, d.bestRoundScore)
        bakeOffDay = v(.bakeOffDay, d.bakeOffDay)
        bakeOffTodayBest = v(.bakeOffTodayBest, d.bakeOffTodayBest)
        bakeOffAttemptsToday = v(.bakeOffAttemptsToday, d.bakeOffAttemptsToday)
        bakeOffAllTimeBest = v(.bakeOffAllTimeBest, d.bakeOffAllTimeBest)
        bakeOffDaysPlayed = v(.bakeOffDaysPlayed, d.bakeOffDaysPlayed)
        bakeOffStreak = v(.bakeOffStreak, d.bakeOffStreak)
        achievementsRaw = v(.achievementsRaw, d.achievementsRaw)
        boothRaw = v(.boothRaw, d.boothRaw)
        welcomeSeen = v(.welcomeSeen, d.welcomeSeen)
        lastSmallJar = v(.lastSmallJar, d.lastSmallJar)
        lastMediumJar = v(.lastMediumJar, d.lastMediumJar)
        lastLargeJar = v(.lastLargeJar, d.lastLargeJar)
    }
}

/// One line of the "ticket stub" history.
struct SpinRecord: Codable, Equatable {
    var date: Date
    var bet: Int
    var payout: Int
    var cascades: Int
    var isFair: Bool
    var bombTotal: Int
}

/// Everything persisted on disk.
struct SaveFile: Codable, Equatable {
    var profile = PlayerProfile()
    var records: [SpinRecord] = []
}
