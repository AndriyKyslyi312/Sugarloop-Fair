import Foundation

/// One board position. `multiplier` is only meaningful for sprinkle bombs.
struct Cell: Equatable, Sendable {
    var symbol: Symbol
    var multiplier: Int = 1
}

/// The 6x5 board, stored row-major (index = row * cols + col, row 0 is the top).
struct Board: Equatable, Sendable {
    static let cols = 6
    static let rows = 5
    static let count = cols * rows

    var cells: [Cell]

    init(cells: [Cell]) {
        precondition(cells.count == Board.count, "Board needs \(Board.count) cells")
        self.cells = cells
    }

    /// Convenience for tests: fill the whole board with one symbol.
    init(filledWith symbol: Symbol) {
        self.cells = Array(repeating: Cell(symbol: symbol), count: Board.count)
    }

    static func index(col: Int, row: Int) -> Int { row * cols + col }
    static func col(of index: Int) -> Int { index % cols }
    static func row(of index: Int) -> Int { index / cols }

    subscript(index: Int) -> Cell {
        get { cells[index] }
        set { cells[index] = newValue }
    }

    func count(of symbol: Symbol) -> Int {
        cells.reduce(0) { $0 + ($1.symbol == symbol ? 1 : 0) }
    }

    /// Orthogonal neighbours of an index.
    static func neighbours(of index: Int) -> [Int] {
        let c = col(of: index), r = row(of: index)
        var result: [Int] = []
        if c > 0 { result.append(index - 1) }
        if c < cols - 1 { result.append(index + 1) }
        if r > 0 { result.append(index - cols) }
        if r < rows - 1 { result.append(index + cols) }
        return result
    }
}
