import SwiftUI

/// Board skins ("booths"), unlocked by total spins played.
enum Booth: String, CaseIterable, Identifiable, Sendable {
    case honey, mint, berry

    var id: String { rawValue }

    var title: String {
        switch self {
        case .honey: "Honey Booth"
        case .mint: "Mint Pavilion"
        case .berry: "Berry Tent"
        }
    }

    var tagline: String {
        switch self {
        case .honey: "The classic stall. Warm caramel glaze."
        case .mint: "Cool and calm. Minty glaze."
        case .berry: "Bold and juicy. Raspberry glaze."
        }
    }

    var unlockSpins: Int {
        switch self {
        case .honey: 0
        case .mint: 60
        case .berry: 200
        }
    }

    var assetName: String { "booth_\(rawValue)" }

    var glaze: Color {
        switch self {
        case .honey: Color(hex: 0xF4B33D)
        case .mint: Color(hex: 0x6FD8B0)
        case .berry: Color(hex: 0xEE4F7E)
        }
    }

    var glazeDeep: Color {
        switch self {
        case .honey: Color(hex: 0xB9741F)
        case .mint: Color(hex: 0x2E9C78)
        case .berry: Color(hex: 0xB82A57)
        }
    }
}
