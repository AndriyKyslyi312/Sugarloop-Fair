import Foundation

/// Rosettes shown in the Tickets stall. Each one is derived from the saved stats.
enum Achievement: String, CaseIterable, Identifiable, Sendable {
    case firstWin, bigWin, megaWin, chain5, stampede, cannonFire, jamSmash, sweetTooth, fairRun, sprinkleStorm, regular, orderRunner, bakeOffEntrant, rankCaptain

    /// Rosettes surfaced by the current match-three game. Legacy slot badges remain
    /// readable from saved profiles but are no longer presented as attainable goals.
    static let current: [Achievement] = [.firstWin, .bigWin, .megaWin, .chain5, .stampede, .cannonFire, .jamSmash, .sweetTooth, .sprinkleStorm, .regular, .orderRunner, .bakeOffEntrant, .rankCaptain]

    var id: String { rawValue }

    var title: String {
        switch self {
        case .firstWin: "First Treat"
        case .bigWin: "Sugar Rush"
        case .megaWin: "Parade of Sweets"
        case .chain5: "Tide Rider"
        case .stampede: "Herd Whisperer"
        case .cannonFire: "Cannon Cadet"
        case .jamSmash: "Jam Smasher"
        case .sweetTooth: "Sweet Tooth"
        case .fairRun: "Fair Regular"
        case .sprinkleStorm: "Sprinkle Storm"
        case .regular: "Loop Regular"
        case .orderRunner: "Order Runner"
        case .bakeOffEntrant: "Bake-Off Entrant"
        case .rankCaptain: "Caramel Captain"
        }
    }

    var detail: String {
        switch self {
        case .firstWin: "Make your first candy match."
        case .bigWin: "Score 20x your move cost in one move."
        case .megaWin: "Score 100x your move cost in one move."
        case .chain5: "Chain 5 cascades from one swap."
        case .stampede: "Trigger a Gummy Stampede."
        case .cannonFire: "Fire the Candy Cannon."
        case .jamSmash: "Smash 10 Sticky Jam cells."
        case .sweetTooth: "Start a Sugar Rush from a full Sweet Tooth Meter."
        case .fairRun: "Play a full Fair Rounds run."
        case .sprinkleStorm: "Finish a cascade with sprinkles worth x25 or more."
        case .regular: "Play 100 valid moves."
        case .orderRunner: "Serve 5 fair-goer orders."
        case .bakeOffEntrant: "Finish a Daily Bake-Off."
        case .rankCaptain: "Reach the Caramel Captain rank."
        }
    }

    func isEarned(by p: PlayerProfile) -> Bool {
        switch self {
        case .firstWin: p.biggestWin > 0
        case .bigWin: p.bestMultipleTimes10 >= 200
        case .megaWin: p.bestMultipleTimes10 >= 1_000
        case .chain5: p.bestCascadeChain >= 5
        case .stampede: p.stampedes >= 1
        case .cannonFire: p.cannonShots >= 1
        case .jamSmash: p.jamHits >= 10
        case .sweetTooth: p.meterCashIns >= 1
        case .fairRun: p.fairRuns >= 1
        case .sprinkleStorm: p.highestBombTotal >= 25
        case .regular: p.totalSpins >= 100
        case .orderRunner: p.ordersCompleted >= 5
        case .bakeOffEntrant: p.bakeOffDaysPlayed >= 1
        case .rankCaptain: FairRank.level(for: p.sugarPoints) >= 3
        }
    }
}
