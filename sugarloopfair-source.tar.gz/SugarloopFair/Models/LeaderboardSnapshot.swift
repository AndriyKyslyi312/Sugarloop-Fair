import Foundation

/// Metrics a future TOP PLAYERS board can rank by. Raw values are stable keys for a server.
enum LeaderboardCategory: String, CaseIterable, Codable, Identifiable, Sendable {
    case sugarPoints
    case bestRound
    case bakeOffToday
    case bakeOffBest
    case bakeOffStreak
    case bestMultipleTimes10
    case longestChain
    case ordersCompleted

    var id: String { rawValue }

    var serverColumn: String {
        switch self {
        case .sugarPoints: "sugar_points"
        case .bestRound: "best_round"
        case .bakeOffToday: "bake_off_today"
        case .bakeOffBest: "bake_off_best"
        case .bakeOffStreak: "bake_off_streak"
        case .bestMultipleTimes10: "best_multiple_times10"
        case .longestChain: "longest_chain"
        case .ordersCompleted: "orders_completed"
        }
    }

    var title: String {
        switch self {
        case .sugarPoints: "Sugar Points"
        case .bestRound: "Best 20-move round"
        case .bakeOffToday: "Today's Bake-Off"
        case .bakeOffBest: "Best Bake-Off"
        case .bakeOffStreak: "Bake-Off streak"
        case .bestMultipleTimes10: "Best single move"
        case .longestChain: "Longest cascade chain"
        case .ordersCompleted: "Orders served"
        }
    }

    /// Human-readable value for this category.
    func format(_ value: Int) -> String {
        switch self {
        case .bestMultipleTimes10: String(format: "x%.1f", Double(value) / 10)
        case .bakeOffStreak: value == 1 ? "1 day" : "\(value) days"
        default: Formatters.coins(value)
        }
    }
}

/// Everything about the local player that a global leaderboard needs, ready to encode and upload.
struct LeaderboardSnapshot: Codable, Equatable, Sendable {
    var playerID: String
    var playerName: String
    var rankLevel: Int
    var rankTitle: String
    var bakeOffDay: String
    var values: [String: Int]
    var capturedAt: Date

    func value(_ category: LeaderboardCategory) -> Int { values[category.rawValue] ?? 0 }
}
