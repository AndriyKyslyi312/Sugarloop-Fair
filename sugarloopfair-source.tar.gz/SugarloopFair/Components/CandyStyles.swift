import SwiftUI

/// Pill button with a plum outline and a pressed-in drop shadow.
struct CandyButtonStyle: ButtonStyle {
    var fill: Color = Theme.raspberry
    var deep: Color = Theme.raspberryDeep
    var foreground: Color = .white
    @Environment(\.isEnabled) private var isEnabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(Theme.display(18))
            .foregroundStyle(foreground)
            .padding(.horizontal, 22)
            .frame(minHeight: Theme.minTarget + 6)
            .background(
                Capsule().fill(LinearGradient(colors: [fill, deep], startPoint: .top, endPoint: .bottom))
            )
            .overlay(Capsule().strokeBorder(Theme.ink, lineWidth: 3))
            .shadow(color: Theme.ink.opacity(0.22), radius: 2, x: 0, y: configuration.isPressed ? 1 : 3)
            .offset(y: configuration.isPressed ? 4 : 0)
            .opacity(isEnabled ? 1 : 0.5)
            .animation(.easeOut(duration: 0.1), value: configuration.isPressed)
    }
}

/// Cream paper card with a plum outline, used wherever text must stay readable on art.
struct PlaqueModifier: ViewModifier {
    var tint: Color = Theme.paper
    var radius: CGFloat = 20

    func body(content: Content) -> some View {
        content
            .background(RoundedRectangle(cornerRadius: radius, style: .continuous).fill(tint))
            .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous).strokeBorder(Theme.ink, lineWidth: 3))
            .shadow(color: Theme.ink.opacity(0.14), radius: 3, x: 0, y: 2)
    }
}

extension View {
    func plaque(tint: Color = Theme.paper, radius: CGFloat = 20) -> some View {
        modifier(PlaqueModifier(tint: tint, radius: radius))
    }

    /// Reads as one element for VoiceOver and keeps the identifier from hiding child identifiers.
    func screenID(_ id: String) -> some View {
        accessibilityElement(children: .contain).accessibilityIdentifier(id)
    }
}

struct CoinBadge: View {
    let amount: Int
    var identifier: String = AccessibilityID.balance

    var body: some View {
        HStack(spacing: 6) {
            Image("icon_coin").resizable().scaledToFit().frame(width: 30, height: 30)
            Text(Formatters.coins(amount))
                .font(Theme.display(20))
                .foregroundStyle(Theme.ink)
                .numericTransition()
                .minimumScaleFactor(0.7)
                .lineLimit(1)
        }
        .padding(.horizontal, 12)
        .frame(minHeight: Theme.minTarget)
        .plaque(radius: 22)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Coins")
        .accessibilityValue(Formatters.coins(amount))
        .accessibilityIdentifier(identifier)
    }
}

struct ToastView: View {
    let text: String

    var body: some View {
        Text(text)
            .font(Theme.body(15))
            .foregroundStyle(Theme.ink)
            .multilineTextAlignment(.center)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .plaque(tint: Theme.lemon.opacity(0.95), radius: 18)
            .padding(.horizontal, 20)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(text)
            .accessibilityIdentifier(AccessibilityID.toast)
            .transition(.move(edge: .top).combined(with: .opacity))
    }
}

/// Header for sheets: stall art, title and a close button.
struct SheetHeader: View {
    let title: String
    let art: String
    let onClose: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Image(art).resizable().scaledToFit().frame(width: 64, height: 64)
                .accessibilityHidden(true)
            Text(title)
                .font(Theme.display(26))
                .foregroundStyle(Theme.ink)
                .minimumScaleFactor(0.7)
                .lineLimit(1)
            Spacer(minLength: 0)
            Button(action: onClose) {
                Image(systemName: "xmark")
                    .font(.system(size: 18, weight: .heavy))
                    .foregroundStyle(Theme.ink)
                    .frame(width: Theme.minTarget, height: Theme.minTarget)
                    .background(Circle().fill(Theme.cream))
                    .overlay(Circle().strokeBorder(Theme.ink, lineWidth: 3))
            }
            .accessibilityLabel("Close")
            .accessibilityIdentifier(AccessibilityID.sheetClose)
        }
        .padding(.horizontal, 16)
        .padding(.top, 14)
        .padding(.bottom, 8)
    }
}

/// Full-bleed art background that never widens the layout.
struct ArtBackground: ViewModifier {
    let name: String

    func body(content: Content) -> some View {
        content.background {
            GeometryReader { proxy in
                Image(name)
                    .resizable()
                    .scaledToFill()
                    .frame(width: proxy.size.width, height: proxy.size.height)
                    .clipped()
            }
            .ignoresSafeArea()
        }
    }
}

extension View {
    func artBackground(_ name: String) -> some View { modifier(ArtBackground(name: name)) }
}
