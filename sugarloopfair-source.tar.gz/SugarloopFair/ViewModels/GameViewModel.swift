import SwiftUI
import Combine

struct Banner: Equatable, Identifiable {
    enum Kind { case win, info, bomb, stampede, fair }
    let id = UUID()
    var text: String
    var kind: Kind
}

struct SpinReceipt: Identifiable, Equatable {
    let id = UUID()
    var bet: Int
    var basePayout: Int
    var fairPayout: Int
    var cascades: Int
    var bombTotal: Int
    var fairRounds: Int
    var stampedes: Int
    var usedCannon: Bool
    var rosettes: [Achievement]
    var orders: [FairOrder] = []
    var orderCoins: Int = 0
    var sugarPoints: Int = 0
    var newRankTitle: String?

    var total: Int { basePayout + fairPayout + orderCoins }
}

/// RNG that is either the system one or a seeded one (UI tests, tours).
struct GameRNG: RandomNumberGenerator {
    private var seeded: SeededGenerator?
    private var system = SystemRandomNumberGenerator()

    init(seed: UInt64?) { seeded = seed.map { SeededGenerator(seed: $0) } }

    mutating func next() -> UInt64 {
        if seeded != nil { return seeded!.next() }
        return system.next()
    }
}

enum GameMode: Equatable {
    case classic
    case bakeOff(BakeOffDay)
}

/// Floating "+120" over the cells that produced it. Position is in board cell units.
struct ScorePopup: Identifiable, Equatable {
    let id = UUID()
    let text: String
    let col: Double
    let row: Double
    let isBig: Bool
}

/// Sprinkle confetti bursting out of cells.
struct ParticleBurst: Identifiable, Equatable {
    let id = UUID()
    let cells: [Int]
    let symbols: [Symbol]
    let start = Date()
}

struct BigWin: Identifiable, Equatable {
    enum Tier { case sweet, rush, mega }
    let id = UUID()
    let tier: Tier
    let label: String

    var title: String {
        switch tier {
        case .sweet: "SWEET!"
        case .rush: "SUGAR STORM!"
        case .mega: "MEGA TREAT!"
        }
    }

    static func tier(forMultiple m: Double) -> Tier? {
        switch m {
        case 25...: .mega
        case 10...: .rush
        case 4...: .sweet
        default: nil
        }
    }
}

/// End of a 20-move round or of a Daily Bake-Off.
struct RoundSummary: Identifiable, Equatable {
    let id = UUID()
    var isBakeOff: Bool
    var score: Int
    var best: Int
    var isNewBest: Bool
    var ordersServed: Int
    var sugarPoints: Int
    var streak: Int
    var dayKey: String
}

@MainActor
final class GameViewModel: ObservableObject {
    enum Phase { case idle, busy, finished }

    static let movesPerRound = 20

    let mode: GameMode
    let store: ProfileStore
    let settings: SettingsStore
    private let online: OnlinePlayerService
    private let haptics: HapticsService
    private let sound: SoundService
    private let fastFactor: Double
    private let autopilot: Bool
    private var rng: GameRNG
    private var bakeRNG: SeededGenerator?
    private var task: Task<Void, Never>?
    private var hintTask: Task<Void, Never>?

    @Published private(set) var board: Board
    /// Bumped per cell whenever its content changes, so SwiftUI can animate a drop for exactly those cells.
    @Published private(set) var tokens: [Int] = Array(repeating: 0, count: Board.count)
    @Published private(set) var highlighted: Set<Int> = []
    @Published private(set) var popping: Set<Int> = []
    @Published private(set) var jam: Set<Int> = []
    @Published private(set) var syrupLevel = 0
    @Published private(set) var banner: Banner?
    @Published private(set) var shownCoins: Int
    @Published private(set) var runningWin = 0.0
    @Published private(set) var phase: Phase = .idle
    @Published private(set) var cannonArmed = false
    @Published private(set) var selectedCells: [Int] = []
    @Published private(set) var movesRemaining: Int

    // Swap animation: the pair slides towards each other while `swapProgress` goes 0 -> 1.
    @Published private(set) var swapPair: (Int, Int)?
    @Published private(set) var swapProgress: CGFloat = 0
    @Published private(set) var wobbleCells: Set<Int> = []
    @Published private(set) var hintCells: Set<Int> = []

    // Juice
    @Published private(set) var popups: [ScorePopup] = []
    @Published private(set) var bursts: [ParticleBurst] = []
    @Published private(set) var bigWin: BigWin?
    @Published private(set) var shakeToken = 0

    // Round / Bake-Off
    @Published private(set) var roundScore = 0
    private var roundOrders = 0
    private var roundPoints = 0
    @Published var roundSummary: RoundSummary?

    @Published var receipt: SpinReceipt?
    @Published var toast: String?

    init(dependencies: AppDependencies, mode: GameMode = .classic) {
        self.mode = mode
        store = dependencies.store
        settings = dependencies.settings
        online = dependencies.online
        haptics = dependencies.haptics
        sound = dependencies.sound
        fastFactor = dependencies.isFast ? 0.02 : 1
        autopilot = dependencies.isAutopilot
        shownCoins = dependencies.store.coins
        if case .bakeOff(let day) = mode {
            var generator = day.generator()
            board = Self.playableBoard(using: &generator)
            bakeRNG = generator
            rng = GameRNG(seed: dependencies.seed)
            movesRemaining = BakeOffDay.moves
        } else {
            var generator = GameRNG(seed: dependencies.seed)
            board = Self.playableBoard(using: &generator)
            rng = generator
            movesRemaining = Self.movesPerRound
        }
        scheduleHint()
        runAutopilotIfNeeded()
    }

    // MARK: Derived

    var isBakeOff: Bool { if case .bakeOff = mode { true } else { false } }
    var bakeOffDay: BakeOffDay? { if case .bakeOff(let day) = mode { day } else { nil } }
    var bet: Int { isBakeOff ? BakeOffDay.bet : store.bet }
    var isIdle: Bool { phase == .idle }
    var canPlay: Bool { isIdle && movesRemaining > 0 }
    var canRaiseBet: Bool { isIdle && !isBakeOff && store.profile.betIndex < ProfileStore.bets.count - 1 }
    var canLowerBet: Bool { isIdle && !isBakeOff && store.profile.betIndex > 0 }
    var syrupFactor: Double { SpinEngine.syrupFactors[min(syrupLevel, SpinEngine.syrupFactors.count - 1)] }
    var rushMoves: Int { isBakeOff ? 0 : store.rushMoves }
    var canFireCannon: Bool { canPlay && !isBakeOff && store.cannonIsReady }
    var canStartRush: Bool { isIdle && !isBakeOff && store.meterIsFull }
    var totalMoves: Int { isBakeOff ? BakeOffDay.moves : Self.movesPerRound }

    // MARK: Bet

    func raiseBet() { if canRaiseBet { store.raiseBet(); haptics.play(.tap); sound.play(.tap) } }
    func lowerBet() { if canLowerBet { store.lowerBet(); haptics.play(.tap); sound.play(.tap) } }

    // MARK: Input

    /// Tap: first tap selects, a tap on a neighbour swaps, any other tap moves the selection.
    func selectCell(_ index: Int) {
        guard canPlay, (0..<Board.count).contains(index) else { return }
        noteInput()
        if cannonArmed {
            fire(column: Board.col(of: index))
            return
        }
        if selectedCells.last == index {
            selectedCells = []
        } else if let first = selectedCells.first, Board.neighbours(of: first).contains(index) {
            selectedCells = []
            attemptSwap(first, index)
            return
        } else {
            selectedCells = [index]
        }
        haptics.play(.tap)
    }

    /// Swipe from a cell in a direction (dx, dy are -1, 0 or 1).
    func swipe(from index: Int, dx: Int, dy: Int) {
        guard canPlay, !cannonArmed else { return }
        let col = Board.col(of: index) + dx, row = Board.row(of: index) + dy
        guard (0..<Board.cols).contains(col), (0..<Board.rows).contains(row) else { return }
        noteInput()
        selectedCells = []
        attemptSwap(index, Board.index(col: col, row: row))
    }

    /// Kept for VoiceOver users and tests: plays the two selected cells.
    func playSelectedMove() {
        guard selectedCells.count == 2 else { return }
        let pair = (selectedCells[0], selectedCells[1])
        selectedCells = []
        attemptSwap(pair.0, pair.1)
    }

    private func attemptSwap(_ a: Int, _ b: Int) {
        guard canPlay else { return }
        guard SpinEngine.isValidSwap(on: board, a, b) else {
            phase = .busy
            task = Task { [weak self] in
                guard let self else { return }
                await self.slide(a, b, keep: false)
                self.wobbleCells = [a, b]
                try? await Task.sleep(ms: 140)
                self.wobbleCells = []
                self.haptics.play(.warning)
                if self.store.profile.totalSpins < 5 { self.toast = "No match there. Line up 3 of a kind, or swap a lollipop." }
                self.phase = .idle
                self.scheduleHint()
            }
            return
        }
        play(a, b)
    }

    // MARK: Moves

    private func play(_ a: Int, _ b: Int) {
        let rush = rushMoves > 0
        var stake = bet
        if !isBakeOff {
            if rush {
                store.useRushMove()
                stake = Int((Double(bet) * ProfileStore.rushBetFactor).rounded())
            } else {
                do { try store.debit(bet) } catch {
                    if let grant = store.rescueIfBroke() {
                        toast = "Out of coins. The fair gave you \(grant) to keep going."
                        shownCoins = store.coins
                    } else {
                        toast = "Not enough coins for this move. Lower the move cost or visit the Candy Jars."
                    }
                    haptics.play(.warning)
                    return
                }
            }
        }

        let startJam = jam
        let result: SpinResult?
        if isBakeOff, var generator = bakeRNG {
            result = SpinEngine().resolveMove(on: board, swapping: a, with: b, bet: stake, jam: startJam, using: &generator)
            bakeRNG = generator
        } else {
            var generator = rng
            result = SpinEngine().resolveMove(on: board, swapping: a, with: b, bet: stake, jam: startJam, using: &generator)
            rng = generator
        }
        guard let result else { return }

        movesRemaining -= 1
        phase = .busy
        toast = nil
        syrupLevel = 0
        runningWin = 0
        let payout = Self.coins(from: result.totalPayout)
        let settled = settle(result, payout: payout, cost: rush || isBakeOff ? 0 : bet, stake: stake, usedCannon: false)

        task = Task { [weak self] in
            guard let self else { return }
            do {
                await self.slide(a, b, keep: true)
                try await self.animate(result, startJam: startJam)
                try await self.celebrate(payout: payout, stake: stake)
                self.after(settled)
                try await self.endOfMoveChecks()
            } catch { /* Settled already; only the animation was cut short. */ }
            self.finish()
        }
    }

    /// Fires the cannon at a column. Free: it is earned by cascades.
    func cannonTapped() {
        guard canFireCannon else { return }
        noteInput()
        cannonArmed.toggle()
        selectedCells = []
        toast = cannonArmed ? "Cannon loaded. Tap any candy to blast its column." : nil
        haptics.play(.tap)
        sound.play(.tap)
    }

    func fire(column: Int) {
        guard canPlay, cannonArmed else { return }
        cannonArmed = false
        var generator = rng
        guard let result = SpinEngine().fireCannon(on: board, column: column, bet: bet, jam: jam, using: &generator) else { return }
        rng = generator
        store.spendCannon()
        phase = .busy
        toast = nil
        syrupLevel = 0
        runningWin = 0
        let startJam = jam
        let payout = Self.coins(from: result.totalPayout)
        let settled = settle(result, payout: payout, cost: 0, stake: bet, usedCannon: true)
        task = Task { [weak self] in
            guard let self else { return }
            do {
                try await self.animate(result, startJam: startJam)
                try await self.celebrate(payout: payout, stake: self.bet)
                self.after(settled)
                try await self.endOfMoveChecks()
            } catch {}
            self.finish()
        }
    }

    func startSugarRush() {
        guard canStartRush, store.startSugarRush() else { return }
        noteInput()
        banner = Banner(text: "Sugar Rush! \(ProfileStore.rushMovesPerRush) free moves x1.5", kind: .fair)
        shakeToken += 1
        sound.play(.fair)
        haptics.play(.bigWin)
        Task { [weak self] in
            try? await Task.sleep(ms: 1_400)
            if self?.banner?.kind == .fair { self?.banner = nil }
        }
    }

    func newBoard() {
        guard isIdle, !isBakeOff else { return }
        var generator = rng
        withAnimation(.candy(0.5, bounce: 0.35)) { setBoard(Self.playableBoard(using: &generator)) }
        rng = generator
        movesRemaining = Self.movesPerRound
        selectedCells = []
        jam = []
        runningWin = 0
        roundScore = 0
        roundOrders = 0
        roundPoints = 0
        roundSummary = nil
        sound.play(.drop)
        scheduleHint()
    }

    func dismissBigWin() { bigWin = nil }

    /// Leaving the screen: every move is settled when it is played, so only animation is dropped.
    func close() {
        task?.cancel()
        hintTask?.cancel()
        finish()
    }

    // MARK: Settlement

    private struct Settled {
        var rewards: ProfileStore.ServeRewards?
        var rosettes: [Achievement]
        var receipt: SpinReceipt?
    }

    private func settle(_ result: SpinResult, payout: Int, cost: Int, stake: Int, usedCannon: Bool) -> Settled {
        if isBakeOff {
            roundScore += BakeOffDay.points(forPayout: result.totalPayout)
            return Settled(rewards: nil, rosettes: [], receipt: nil)
        }
        let jamHits = result.steps.reduce(0) { $0 + $1.clusters.reduce(0) { $0 + $1.jamConsumed.count } }
        let stampedes = result.steps.filter { $0.stampede != nil }.count
        let rosettes: [Achievement]
        if usedCannon {
            store.credit(payout)
            rosettes = []
        } else {
            let summary = SpinSummary(bet: cost, payout: payout, cascades: result.steps.count,
                                      jamHits: jamHits, stampedes: stampedes, bombTotal: result.bombMultiplier,
                                      fairRounds: 0, usedCannon: false)
            rosettes = store.settle(summary)
        }
        store.addProgress(meter: result.meterGain, cannon: usedCannon ? 0 : result.cannonChargeGain)
        let rewards = store.applyServe(ServeOutcome(result: result, bet: stake), bet: stake)
        roundScore += payout + rewards.orderCoins
        roundOrders += rewards.completed.count
        roundPoints += rewards.points

        var receipt: SpinReceipt?
        if payout >= stake * 10 || rewards.rankedUp {
            receipt = SpinReceipt(
                bet: cost, basePayout: payout, fairPayout: 0, cascades: result.steps.count,
                bombTotal: result.bombMultiplier, fairRounds: 0, stampedes: stampedes, usedCannon: usedCannon,
                rosettes: rosettes + rewards.rosettes, orders: rewards.completed, orderCoins: rewards.orderCoins,
                sugarPoints: rewards.points, newRankTitle: rewards.rankedUp ? FairRank.titles[rewards.rankAfter] : nil
            )
        }
        return Settled(rewards: rewards, rosettes: rosettes + rewards.rosettes, receipt: receipt)
    }

    private func after(_ settled: Settled) {
        shownCoins = store.coins
        if let rewards = settled.rewards, !rewards.completed.isEmpty {
            let first = rewards.completed[0]
            toast = rewards.completed.count > 1
                ? "\(rewards.completed.count) orders served! +\(Formatters.coins(rewards.orderCoins)) coins"
                : "\(first.customer.name)'s order served! +\(Formatters.coins(rewards.orderCoins)) coins"
            sound.play(.coin)
            haptics.play(.win)
        } else if let rosette = settled.rosettes.first {
            toast = "Rosette earned: \(rosette.title)"
        }
        receipt = settled.receipt
    }

    private func endOfMoveChecks() async throws {
        if movesRemaining == 0 {
            try await pause(400)
            receipt = nil
            finishRound()
        } else if !SpinEngine.hasAnyMove(on: board) {
            banner = Banner(text: "Shuffle!", kind: .info)
            try await pause(500)
            reshuffle()
            banner = nil
        }
    }

    private func finishRound() {
        if let day = bakeOffDay {
            let record = store.recordBakeOff(score: roundScore, day: day)
            roundSummary = RoundSummary(isBakeOff: true, score: roundScore, best: record.todayBest, isNewBest: record.isTodayBest,
                                        ordersServed: 0, sugarPoints: roundScore / 50, streak: record.streak, dayKey: day.key)
        } else {
            let best = store.recordRound(score: roundScore)
            roundSummary = RoundSummary(isBakeOff: false, score: roundScore, best: store.profile.bestRoundScore, isNewBest: best,
                                        ordersServed: roundOrders, sugarPoints: roundPoints, streak: 0, dayKey: "")
        }
        Task { await online.syncFinishedRound(name: store.playerName, snapshot: store.snapshot()) }
        sound.play(.fair)
    }

    private func reshuffle() {
        if isBakeOff, var generator = bakeRNG {
            withAnimation(.candy(0.5)) { setBoard(Self.playableBoard(using: &generator)) }
            bakeRNG = generator
        } else {
            var generator = rng
            withAnimation(.candy(0.5)) { setBoard(Self.playableBoard(using: &generator)) }
            rng = generator
        }
        jam = []
    }

    static func playableBoard<R: RandomNumberGenerator>(using generator: inout R) -> Board {
        var next = SpinEngine().randomBoard(using: &generator)
        var attempts = 0
        while (!SpinEngine.findMatches(on: next).isEmpty || !SpinEngine.hasAnyMove(on: next)) && attempts < 200 {
            next = SpinEngine().randomBoard(using: &generator)
            attempts += 1
        }
        return next
    }

    /// Any win pays at least one coin, so a small cost never rounds a win down to nothing.
    private static func coins(from payout: Double) -> Int { payout > 0 ? max(1, Int(payout.rounded())) : 0 }

    private func finish() {
        phase = movesRemaining == 0 && isBakeOff ? .finished : .idle
        highlighted = []
        popping = []
        popups = []
        swapPair = nil
        swapProgress = 0
        if bigWin != nil { bigWin = nil }
        if banner?.kind != .fair { banner = nil }
        shownCoins = store.coins
        if phase == .idle { scheduleHint() }
        runAutopilotIfNeeded()
    }

    /// Tour flag: plays the best move by itself so screenshots show real cascades.
    private func runAutopilotIfNeeded() {
        guard autopilot else { return }
        Task { [weak self] in
            try? await Task.sleep(ms: 700)
            guard let self, self.canPlay, self.receipt == nil, self.roundSummary == nil,
                  let move = MoveAdvisor.bestMove(on: self.board) else { return }
            self.attemptSwap(move.0, move.1)
        }
    }

    // MARK: Hint

    private func noteInput() {
        hintTask?.cancel()
        hintCells = []
    }

    /// After a few idle seconds the best move gives a little wiggle.
    private func scheduleHint() {
        hintTask?.cancel()
        hintTask = Task { [weak self] in
            try? await Task.sleep(ms: 7000)
            guard !Task.isCancelled, let self, self.canPlay, !self.cannonArmed, self.selectedCells.isEmpty,
                  let move = MoveAdvisor.bestMove(on: self.board) else { return }
            for _ in 0..<2 {
                self.hintCells = [move.0, move.1]
                try? await Task.sleep(ms: 260)
                self.hintCells = []
                try? await Task.sleep(ms: 260)
            }
        }
    }

    // MARK: Animation

    private func pause(_ ms: Int) async throws {
        let factor = (settings.quickSpin ? 0.55 : 1) * fastFactor
        try await Task.sleep(ms: max(1, Int(Double(ms) * factor)))
    }

    private func setBoard(_ new: Board) {
        for index in 0..<Board.count where new[index] != board[index] { tokens[index] += 1 }
        board = new
    }

    /// Slides two cells into each other's place; `keep` commits the swap, otherwise they slide back.
    private func slide(_ a: Int, _ b: Int, keep: Bool) async {
        swapPair = (a, b)
        withAnimation(.easeInOut(duration: 0.16)) { swapProgress = 1 }
        try? await Task.sleep(ms: Int(170 * max(fastFactor, 0.2)))
        if keep {
            var swapped = board
            swapped.cells.swapAt(a, b)
            board = swapped
            swapPair = nil
            swapProgress = 0
        } else {
            withAnimation(.candy(0.25, bounce: 0.5)) { swapProgress = 0 }
            try? await Task.sleep(ms: Int(250 * max(fastFactor, 0.2)))
            swapPair = nil
        }
    }

    private func emitBurst(cells: [Int], symbols: [Symbol]) {
        let burst = ParticleBurst(cells: cells, symbols: symbols)
        bursts.append(burst)
        Task { [weak self] in
            try? await Task.sleep(ms: 900)
            self?.bursts.removeAll { $0.id == burst.id }
        }
    }

    private func popup(for cells: [Int], text: String, big: Bool) -> ScorePopup {
        let cols = cells.map { Double(Board.col(of: $0)) }, rows = cells.map { Double(Board.row(of: $0)) }
        let n = Double(max(cells.count, 1))
        return ScorePopup(text: text, col: cols.reduce(0, +) / n, row: rows.reduce(0, +) / n, isBig: big)
    }

    private func label(for amount: Double) -> String {
        isBakeOff ? "+\(BakeOffDay.points(forPayout: amount))" : "+\(Formatters.coins(amount))"
    }

    private static func comboText(_ cascade: Int) -> String? {
        switch cascade {
        case ..<1: nil
        case 1: "Combo x2!"
        case 2: "Sweet Combo x3!"
        case 3: "Sugar Storm x4!"
        default: "Candy Quake x\(cascade + 1)!"
        }
    }

    private func animate(_ result: SpinResult, startJam: Set<Int>) async throws {
        jam = startJam
        for (index, step) in result.steps.enumerated() {
            switch step.special {
            case .swirl(let symbol, let cells):
                highlighted = Set(cells)
                banner = Banner(text: "Lollipop Swirl!", kind: .fair)
                shakeToken += 1
                sound.play(.bomb); haptics.play(.bigWin)
                emitBurst(cells: cells, symbols: cells.map { _ in symbol })
                try await pause(650)
            case .cannon(_, let cells):
                highlighted = Set(cells)
                banner = Banner(text: "Cannon blast!", kind: .bomb)
                shakeToken += 1
                sound.play(.cannon); haptics.play(.bigWin)
                emitBurst(cells: cells, symbols: cells.map { step.board[$0].symbol })
                try await pause(550)
            case nil:
                if let stampede = step.stampede {
                    highlighted = Set(stampede.herd)
                    banner = Banner(text: "Gummy Stampede!", kind: .stampede)
                    shakeToken += 1
                    sound.play(.stampede); haptics.play(.bigWin)
                    try await pause(500)
                    highlighted = Set(stampede.herd + stampede.converted)
                    emitBurst(cells: stampede.converted, symbols: stampede.converted.map { _ in stampede.symbol })
                    try await pause(300)
                } else if let combo = Self.comboText(index) {
                    banner = Banner(text: combo, kind: index >= 3 ? .fair : .win)
                }
            }

            syrupLevel = step.syrupLevel
            let cells = Set(step.clusters.flatMap(\.cells))
            highlighted.formUnion(cells)
            runningWin += step.payout
            popups = step.clusters.filter { $0.payout > 0 }.map { popup(for: $0.cells, text: label(for: $0.payout), big: $0.payout >= Double(bet) * 2) }
            sound.play(.win); haptics.play(step.payout >= Double(bet) * 3 ? .bigWin : .win)
            try await pause(index == 0 ? 520 : 600)

            let removed = highlighted
            withAnimation(.easeIn(duration: 0.18)) { popping = removed }
            emitBurst(cells: Array(cells), symbols: cells.map { step.board[$0].symbol })
            jam = step.jamAfter
            try await pause(200)
            highlighted = []
            popping = []
            popups = []
            withAnimation(.candy(0.5, bounce: 0.4)) { setBoard(step.boardAfter) }
            sound.play(.drop)
            try await pause(420)
            if banner?.kind != .fair || index == 0 { banner = nil }
        }

        if result.chainPayout > 0, result.bombMultiplier > 0 {
            let bombs = Set(result.finalBoard.cells.indices.filter { result.finalBoard[$0].symbol == .sprinkle })
            highlighted = bombs
            banner = Banner(text: "Sprinkles x\(result.bombMultiplier)", kind: .bomb)
            runningWin = result.totalPayout
            shakeToken += 1
            emitBurst(cells: Array(bombs), symbols: bombs.map { _ in .sprinkle })
            sound.play(.bomb); haptics.play(.bigWin)
            try await pause(800)
            highlighted = []
        }
        banner = nil
    }

    private func celebrate(payout: Int, stake: Int) async throws {
        guard stake > 0, let tier = BigWin.tier(forMultiple: Double(payout) / Double(stake)) else { return }
        let label = isBakeOff ? "+\(Formatters.coins(BakeOffDay.points(forPayout: Double(payout)))) points" : "+\(Formatters.coins(payout)) coins"
        bigWin = BigWin(tier: tier, label: label)
        shakeToken += 1
        sound.play(.fair); haptics.play(.bigWin)
        try await pause(2_000)
        bigWin = nil
    }
}
