import Foundation

/// Daily Bake-Off: the same starting board and refills for every player on a calendar day (UTC),
/// a fixed number of free moves, scored in points.
struct BakeOffDay: Equatable, Sendable {
    static let moves = 15
    static let bet = 100

    let key: String
    let seed: UInt64

    init(key: String) {
        self.key = key
        // FNV-1a hash of the day key: stable across devices and launches.
        var h: UInt64 = 0xcbf2_9ce4_8422_2325
        for byte in key.utf8 { h = (h ^ UInt64(byte)) &* 0x0000_0100_0000_01B3 }
        seed = h
    }

    static func key(for date: Date) -> String {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "UTC") ?? TimeZone(secondsFromGMT: 0)!
        let c = calendar.dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", c.year ?? 2026, c.month ?? 1, c.day ?? 1)
    }

    static func on(_ date: Date) -> BakeOffDay { BakeOffDay(key: key(for: date)) }

    /// Generator for the day: same board and same refill stream for every player.
    func generator() -> SeededGenerator { SeededGenerator(seed: seed) }

    /// Points for one move: 100 per move-cost multiple scored.
    static func points(forPayout payout: Double) -> Int { Int((payout / Double(bet) * 100).rounded()) }
}
