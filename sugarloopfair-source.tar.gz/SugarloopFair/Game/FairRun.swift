import Foundation

struct FairRoundOutcome: Sendable {
    let result: SpinResult
    /// Sprinkle multiplier collected so far, including this round.
    let accumulatedMultiplier: Int
    let payout: Double
    /// Extra rounds awarded by lollipops during this round.
    let retriggeredRounds: Int
}

/// Fair Rounds: a bonus run where sprinkle multipliers stack across rounds and jam persists.
struct FairRun: Sendable {
    static let meterRounds = 6
    static let retriggerBase = 4

    var roundsRemaining: Int
    private(set) var roundsPlayed = 0
    private(set) var accumulatedMultiplier = 0
    private(set) var totalWon = 0.0
    private(set) var jam: Set<Int> = []

    var isFinished: Bool { roundsRemaining <= 0 }

    init(rounds: Int) { roundsRemaining = rounds }

    /// 3 lollipops open 8 rounds, every extra lollipop adds 2 more.
    static func startingRounds(forScatters count: Int) -> Int { 8 + 2 * max(0, count - 3) }

    /// 3 lollipops in a round add 4 rounds, every extra one adds 1.
    static func retriggerRounds(forScatters count: Int) -> Int {
        count >= 3 ? retriggerBase + (count - 3) : 0
    }

    mutating func playRound<R: RandomNumberGenerator>(bet: Int, using rng: inout R) -> FairRoundOutcome {
        precondition(!isFinished, "Fair run already finished")
        let result = SpinEngine(mode: .fair).spin(bet: bet, jam: jam, using: &rng)

        accumulatedMultiplier += result.bombMultiplier
        // Multipliers only pay when the round itself produced a win.
        let payout = result.chainPayout > 0 ? result.chainPayout * Double(max(accumulatedMultiplier, 1)) : 0
        let extra = Self.retriggerRounds(forScatters: result.scatterCount)

        jam = result.jamAfter
        roundsRemaining += extra - 1
        roundsPlayed += 1
        totalWon += payout
        return FairRoundOutcome(
            result: result,
            accumulatedMultiplier: accumulatedMultiplier,
            payout: payout,
            retriggeredRounds: extra
        )
    }
}
