import Foundation

// MARK: - Result types

struct ClusterWin: Equatable, Sendable {
    let symbol: Symbol
    let cells: [Int]
    /// Payout after Sticky Jam and Syrup Tide.
    let payout: Double
    /// Jam cells this cluster consumed (it paid double).
    let jamConsumed: [Int]
}

struct StampedeEvent: Equatable, Sendable {
    let symbol: Symbol
    let herd: [Int]
    let row: Int
    let converted: [Int]
}

struct CascadeStep: Sendable {
    /// Board that was evaluated (after any stampede).
    var board: Board
    var stampede: StampedeEvent?
    var clusters: [ClusterWin]
    var syrupLevel: Int
    var syrupFactor: Double
    var payout: Double
    var jamAfter: Set<Int>
    /// Board after removal, gravity and refill.
    var boardAfter: Board
    /// Lollipop Swirl or Candy Cannon that opened this step, if any.
    var special: SpecialEvent? = nil
}

/// Player-triggered blasts in match-three play.
enum SpecialEvent: Equatable, Sendable {
    /// A lollipop swapped with a candy clears every candy of that kind.
    case swirl(symbol: Symbol, cells: [Int])
    /// The Candy Cannon clears a whole column.
    case cannon(column: Int, cells: [Int])
}

struct SpinResult: Sendable {
    var startBoard: Board
    var steps: [CascadeStep]
    var finalBoard: Board
    /// Sum of cascade payouts before bomb multipliers.
    var chainPayout: Double
    /// Sum of sprinkle multipliers on the final board (0 when none landed).
    var bombMultiplier: Int
    /// Payout in a plain spin: chain payout times bombs (only when something won).
    var totalPayout: Double
    var scatterCount: Int
    var cannonColumn: Int?
    var jamAfter: Set<Int>
    /// Sweet Tooth Meter progress earned by this spin.
    var meterGain: Int
    /// Candy Cannon charge earned by this spin.
    var cannonChargeGain: Int
}

enum EngineMode: Sendable {
    case base
    case fair
}

// MARK: - Engine

/// Pure rules for one spin: no UI, no persistence, fully deterministic for a given generator.
struct SpinEngine: Sendable {
    var mode: EngineMode = .base

    /// Syrup Tide: payout factor per cascade index in a chain.
    static let syrupFactors: [Double] = [1, 1, 1.25, 1.5, 2, 3]
    static let maxCascades = 30
    static let jamFactor = 1.5

    static func syrupLevel(forCascade index: Int) -> Int { min(index, syrupFactors.count - 1) }

    // MARK: Spin

    func spin<R: RandomNumberGenerator>(
        bet: Int,
        jam startJam: Set<Int> = [],
        cannonColumn: Int? = nil,
        startingFrom fixedBoard: Board? = nil,
        using rng: inout R
    ) -> SpinResult {
        var board = fixedBoard ?? randomBoard(using: &rng)
        var jam = startJam

        if let column = cannonColumn, (0..<Board.cols).contains(column) {
            board = Self.applyCannon(to: board, column: column, using: &rng)
            for row in 0..<Board.rows { jam.insert(Board.index(col: column, row: row)) }
        }
        let startBoard = board

        var steps: [CascadeStep] = []
        var chainPayout = 0.0

        while steps.count < Self.maxCascades {
            // Gummy Stampede: a herd of 3-7 connected gummies runs along its row.
            let stampede = Self.stampede(on: board)
            board = stampede.board

            let found = Self.findClusters(on: board)
            if found.isEmpty { break }

            let level = Self.syrupLevel(forCascade: steps.count)
            let factor = Self.syrupFactors[level]

            var wins: [ClusterWin] = []
            var consumed = Set<Int>()
            for cluster in found {
                let hits = cluster.cells.filter { jam.contains($0) }
                var pay = Double(bet) * PayTable.multiplier(for: cluster.symbol, size: cluster.cells.count) * factor
                if !hits.isEmpty { pay *= Self.jamFactor }
                consumed.formUnion(hits)
                wins.append(ClusterWin(symbol: cluster.symbol, cells: cluster.cells, payout: pay, jamConsumed: hits))
            }
            let stepPayout = wins.reduce(0) { $0 + $1.payout }
            chainPayout += stepPayout

            // Sticky Jam: spent jam disappears, every other winning cell leaves new jam behind.
            jam.subtract(consumed)
            let removed = Set(wins.flatMap(\.cells))
            jam.formUnion(removed.subtracting(consumed))

            let after = refilled(board, removing: removed, using: &rng)
            steps.append(CascadeStep(
                board: board,
                stampede: stampede.event,
                clusters: wins,
                syrupLevel: level,
                syrupFactor: factor,
                payout: stepPayout,
                jamAfter: jam,
                boardAfter: after
            ))
            board = after
        }

        let bombs = board.cells.reduce(0) { $0 + ($1.symbol == .sprinkle ? $1.multiplier : 0) }
        let scatters = board.count(of: .lollipop)
        let total = chainPayout > 0 ? chainPayout * Double(max(bombs, 1)) : 0
        let won = !steps.isEmpty

        return SpinResult(
            startBoard: startBoard,
            steps: steps,
            finalBoard: board,
            chainPayout: chainPayout,
            bombMultiplier: bombs,
            totalPayout: total,
            scatterCount: scatters,
            cannonColumn: cannonColumn,
            jamAfter: jam,
            meterGain: steps.count + (won ? 1 : 0),
            cannonChargeGain: steps.count
        )
    }

    // MARK: Board generation

    private static let baseWeights: [(Symbol, Double)] = [
        (.mint, 10), (.lemon, 10), (.grape, 10),
        (.honey, 8), (.tart, 8),
        (.bear, 6), (.fox, 6), (.frog, 6),
        (.lollipop, 0.8), (.sprinkle, 0.1)
    ]

    private static let fairWeights: [(Symbol, Double)] = [
        (.mint, 10), (.lemon, 10), (.grape, 10),
        (.honey, 8), (.tart, 8),
        (.bear, 6), (.fox, 6), (.frog, 6),
        (.lollipop, 0.5), (.sprinkle, 1.2)
    ]

    private static let bombWeights: [(Int, Double)] = [
        (2, 45), (3, 28), (4, 15), (5, 8), (6, 4), (8, 2), (10, 1), (15, 0.4), (25, 0.1)
    ]

    func randomCell<R: RandomNumberGenerator>(using rng: inout R) -> Cell {
        let symbol = Self.weightedPick(mode == .fair ? Self.fairWeights : Self.baseWeights, using: &rng)
        if symbol == .sprinkle {
            return Cell(symbol: .sprinkle, multiplier: Self.weightedPick(Self.bombWeights, using: &rng))
        }
        return Cell(symbol: symbol)
    }

    func randomBoard<R: RandomNumberGenerator>(using rng: inout R) -> Board {
        Board(cells: (0..<Board.count).map { _ in randomCell(using: &rng) })
    }

    /// Resolves one player-chosen adjacent swap (see MatchEngine.swift).
    func resolveMove<R: RandomNumberGenerator>(
        on source: Board, swapping first: Int, with second: Int, bet: Int,
        jam startJam: Set<Int> = [], using rng: inout R
    ) -> SpinResult? {
        guard Self.isValidSwap(on: source, first, second) else { return nil }
        var board = source
        board.cells.swapAt(first, second)
        let opening = Self.swirlOpening(on: board, swapped: first, second, bet: bet)
        return runCascades(from: board, opening: opening, bet: bet, jam: startJam, using: &rng)
    }

    /// Match groups are connected horizontally or vertically; diagonals do not count.
    static func findMatches(on board: Board) -> [(symbol: Symbol, cells: [Int])] {
        var visited = Set<Int>()
        var matches: [(Symbol, [Int])] = []
        for start in 0..<Board.count where !visited.contains(start) && board[start].symbol.isPaying {
            let symbol = board[start].symbol
            var queue = [start]
            var component: [Int] = []
            visited.insert(start)
            while let current = queue.popLast() {
                component.append(current)
                for next in Board.neighbours(of: current) where !visited.contains(next) && board[next].symbol == symbol {
                    visited.insert(next)
                    queue.append(next)
                }
            }
            if component.count >= 3 { matches.append((symbol, component)) }
        }
        return matches
    }

    static func hasValidMove(on board: Board) -> Bool {
        for first in 0..<Board.count {
            for second in Board.neighbours(of: first) where second > first {
                if createsMatch(on: board, swapping: first, with: second) { return true }
            }
        }
        return false
    }

    static func createsMatch(on source: Board, swapping first: Int, with second: Int) -> Bool {
        guard (0..<Board.count).contains(first), (0..<Board.count).contains(second),
              Board.neighbours(of: first).contains(second) else { return false }
        var swapped = source
        swapped.cells.swapAt(first, second)
        return findMatches(on: swapped).contains { $0.cells.contains(first) || $0.cells.contains(second) }
    }

    static func weightedPick<T, R: RandomNumberGenerator>(_ items: [(T, Double)], using rng: inout R) -> T {
        let total = items.reduce(0) { $0 + $1.1 }
        var roll = Double.random(in: 0..<total, using: &rng)
        for (item, weight) in items {
            if roll < weight { return item }
            roll -= weight
        }
        return items[items.count - 1].0
    }

    // MARK: Clusters

    /// Pay-anywhere clusters: 8 or more of one paying symbol, wherever they sit.
    static func findClusters(on board: Board) -> [(symbol: Symbol, cells: [Int])] {
        var buckets: [Symbol: [Int]] = [:]
        for (index, cell) in board.cells.enumerated() where cell.symbol.isPaying {
            buckets[cell.symbol, default: []].append(index)
        }
        return Symbol.payingSymbols.compactMap { symbol in
            guard let cells = buckets[symbol], cells.count >= PayTable.minCluster else { return nil }
            return (symbol, cells)
        }
    }

    // MARK: Tumble

    /// Remove cells, drop the survivors down each column and fill the gaps from the top.
    func refilled<R: RandomNumberGenerator>(_ board: Board, removing removed: Set<Int>, using rng: inout R) -> Board {
        var result = board
        for col in 0..<Board.cols {
            var survivors: [Cell] = []
            for row in stride(from: Board.rows - 1, through: 0, by: -1) {
                let index = Board.index(col: col, row: row)
                if !removed.contains(index) { survivors.append(board[index]) }
            }
            for (offset, row) in stride(from: Board.rows - 1, through: 0, by: -1).enumerated() {
                let index = Board.index(col: col, row: row)
                result[index] = offset < survivors.count ? survivors[offset] : randomCell(using: &rng)
            }
        }
        return result
    }

    // MARK: Gummy Stampede

    /// Connected groups of 3-7 identical gummy animals charge along the row of their lowest member
    /// and turn every paying symbol on it into that animal.
    static func stampede(on board: Board) -> (board: Board, event: StampedeEvent?) {
        var visited = Set<Int>()
        var best: (symbol: Symbol, group: [Int])?

        for start in 0..<Board.count where !visited.contains(start) {
            let symbol = board[start].symbol
            guard symbol.isAnimal else { continue }
            var group: [Int] = []
            var queue = [start]
            visited.insert(start)
            while let current = queue.popLast() {
                group.append(current)
                for next in Board.neighbours(of: current) where !visited.contains(next) && board[next].symbol == symbol {
                    visited.insert(next)
                    queue.append(next)
                }
            }
            guard (3...7).contains(group.count) else { continue }
            if best == nil || group.count > best!.group.count { best = (symbol, group.sorted()) }
        }

        guard let herd = best else { return (board, nil) }
        let row = herd.group.map { Board.row(of: $0) }.max() ?? 0
        var result = board
        var converted: [Int] = []
        for col in 0..<Board.cols {
            let index = Board.index(col: col, row: row)
            let cell = board[index]
            if cell.symbol.isPaying && cell.symbol != herd.symbol {
                result[index] = Cell(symbol: herd.symbol)
                converted.append(index)
            }
        }
        guard !converted.isEmpty else { return (board, nil) }
        return (result, StampedeEvent(symbol: herd.symbol, herd: herd.group, row: row, converted: converted))
    }

    // MARK: Candy Cannon

    /// Fills a column with the most common paying symbol and tops it up to a guaranteed cluster of 8.
    static func applyCannon<R: RandomNumberGenerator>(to board: Board, column: Int, using rng: inout R) -> Board {
        var result = board
        let target = Symbol.payingSymbols.max { lhs, rhs in
            let l = board.count(of: lhs), r = board.count(of: rhs)
            return l == r ? lhs.rawValue < rhs.rawValue : l < r
        } ?? .mint

        var columnIndices: [Int] = []
        for row in 0..<Board.rows {
            let index = Board.index(col: column, row: row)
            columnIndices.append(index)
            result[index] = Cell(symbol: target)
        }

        var candidates = (0..<Board.count).filter {
            !columnIndices.contains($0) && result[$0].symbol.isPaying && result[$0].symbol != target
        }
        candidates.shuffle(using: &rng)
        var count = result.count(of: target)
        for index in candidates where count < PayTable.minCluster {
            result[index] = Cell(symbol: target)
            count += 1
        }
        return result
    }
}
