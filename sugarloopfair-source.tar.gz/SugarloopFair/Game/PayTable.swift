import Foundation

/// Cluster pay table. Values are multiples of the bet, virtual currency only.
enum PayTable {
    static let minCluster = 8
    static let matchTierLabels = ["3–4", "5–6", "7–8", "9+"]

    /// Global calibration so the virtual return-to-player stays in a sensible band.
    static let payScale = 0.3

    /// Match-three calibration: a random legal move returns a bit over half its cost, smart play close to even.
    static let matchScale = 0.17

    /// Tiers: 8-9, 10-11, 12-15, 16+.
    private static let table: [Symbol: [Double]] = [
        .mint: [0.20, 0.50, 1.5, 5],
        .lemon: [0.25, 0.60, 1.8, 6],
        .grape: [0.30, 0.80, 2.2, 8],
        .honey: [0.50, 1.2, 3, 12],
        .tart: [0.60, 1.5, 4, 15],
        .bear: [1.0, 3, 8, 30],
        .fox: [1.2, 3.5, 10, 40],
        .frog: [1.5, 4, 12, 50]
    ]

    static func tier(forSize size: Int) -> Int {
        switch size {
        case ..<minCluster: -1
        case 8...9: 0
        case 10...11: 1
        case 12...15: 2
        default: 3
        }
    }

    /// Multiple of the bet paid for a cluster of `size` symbols (0 below the minimum).
    static func multiplier(for symbol: Symbol, size: Int) -> Double {
        let t = tier(forSize: size)
        guard t >= 0, let row = table[symbol] else { return 0 }
        return row[t] * payScale
    }

    /// Match-three scoring uses the same candy tiers, mapped to practical group sizes.
    static func matchMultiplier(for symbol: Symbol, size: Int) -> Double {
        guard size >= 3, let row = table[symbol] else { return 0 }
        let tier: Int
        switch size {
        case 3...4: tier = 0
        case 5...6: tier = 1
        case 7...8: tier = 2
        default: tier = 3
        }
        return row[tier] * matchScale
    }

    /// Match pay multiples for the paytable screen, one per match tier.
    static func matchRows(for symbol: Symbol) -> [Double] { (table[symbol] ?? []).map { $0 * matchScale } }

    /// Calibrated multipliers for the paytable screen, one per tier.
    static func rows(for symbol: Symbol) -> [Double] { (table[symbol] ?? []).map { $0 * payScale } }
}
