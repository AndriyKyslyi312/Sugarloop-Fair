import Foundation

/// Match-three rules on top of the shared board, tumble and pay table.
extension SpinEngine {
    /// Gummy matches of this size or more stampede through their row.
    static let stampedeMatchSize = 4

    /// A swap is legal when it makes a connected group of 3+ or when it moves a lollipop onto a candy.
    static func isValidSwap(on board: Board, _ first: Int, _ second: Int) -> Bool {
        guard (0..<Board.count).contains(first), (0..<Board.count).contains(second),
              Board.neighbours(of: first).contains(second) else { return false }
        return swirlSymbol(on: board, first, second) != nil || createsMatch(on: board, swapping: first, with: second)
    }

    /// The candy kind a lollipop swap would clear, if the pair is lollipop + paying candy.
    static func swirlSymbol(on board: Board, _ first: Int, _ second: Int) -> Symbol? {
        let a = board[first].symbol, b = board[second].symbol
        if a == .lollipop && b.isPaying { return b }
        if b == .lollipop && a.isPaying { return a }
        return nil
    }

    static func hasAnyMove(on board: Board) -> Bool {
        for first in 0..<Board.count {
            for second in Board.neighbours(of: first) where second > first && isValidSwap(on: board, first, second) { return true }
        }
        return false
    }

    /// Opening step for a lollipop swap on the already-swapped board.
    static func swirlOpening(on swapped: Board, swapped first: Int, _ second: Int, bet: Int) -> Opening? {
        let a = swapped[first].symbol, b = swapped[second].symbol
        let lollipop: Int, symbol: Symbol
        if a == .lollipop && b.isPaying { lollipop = first; symbol = b }
        else if b == .lollipop && a.isPaying { lollipop = second; symbol = a }
        else { return nil }
        let cells = swapped.cells.indices.filter { swapped[$0].symbol == symbol }
        let removed = Set(cells + [lollipop])
        let pay = Double(bet) * PayTable.matchMultiplier(for: symbol, size: max(3, cells.count))
        let win = ClusterWin(symbol: symbol, cells: cells.sorted(), payout: pay, jamConsumed: [])
        return Opening(wins: [win], removed: removed, special: .swirl(symbol: symbol, cells: Array(removed).sorted()))
    }

    /// Opening step for a cannon shot: the column is cleared, each candy paying a third of its 3-match value.
    static func cannonOpening(on board: Board, column: Int, bet: Int) -> Opening? {
        guard (0..<Board.cols).contains(column) else { return nil }
        let cells = (0..<Board.rows).map { Board.index(col: column, row: $0) }
        var bySymbol: [Symbol: [Int]] = [:]
        for index in cells where board[index].symbol.isPaying { bySymbol[board[index].symbol, default: []].append(index) }
        let wins = Symbol.payingSymbols.compactMap { symbol -> ClusterWin? in
            guard let group = bySymbol[symbol] else { return nil }
            let pay = Double(bet) * PayTable.matchMultiplier(for: symbol, size: 3) * Double(group.count) / 3
            return ClusterWin(symbol: symbol, cells: group, payout: pay, jamConsumed: [])
        }
        return Opening(wins: wins, removed: Set(cells), special: .cannon(column: column, cells: cells))
    }

    struct Opening: Sendable {
        var wins: [ClusterWin]
        var removed: Set<Int>
        var special: SpecialEvent
    }

    /// Fires the Candy Cannon at a column and resolves the cascades that follow.
    func fireCannon<R: RandomNumberGenerator>(on board: Board, column: Int, bet: Int, jam: Set<Int> = [], using rng: inout R) -> SpinResult? {
        guard let opening = Self.cannonOpening(on: board, column: column, bet: bet) else { return nil }
        var result = runCascades(from: board, opening: opening, bet: bet, jam: jam, using: &rng)
        result.cannonColumn = column
        return result
    }

    /// One evaluated cascade step: matches, jam, syrup and any stampede rows.
    private func evaluate(_ board: Board, level: Int, jam: Set<Int>, bet: Int) -> (wins: [ClusterWin], removed: Set<Int>, consumed: Set<Int>, stampede: StampedeEvent?)? {
        let matches = Self.findMatches(on: board)
        guard !matches.isEmpty else { return nil }
        let factor = Self.syrupFactors[level]
        var wins: [ClusterWin] = []
        var removed = Set<Int>()
        var consumed = Set<Int>()
        var stampede: StampedeEvent?

        for match in matches {
            var cells = match.cells
            // Gummy Stampede: a big gummy match tramples the whole row of its lowest member.
            if match.symbol.isAnimal, match.cells.count >= Self.stampedeMatchSize, stampede == nil {
                let row = match.cells.map { Board.row(of: $0) }.max() ?? 0
                let rowCells = (0..<Board.cols).map { Board.index(col: $0, row: row) }.filter { !match.cells.contains($0) && board[$0].symbol != .lollipop }
                cells += rowCells
                stampede = StampedeEvent(symbol: match.symbol, herd: match.cells.sorted(), row: row, converted: rowCells)
            }
            let hits = cells.filter { jam.contains($0) }
            var pay = Double(bet) * PayTable.matchMultiplier(for: match.symbol, size: cells.count) * factor
            if !hits.isEmpty { pay *= Self.jamFactor }
            consumed.formUnion(hits)
            removed.formUnion(cells)
            wins.append(ClusterWin(symbol: match.symbol, cells: cells.sorted(), payout: pay, jamConsumed: hits))
        }
        return (wins, removed, consumed, stampede)
    }

    func runCascades<R: RandomNumberGenerator>(from start: Board, opening: Opening?, bet: Int, jam startJam: Set<Int>, using rng: inout R) -> SpinResult {
        var board = start
        var jam = startJam
        var steps: [CascadeStep] = []
        var chainPayout = 0.0

        if let opening {
            let hits = opening.removed.filter { jam.contains($0) }
            var wins = opening.wins
            if !hits.isEmpty { wins = wins.map { ClusterWin(symbol: $0.symbol, cells: $0.cells, payout: $0.payout * Self.jamFactor, jamConsumed: $0.cells.filter(hits.contains)) } }
            let payout = wins.reduce(0) { $0 + $1.payout }
            chainPayout += payout
            jam.subtract(hits)
            let after = refilled(board, removing: opening.removed, using: &rng)
            steps.append(CascadeStep(board: board, stampede: nil, clusters: wins, syrupLevel: 0, syrupFactor: 1,
                                     payout: payout, jamAfter: jam, boardAfter: after, special: opening.special))
            board = after
        }

        while steps.count < Self.maxCascades {
            let level = Self.syrupLevel(forCascade: steps.count)
            guard let step = evaluate(board, level: level, jam: jam, bet: bet) else { break }
            let payout = step.wins.reduce(0) { $0 + $1.payout }
            chainPayout += payout
            jam.subtract(step.consumed)
            jam.formUnion(step.removed.subtracting(step.consumed))
            let after = refilled(board, removing: step.removed, using: &rng)
            steps.append(CascadeStep(board: board, stampede: step.stampede, clusters: step.wins, syrupLevel: level,
                                     syrupFactor: Self.syrupFactors[level], payout: payout, jamAfter: jam, boardAfter: after))
            board = after
        }

        let bombs = board.cells.reduce(0) { $0 + ($1.symbol == .sprinkle ? $1.multiplier : 0) }
        let total = chainPayout > 0 ? chainPayout * Double(max(bombs, 1)) : 0
        return SpinResult(startBoard: start, steps: steps, finalBoard: board, chainPayout: chainPayout,
                          bombMultiplier: bombs, totalPayout: total, scatterCount: board.count(of: .lollipop),
                          cannonColumn: nil, jamAfter: jam, meterGain: steps.count, cannonChargeGain: steps.count)
    }
}

/// Finds good moves: used for the idle hint, the `--autopilot` tour flag and balance simulation.
enum MoveAdvisor {
    static func validMoves(on board: Board) -> [(Int, Int)] {
        var moves: [(Int, Int)] = []
        for first in 0..<Board.count {
            for second in Board.neighbours(of: first) where second > first && SpinEngine.isValidSwap(on: board, first, second) {
                moves.append((first, second))
            }
        }
        return moves
    }

    /// Immediate value of a move: first-step pay multiples plus specials. Deterministic, no refills.
    static func value(of move: (Int, Int), on board: Board) -> Double {
        var swapped = board
        swapped.cells.swapAt(move.0, move.1)
        if let opening = SpinEngine.swirlOpening(on: swapped, swapped: move.0, move.1, bet: 1) {
            return opening.wins.reduce(0) { $0 + $1.payout } + 0.2
        }
        var total = 0.0
        for match in SpinEngine.findMatches(on: swapped) {
            var size = match.cells.count
            if match.symbol.isAnimal && size >= SpinEngine.stampedeMatchSize { size += Board.cols - 1 }
            total += PayTable.matchMultiplier(for: match.symbol, size: size)
        }
        return total
    }

    static func bestMove(on board: Board) -> (Int, Int)? {
        validMoves(on: board).max { value(of: $0, on: board) < value(of: $1, on: board) }
    }
}
