import Foundation

/// Sugar Points earned per serve and the ten fair ranks they unlock.
enum FairRank {
    static let titles = [
        "Taffy Trainee", "Gumdrop Greeter", "Lollipop Lieutenant", "Caramel Captain", "Fudge Foreman",
        "Toffee Tycoon", "Marzipan Marshal", "Praline Prefect", "Sugarloop Star", "Candy Baron"
    ]

    /// Points needed to reach each rank (index 0 is the starting rank).
    static let thresholds = [0, 150, 400, 800, 1_400, 2_300, 3_600, 5_400, 8_000, 12_000]

    static func level(for points: Int) -> Int {
        thresholds.lastIndex { points >= $0 } ?? 0
    }

    static func title(for points: Int) -> String { titles[level(for: points)] }

    /// 0...1 progress towards the next rank (1 at max rank).
    static func progress(for points: Int) -> Double {
        let l = level(for: points)
        guard l + 1 < thresholds.count else { return 1 }
        let lo = thresholds[l], hi = thresholds[l + 1]
        return Double(points - lo) / Double(hi - lo)
    }

    /// Points for one move: a little for playing, more for skill-driven results.
    static func points(for o: ServeOutcome) -> Int {
        var p = 1
        p += Int((o.multiple * 4).rounded(.down))
        p += max(0, o.cascades - 1) * 3
        p += o.stampedes * 5
        p += o.swirls * 3
        p += o.jamHits / 2
        return p
    }
}
