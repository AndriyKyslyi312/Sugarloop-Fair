import Foundation

/// What one serve achieved, condensed for orders, rank and leaderboards.
struct ServeOutcome: Equatable, Sendable {
    var clusters: [ClusterSize]
    var cascades: Int
    var stampedes: Int
    var jamHits: Int
    /// Lollipop Swirls and cannon shots that opened the move.
    var swirls: Int = 0
    var cannonShots: Int = 0
    /// Sprinkle total that actually multiplied a win (0 when none applied).
    var appliedSprinkles: Int
    /// Payout divided by bet.
    var multiple: Double

    struct ClusterSize: Equatable, Sendable {
        let symbol: Symbol
        let size: Int
    }

    init(clusters: [ClusterSize] = [], cascades: Int = 0, stampedes: Int = 0, jamHits: Int = 0, swirls: Int = 0, cannonShots: Int = 0, appliedSprinkles: Int = 0, multiple: Double = 0) {
        self.clusters = clusters
        self.cascades = cascades
        self.stampedes = stampedes
        self.jamHits = jamHits
        self.swirls = swirls
        self.cannonShots = cannonShots
        self.appliedSprinkles = appliedSprinkles
        self.multiple = multiple
    }

    init(result: SpinResult, bet: Int) {
        let steps = result.steps
        self.init(
            clusters: steps.flatMap { $0.clusters.map { ClusterSize(symbol: $0.symbol, size: $0.cells.count) } },
            cascades: steps.count,
            stampedes: steps.filter { $0.stampede != nil }.count,
            jamHits: steps.reduce(0) { $0 + $1.clusters.reduce(0) { $0 + $1.jamConsumed.count } },
            swirls: steps.filter { if case .swirl = $0.special { true } else { false } }.count,
            cannonShots: steps.filter { if case .cannon = $0.special { true } else { false } }.count,
            appliedSprinkles: result.chainPayout > 0 ? result.bombMultiplier : 0,
            multiple: bet > 0 ? result.totalPayout / Double(bet) : 0
        )
    }
}

/// Visitors of the fair who place orders.
enum Customer: String, Codable, CaseIterable, Sendable {
    case kid, grandma, clown, baker

    var name: String {
        switch self {
        case .kid: "Pip"
        case .grandma: "Nana Rue"
        case .clown: "Bingo"
        case .baker: "Chef Oona"
        }
    }

    var assetName: String { "customer_\(rawValue)" }
}

enum OrderGoal: Codable, Equatable, Sendable {
    /// Pop a cluster of at least `size` of `symbol` in one serve.
    case cluster(symbol: Symbol, size: Int)
    /// Chain at least `count` cascades in one serve.
    case cascades(count: Int)
    /// Trigger a Gummy Stampede.
    case stampede
    /// Win at least `multiple` times the bet in one serve.
    case winMultiple(multiple: Int)
    /// Make a win with sprinkles worth at least `total`.
    case sprinkles(total: Int)
    /// Smash at least `count` jam cells in one serve.
    case jam(count: Int)
    /// Pop a Lollipop Swirl.
    case swirl

    var text: String {
        switch self {
        case .cluster(let s, let n): "Match \(n)+ \(s.displayName)s at once"
        case .cascades(let n): "Chain \(n) cascades"
        case .stampede: "Start a Gummy Stampede"
        case .winMultiple(let m): "Score \(m)x your move cost"
        case .sprinkles(let t): "Win with x\(t)+ sprinkles"
        case .jam(let n): "Smash \(n) jam cells"
        case .swirl: "Pop a Lollipop Swirl"
        }
    }

    var iconAsset: String {
        switch self {
        case .cluster(let s, _): s.assetName
        case .cascades: "mech_syrup"
        case .stampede: "sym_bear"
        case .winMultiple: "icon_coin"
        case .sprinkles: "sym_sprinkle"
        case .jam: "tile_jam"
        case .swirl: "sym_lollipop"
        }
    }

    func isMet(by o: ServeOutcome) -> Bool {
        switch self {
        case .cluster(let s, let n): o.clusters.contains { $0.symbol == s && $0.size >= n }
        case .cascades(let n): o.cascades >= n
        case .stampede: o.stampedes > 0
        case .winMultiple(let m): o.multiple >= Double(m)
        case .sprinkles(let t): o.appliedSprinkles >= t
        case .jam(let n): o.jamHits >= n
        case .swirl: o.swirls > 0
        }
    }
}

struct FairOrder: Codable, Equatable, Identifiable, Sendable {
    var id: UUID
    var customer: Customer
    var goal: OrderGoal
    /// Coin reward as a multiple of the bet used for the serve that completes it.
    var rewardMultiple: Double
    var sugarPoints: Int
}

enum OrderBook {
    static let slots = 3

    static func make<R: RandomNumberGenerator>(using rng: inout R) -> FairOrder {
        let customer = Customer.allCases.randomElement(using: &rng) ?? .kid
        let roll = Int.random(in: 0..<100, using: &rng)
        let goal: OrderGoal
        let reward: Double
        switch roll {
        case 0..<34:
            let symbol = Symbol.payingSymbols.randomElement(using: &rng) ?? .mint
            let size = symbol.isAnimal ? 4 : ([4, 5].randomElement(using: &rng) ?? 4)
            goal = .cluster(symbol: symbol, size: size)
            reward = symbol.isAnimal ? 4 : (size == 5 ? 4 : 2)
        case 34..<52:
            let n = [3, 4].randomElement(using: &rng) ?? 3
            goal = .cascades(count: n)
            reward = n == 3 ? 2 : 4
        case 52..<64:
            goal = .stampede
            reward = 4
        case 64..<76:
            goal = .swirl
            reward = 3
        case 76..<88:
            let n = [6, 10].randomElement(using: &rng) ?? 6
            goal = .jam(count: n)
            reward = n == 6 ? 2 : 3
        case 88..<96:
            let m = [2, 3].randomElement(using: &rng) ?? 2
            goal = .winMultiple(multiple: m)
            reward = Double(m + 1)
        default:
            goal = .sprinkles(total: 2)
            reward = 5
        }
        return FairOrder(id: UUID(uuidString: uuid(using: &rng)) ?? UUID(), customer: customer, goal: goal, rewardMultiple: reward / 2, sugarPoints: Int(reward * 15))
    }

    static func fresh<R: RandomNumberGenerator>(using rng: inout R) -> [FairOrder] {
        var list: [FairOrder] = []
        for _ in 0..<slots { list.append(makeDistinct(from: list, using: &rng)) }
        return list
    }

    /// A new order whose goal differs from every order already on the board.
    static func makeDistinct<R: RandomNumberGenerator>(from existing: [FairOrder], using rng: inout R) -> FairOrder {
        var order = make(using: &rng)
        var attempts = 0
        while existing.contains(where: { $0.goal == order.goal }) && attempts < 20 {
            order = make(using: &rng)
            attempts += 1
        }
        return order
    }

    /// Splits orders into completed ones and the refilled list.
    static func resolve<R: RandomNumberGenerator>(_ orders: [FairOrder], with outcome: ServeOutcome, using rng: inout R) -> (completed: [FairOrder], next: [FairOrder]) {
        var completed: [FairOrder] = []
        var next = orders
        for index in next.indices where next[index].goal.isMet(by: outcome) {
            completed.append(next[index])
            let others = next.enumerated().filter { $0.offset != index }.map(\.element)
            next[index] = makeDistinct(from: others, using: &rng)
        }
        return (completed, next)
    }

    /// Deterministic UUID text from the generator so seeded runs stay reproducible.
    private static func uuid<R: RandomNumberGenerator>(using rng: inout R) -> String {
        let a = rng.next(), b = rng.next()
        let hex = String(format: "%016llX%016llX", a, b)
        let c = Array(hex)
        return "\(String(c[0..<8]))-\(String(c[8..<12]))-4\(String(c[13..<16]))-A\(String(c[17..<20]))-\(String(c[20..<32]))"
    }
}
