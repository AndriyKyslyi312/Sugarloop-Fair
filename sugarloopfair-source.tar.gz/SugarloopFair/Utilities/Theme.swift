import SwiftUI

extension Color {
    init(hex: UInt32, opacity: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: opacity
        )
    }
}

/// Visual language of Sugarloop Fair: pastel mint / raspberry / caramel on cream with plum outlines.
enum Theme {
    static let ink = Color(hex: 0x4A2340)
    static let cream = Color(hex: 0xFFF3DC)
    static let paper = Color(hex: 0xFFFBF1)
    static let mint = Color(hex: 0x6FD8B0)
    static let mintDeep = Color(hex: 0x2E9C78)
    static let raspberry = Color(hex: 0xEE4F7E)
    static let raspberryDeep = Color(hex: 0xB82A57)
    static let caramel = Color(hex: 0xE9A04B)
    static let lemon = Color(hex: 0xFFD84D)
    static let grape = Color(hex: 0x9A6BDB)
    static let sky = Color(hex: 0xBDE7F4)
    static let pink = Color(hex: 0xFFB3C8)

    static let maxContentWidth: CGFloat = 640
    static let minTarget: CGFloat = 44

    static func display(_ size: CGFloat) -> Font { .system(size: size, weight: .heavy, design: .rounded) }
    static func body(_ size: CGFloat = 16) -> Font { .system(size: size, weight: .semibold, design: .rounded) }
}
