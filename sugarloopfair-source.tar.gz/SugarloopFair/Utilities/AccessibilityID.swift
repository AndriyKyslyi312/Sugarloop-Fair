import Foundation

/// Identifiers shared with the UI tests (duplicated there as plain strings).
enum AccessibilityID {
    static let alley = "alley"
    static let balance = "balance"
    static let stallPlay = "stall_play"
    static let stallJars = "stall_jars"
    static let stallBakeOff = "stall_bakeoff"
    static let stallBooths = "stall_booths"
    static let stallTickets = "stall_tickets"
    static let stallHowTo = "stall_howto"
    static let stallSettings = "stall_settings"
    static let sheetClose = "sheet_close"

    static let gameScreen = "game_screen"
    static let gameClose = "game_close"
    static let gameBalance = "game_balance"
    static let matchButton = "match_button"
    static let betPlus = "bet_plus"
    static let betMinus = "bet_minus"
    static let betValue = "bet_value"
    static let cannonButton = "cannon_button"
    static let meterButton = "meter_button"
    static let board = "board"
    static let banner = "banner"
    static let receipt = "receipt"
    static let receiptClose = "receipt_close"
    static func column(_ index: Int) -> String { "cannon_column_\(index)" }

    static let toast = "toast"
    static let welcomeStart = "welcome_start"
    static let resetButton = "reset_progress"
    static let resetConfirm = "reset_confirm"
    static let hapticsToggle = "haptics_toggle"
    static let soundToggle = "sound_toggle"
    static let quickToggle = "quick_toggle"
    static func jar(_ name: String) -> String { "jar_\(name)" }
    static func booth(_ name: String) -> String { "booth_\(name)" }
}
