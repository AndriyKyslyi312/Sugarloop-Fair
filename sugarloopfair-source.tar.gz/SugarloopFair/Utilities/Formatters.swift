import Foundation

enum Formatters {
    private static let grouped: NumberFormatter = {
        let f = NumberFormatter()
        f.numberStyle = .decimal
        f.groupingSeparator = ","
        f.usesGroupingSeparator = true
        f.locale = Locale(identifier: "en_US")
        return f
    }()

    static func coins(_ value: Int) -> String { grouped.string(from: NSNumber(value: value)) ?? "\(value)" }

    static func coins(_ value: Double) -> String { coins(Int(value.rounded())) }

    /// "x12.5" style multiplier of a bet.
    static func multiple(_ payout: Double, bet: Int) -> String {
        guard bet > 0 else { return "x0" }
        let m = payout / Double(bet)
        return m >= 10 ? "x\(Int(m.rounded()))" : "x" + String(format: "%.1f", m)
    }

    static func countdown(_ seconds: TimeInterval) -> String {
        let s = max(0, Int(seconds.rounded(.up)))
        if s >= 86_400 { return "\(s / 86_400)d \((s % 86_400) / 3_600)h" }
        if s >= 3_600 { return "\(s / 3_600)h \((s % 3_600) / 60)m" }
        return "\(s / 60)m \(s % 60)s"
    }
}
