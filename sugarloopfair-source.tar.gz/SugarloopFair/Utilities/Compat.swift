import SwiftUI

// iOS 15 is the minimum for this app, so newer SwiftUI and concurrency APIs go through these helpers.

extension Animation {
    /// Spring described like the iOS 17 `spring(duration:bounce:)`, built from the iOS 13 API.
    static func candy(_ duration: Double, bounce: Double = 0) -> Animation {
        .spring(response: duration, dampingFraction: max(0.3, 1 - bounce * 0.75))
    }
}

extension Task where Success == Never, Failure == Never {
    /// `Task.sleep(for:)` needs iOS 16; this works on iOS 15.
    static func sleep(ms: Int) async throws {
        try await Task.sleep(nanoseconds: UInt64(max(0, ms)) * 1_000_000)
    }
}

extension View {
    /// Rolling digits where available (iOS 16+).
    @ViewBuilder
    func numericTransition() -> some View {
        if #available(iOS 16.0, *) {
            contentTransition(.numericText())
        } else {
            self
        }
    }

    /// Sheet heights where available (iOS 16+); full-height sheets on iOS 15.
    @ViewBuilder
    func sheetSize(allowsMedium: Bool) -> some View {
        if #available(iOS 16.0, *) {
            presentationDetents(allowsMedium ? [.medium, .large] : [.large])
                .presentationDragIndicator(.visible)
        } else {
            self
        }
    }
}
