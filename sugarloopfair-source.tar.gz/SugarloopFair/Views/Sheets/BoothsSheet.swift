import SwiftUI

struct BoothsSheet: View {
    @ObservedObject var store: ProfileStore
    let onClose: () -> Void
    @State private var message: String?

    var body: some View {
        SheetScaffold(title: "Booths", art: "stall_booths", identifier: "booths_sheet", onClose: onClose) {
            Text("Each booth glazes the board in its own colours. Unlock more by playing.")
                .font(Theme.body(14)).foregroundStyle(Theme.ink.opacity(0.8))
                .frame(maxWidth: .infinity, alignment: .leading)
            ForEach(Booth.allCases) { booth in row(booth) }
            if let message {
                Text(message).font(Theme.body(14)).foregroundStyle(Theme.ink)
                    .padding(10).plaque(tint: Theme.lemon, radius: 14)
            }
        }
    }

    private func row(_ booth: Booth) -> some View {
        let unlocked = store.isUnlocked(booth)
        let selected = store.booth == booth
        return HStack(spacing: 12) {
            Image(booth.assetName).resizable().scaledToFit().frame(width: 80, height: 80)
                .saturation(unlocked ? 1 : 0).opacity(unlocked ? 1 : 0.6).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text(booth.title).font(Theme.display(20)).foregroundStyle(Theme.ink).lineLimit(2).minimumScaleFactor(0.8)
                Text(booth.tagline).font(Theme.body(13)).foregroundStyle(Theme.ink.opacity(0.8))
                Capsule().fill(booth.glaze).frame(height: 10).overlay(Capsule().strokeBorder(Theme.ink, lineWidth: 2))
            }
            Spacer(minLength: 0)
            Button(selected ? "Selected" : (unlocked ? "Select" : "\(max(0, booth.unlockSpins - store.profile.totalSpins)) moves")) {
                do { try store.select(booth); message = nil } catch { message = error.localizedDescription }
            }
            .buttonStyle(CandyButtonStyle(fill: selected ? Theme.mint : Theme.raspberry, deep: selected ? Theme.mintDeep : Theme.raspberryDeep, foreground: selected ? Theme.ink : .white))
            .fixedSize()
            .disabled(selected)
            .accessibilityLabel(unlocked ? (selected ? "\(booth.title), selected" : "Select \(booth.title)") : "\(booth.title), locked")
            .accessibilityIdentifier(AccessibilityID.booth(booth.rawValue))
        }
        .padding(12)
        .plaque()
    }
}
