import SwiftUI

/// Shared sheet frame: paper background, header with stall art, scrolling body.
struct SheetScaffold<Content: View>: View {
    let title: String
    let art: String
    let identifier: String
    let onClose: () -> Void
    @ViewBuilder var content: Content

    var body: some View {
        VStack(spacing: 0) {
            SheetHeader(title: title, art: art, onClose: onClose)
            ScrollView {
                VStack(spacing: 12) { content }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 24)
                    .frame(maxWidth: 560)
                    .frame(maxWidth: .infinity)
            }
        }
        .background(Theme.cream.ignoresSafeArea())
        .screenID(identifier)
        .preferredColorScheme(.light)
    }
}
