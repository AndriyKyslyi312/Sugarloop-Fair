import SwiftUI

struct JarsSheet: View {
    @ObservedObject var store: ProfileStore
    let onClose: () -> Void
    @State private var message: String?

    var body: some View {
        SheetScaffold(title: "Candy Jars", art: "stall_jars", identifier: "jars_sheet", onClose: onClose) {
            CoinBadge(amount: store.coins, identifier: "jars_balance")
                .frame(maxWidth: .infinity, alignment: .leading)
            Text("Free refills of virtual coins. Each jar refills on its own timer.")
                .font(Theme.body(14)).foregroundStyle(Theme.ink.opacity(0.8))
                .frame(maxWidth: .infinity, alignment: .leading)
            ForEach(Jar.allCases) { jar in row(jar) }
            if let message {
                Text(message).font(Theme.body(14)).foregroundStyle(Theme.ink)
                    .padding(10).plaque(tint: Theme.lemon, radius: 14)
                    .accessibilityIdentifier("jars_message")
            }
        }
    }

    private func row(_ jar: Jar) -> some View {
        let wait = store.secondsUntilReady(jar)
        return HStack(spacing: 12) {
            Image(jar.assetName).resizable().scaledToFit().frame(width: 76, height: 92).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text(jar.title).font(Theme.display(20)).foregroundStyle(Theme.ink)
                Text("+\(Formatters.coins(jar.reward)) coins").font(Theme.body(15)).foregroundStyle(Theme.ink)
                Text("Refills every \(Formatters.countdown(jar.cooldown))").font(Theme.body(12)).foregroundStyle(Theme.ink.opacity(0.7))
            }
            Spacer(minLength: 0)
            Button(wait == 0 ? "Claim" : Formatters.countdown(TimeInterval(wait))) { claim(jar) }
                .buttonStyle(CandyButtonStyle(fill: Theme.mint, deep: Theme.mintDeep, foreground: Theme.ink))
                .disabled(wait > 0)
                .accessibilityIdentifier(AccessibilityID.jar(jar.rawValue))
        }
        .padding(12)
        .plaque()
    }

    private func claim(_ jar: Jar) {
        do {
            let amount = try store.claim(jar)
            message = "You collected \(Formatters.coins(amount)) coins."
        } catch {
            message = error.localizedDescription
        }
    }
}
