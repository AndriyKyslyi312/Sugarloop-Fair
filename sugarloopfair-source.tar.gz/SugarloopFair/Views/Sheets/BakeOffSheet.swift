import SwiftUI

/// The Bake-Off stall: today's challenge, personal records and the start button.
struct BakeOffSheet: View {
    @ObservedObject var store: ProfileStore
    let onStart: () -> Void
    let onClose: () -> Void

    var body: some View {
        let today = store.todayBakeOff
        SheetScaffold(title: "Daily Bake-Off", art: "stall_bakeoff", identifier: "bakeoff_sheet", onClose: onClose) {
            Image("mech_bakeoff").resizable().scaledToFit().frame(maxHeight: 190).accessibilityHidden(true)
            Text("Everyone gets the same board and the same candy drops today. You have \(BakeOffDay.moves) free moves; every move-cost multiple you score is worth 100 points. Your best attempt of the day counts.")
                .font(Theme.body(15)).foregroundStyle(Theme.ink)
                .padding(14).plaque()
            VStack(spacing: 8) {
                row("Today", today.key)
                row("Best today", Formatters.coins(store.bakeOffBest(for: today)))
                row("Attempts today", "\(store.bakeOffAttempts(for: today))")
                row("Personal best", Formatters.coins(store.profile.bakeOffAllTimeBest))
                row("Streak", store.liveBakeOffStreak == 1 ? "1 day" : "\(store.liveBakeOffStreak) days")
            }
            .padding(14).plaque()
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("bakeoff_records")
            Button("Start today's Bake-Off", action: onStart)
                .buttonStyle(CandyButtonStyle())
                .accessibilityIdentifier("bakeoff_start")
            Text("No coins are spent or won in the Bake-Off.").font(Theme.body(12)).foregroundStyle(Theme.ink.opacity(0.7))
        }
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title).font(Theme.body(15)).foregroundStyle(Theme.ink)
            Spacer()
            Text(value).font(Theme.display(16)).foregroundStyle(Theme.ink)
        }
    }
}
