import SwiftUI
import WebKit

struct TopPlayersSheet: View {
    @ObservedObject var store: ProfileStore
    @ObservedObject var online: OnlinePlayerService
    let onClose: () -> Void
    @Environment(\.openURL) private var openURL
    @State private var category: LeaderboardCategory = .bestRound
    @State private var confirmLeave = false

    var body: some View {
        TopPlayersWebPage(payload: [
            "name": store.playerName,
            "joined": online.hasConsent,
            "loading": online.isLoading,
            "joining": online.isJoining,
            "message": online.message ?? "",
            "selected": category.title,
            "categories": LeaderboardCategory.allCases.map(\.title),
            "players": online.players.map {
                ["name": $0.name, "score": category.format($0.value(for: category))]
            }
        ], action: handle)
        .background(Theme.cream.ignoresSafeArea())
        .screenID("top_players_sheet")
        .preferredColorScheme(.light)
        .task {
            if online.hasConsent { await refresh() }
        }
        .confirmationDialog("Leave TOP PLAYERS?", isPresented: $confirmLeave, titleVisibility: .visible) {
            Button("Remove my online profile", role: .destructive) { Task { await online.leaveLeaderboard() } }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Your online leaderboard profile and saved scores will be removed. Local game progress stays on this iPhone.")
        }
    }

    private func refresh() async {
        await online.refresh(category: category, day: store.todayBakeOff.key)
    }

    private func handle(_ action: String, _ value: String) {
        switch action {
        case "close":
            onClose()
        case "privacy":
            if let url = URL(string: "https://sugarloopfair.website/#privacy") { openURL(url) }
        case "join":
            guard !online.hasConsent, !online.isJoining else { return }
            category = .bestRound
            store.setPlayerName(value)
            Task { await online.enableLeaderboard(name: store.playerName, snapshot: store.snapshot()) }
        case "save":
            guard online.hasConsent, !online.isJoining else { return }
            store.setPlayerName(value)
            Task {
                await online.updateName(store.playerName)
                await refresh()
            }
        case "category":
            guard !online.isLoading, !online.isJoining,
                  let selection = LeaderboardCategory.allCases.first(where: { $0.title == value }),
                  selection != category else { return }
            category = selection
            Task { await refresh() }
        case "refresh":
            Task { await refresh() }
        case "leave":
            confirmLeave = online.hasConsent
        default:
            break
        }
    }
}

private struct TopPlayersWebPage: UIViewRepresentable {
    let payload: [String: Any]
    let action: (String, String) -> Void

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.userContentController.add(context.coordinator, name: "leaderboard")
        let web = WKWebView(frame: .zero, configuration: configuration)
        web.navigationDelegate = context.coordinator
        web.loadHTMLString(Self.html, baseURL: nil)
        return web
    }

    func updateUIView(_ web: WKWebView, context: Context) {
        context.coordinator.action = action
        context.coordinator.payload = payload
        context.coordinator.render(in: web)
    }

    static func dismantleUIView(_ web: WKWebView, coordinator: Coordinator) {
        web.configuration.userContentController.removeScriptMessageHandler(forName: "leaderboard")
        web.navigationDelegate = nil
        coordinator.action = nil
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        var action: ((String, String) -> Void)?
        var payload: [String: Any] = [:]
        private var ready = false

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            ready = true
            render(in: webView)
        }

        func render(in web: WKWebView) {
            guard ready else { return }
            web.callAsyncJavaScript("window.renderLeaderboard(payload)", arguments: ["payload": payload],
                                    in: nil, in: .page, completionHandler: nil)
        }

        func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.frameInfo.isMainFrame, let body = message.body as? [String: String],
                  let command = body["action"] else { return }
            action?(command, body["value"] ?? "")
        }
    }

    private static let html = #"""
    <!doctype html>
    <html lang="en"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      * { box-sizing: border-box; }
      [hidden] { display: none !important; }
      body { margin: 0; background: #fff2d8; color: #512144; font: 600 16px -apple-system, sans-serif; }
      main { max-width: 600px; margin: auto; padding: 20px 16px; }
      header, form, .bar { display: flex; gap: 12px; align-items: center; }
      header, .bar { justify-content: space-between; }
      h1 { font-size: 27px; margin: 0; }
      h2 { font-size: 20px; }
      button, input { font: inherit; color: inherit; min-height: 44px; }
      button { border: 2px solid; border-radius: 24px; background: #fffaf0; padding: 8px 14px; }
      button:disabled { opacity: .55; }
      input { min-width: 0; flex: 1; padding: 10px; background: #fffaf0; border: 2px solid; border-radius: 12px; }
      form { margin: 18px 0; }
      #submit { background: #36dbac; font-weight: 800; }
      nav { display: flex; gap: 8px; overflow-x: auto; padding-bottom: 4px; }
      nav button { flex: none; font-size: 14px; }
      nav button[aria-pressed=true] { background: #c61654; color: white; border-color: #512144; }
      #refresh, #status { background: #ffdd45; }
      #status { border-radius: 12px; padding: 12px; text-align: center; }
      ol { padding: 0; list-style: none; display: grid; gap: 8px; }
      li { display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 10px; padding: 12px;
           background: #fffaf0; border: 2px solid; border-radius: 14px; overflow-wrap: anywhere; }
      li:first-child { background: #ffed9a; }
      .link { display: block; margin: 10px auto; border: 0; background: transparent; color: #a41648; }
    </style></head><body><main>
      <header><h1>🏅 TOP PLAYERS</h1><button id="close" aria-label="Close">✕</button></header>
      <section id="consent" hidden>
        <h2>Join the fair standings</h2>
        <p>Your fair name, a device-scoped player ID, and leaderboard totals are sent to Sugarloop Fair’s online service when you join and when a round ends. You can keep playing without joining.</p>
      </section>
      <form id="profile" hidden>
        <input id="name" maxlength="32" aria-label="Your fair name" placeholder="Your fair name" autocapitalize="words">
        <button id="submit" type="submit">Save</button>
      </form>
      <section id="board" hidden>
        <nav id="categories" aria-label="Leaderboard categories"></nav>
        <div class="bar"><h2 id="category"></h2><button id="refresh" aria-label="Refresh TOP PLAYERS">↻</button></div>
        <ol id="players"></ol>
      </section>
      <p id="status" role="status" aria-live="polite">Loading the fair board…</p>
      <button id="privacy" class="link" hidden>Read the privacy notice</button>
      <button id="leave" class="link" hidden>Leave TOP PLAYERS</button>
    </main><script>
      const element = id => document.getElementById(id);
      const send = (action, value = '') => window.webkit.messageHandlers.leaderboard.postMessage({ action, value });
      let joined = false;
      let lastName;
      let categoryButtons = [];
      for (const action of ['close', 'refresh', 'privacy', 'leave']) {
        element(action).onclick = () => send(action);
      }
      element('profile').onsubmit = event => {
        event.preventDefault();
        send(joined ? 'save' : 'join', element('name').value);
      };
      window.renderLeaderboard = data => {
        joined = data.joined;
        const busy = data.loading || data.joining;
        element('profile').hidden = false;
        element('consent').hidden = element('privacy').hidden = joined;
        element('board').hidden = element('leave').hidden = !joined;
        if (lastName !== data.name) {
          element('name').value = data.name;
          lastName = data.name;
        }
        element('submit').textContent = data.joining ? 'Joining…' : joined ? 'Save' : 'Join TOP PLAYERS';
        element('submit').disabled = busy;
        element('refresh').disabled = busy;
        if (!categoryButtons.length) {
          categoryButtons = data.categories.map(title => {
            const button = document.createElement('button');
            button.textContent = title;
            button.onclick = () => send('category', title);
            element('categories').append(button);
            return button;
          });
        }
        for (const button of categoryButtons) {
          button.disabled = busy;
          button.setAttribute('aria-pressed', String(button.textContent === data.selected));
        }
        element('category').textContent = data.selected;
        const rows = joined && !busy ? data.players : [];
        element('players').replaceChildren(...rows.map((player, index) => {
          const row = document.createElement('li');
          for (const value of [index + 1, player.name, player.score]) {
            const cell = document.createElement('span');
            cell.textContent = value;
            row.append(cell);
          }
          return row;
        }));
        const status = busy ? 'Loading the fair board…' :
          data.message || (joined && !rows.length ? 'No players yet. Finish a round to join the board.' : '');
        element('status').textContent = status;
        element('status').hidden = !status;
      };
    </script></body></html>
    """#
}
