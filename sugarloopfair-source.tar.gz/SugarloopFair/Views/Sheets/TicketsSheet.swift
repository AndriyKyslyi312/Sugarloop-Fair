import SwiftUI

struct TicketsSheet: View {
    @ObservedObject var store: ProfileStore
    let onClose: () -> Void

    private func art(_ a: Achievement) -> String {
        switch a {
        case .firstWin: "sym_mint"
        case .bigWin: "sym_honey"
        case .megaWin: "sym_tart"
        case .chain5: "sym_lemon"
        case .stampede: "sym_bear"
        case .cannonFire: "icon_cannon"
        case .jamSmash: "tile_jam"
        case .sweetTooth: "sym_lollipop"
        case .fairRun: "sym_frog"
        case .sprinkleStorm: "sym_sprinkle"
        case .regular: "sym_fox"
        case .orderRunner: "customer_baker"
        case .bakeOffEntrant: "icon_cake"
        case .rankCaptain: "rank_rosette"
        }
    }

    var body: some View {
        let p = store.profile
        SheetScaffold(title: "Tickets", art: "stall_tickets", identifier: "tickets_sheet", onClose: onClose) {
            FairCard(snapshot: store.snapshot(), points: p.sugarPoints)

            VStack(spacing: 8) {
                stat("Moves played", "\(p.totalSpins)")
                stat("Rounds finished", "\(p.roundsPlayed)")
                stat("Best match score", Formatters.coins(p.biggestWin))
                stat("Best score multiple", String(format: "x%.1f", Double(p.bestMultipleTimes10) / 10))
                stat("Longest cascade chain", "\(p.bestCascadeChain)")
                stat("Sticky jam cells cleared", "\(p.jamHits)")
                stat("Gummy stampedes", "\(p.stampedes)")
                stat("Cannon shots", "\(p.cannonShots)")
                stat("Bake-Off days played", "\(p.bakeOffDaysPlayed)")
            }
            .padding(14)
            .plaque()
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("stats_card")

            Text("Rosettes").font(Theme.display(22)).foregroundStyle(Theme.ink)
                .frame(maxWidth: .infinity, alignment: .leading)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 10)], spacing: 10) {
                ForEach(Achievement.current) { a in
                    let earned = a.isEarned(by: p)
                    VStack(spacing: 4) {
                        Image(art(a)).resizable().scaledToFit().frame(height: 52)
                            .saturation(earned ? 1 : 0).opacity(earned ? 1 : 0.4)
                        Text(a.title).font(Theme.display(14)).foregroundStyle(Theme.ink).multilineTextAlignment(.center)
                        Text(a.detail).font(Theme.body(11)).foregroundStyle(Theme.ink.opacity(0.75)).multilineTextAlignment(.center)
                    }
                    .padding(10)
                    .frame(maxWidth: .infinity, minHeight: 130)
                    .plaque(tint: earned ? Theme.lemon.opacity(0.7) : Theme.paper, radius: 16)
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("\(a.title). \(a.detail)")
                    .accessibilityValue(earned ? "Earned" : "Locked")
                }
            }

            Text("Recent tickets").font(Theme.display(22)).foregroundStyle(Theme.ink)
                .frame(maxWidth: .infinity, alignment: .leading).padding(.top, 6)
            let records = store.recentRecords(limit: 12)
            if records.isEmpty {
                Text("Your match results will be stamped here.").font(Theme.body(14)).foregroundStyle(Theme.ink.opacity(0.75))
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            ForEach(Array(records.enumerated()), id: \.offset) { _, r in
                HStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Text("Move cost \(Formatters.coins(r.bet))").font(Theme.body(14)).foregroundStyle(Theme.ink)
                        Text("\(r.cascades) cascades").font(Theme.body(12)).foregroundStyle(Theme.ink.opacity(0.7))
                    }
                    Spacer()
                    Text(r.payout > 0 ? "+\(Formatters.coins(r.payout))" : "0")
                        .font(Theme.display(18)).foregroundStyle(r.payout > 0 ? Theme.mintDeep : Theme.ink.opacity(0.6))
                }
                .padding(.horizontal, 14).padding(.vertical, 8)
                .plaque(radius: 12)
            }
        }
    }

    private func stat(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title).font(Theme.body(15)).foregroundStyle(Theme.ink)
            Spacer()
            Text(value).font(Theme.display(16)).foregroundStyle(Theme.ink)
        }
    }
}

/// The player's card: exactly the numbers a TOP PLAYERS board will compare.
struct FairCard: View {
    let snapshot: LeaderboardSnapshot
    let points: Int

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                Image("rank_rosette").resizable().scaledToFit().frame(width: 58, height: 58).accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 3) {
                    Text(snapshot.playerName).font(Theme.display(22)).foregroundStyle(Theme.ink).lineLimit(1).minimumScaleFactor(0.7)
                    Text("Rank \(snapshot.rankLevel + 1) · \(snapshot.rankTitle)").font(Theme.body(14)).foregroundStyle(Theme.ink)
                    RankBar(points: points).frame(height: 10)
                }
            }
            ForEach(LeaderboardCategory.allCases) { category in
                HStack {
                    Text(category.title).font(Theme.body(14)).foregroundStyle(Theme.ink)
                    Spacer()
                    Text(category.format(snapshot.value(category))).font(Theme.display(15)).foregroundStyle(Theme.ink)
                }
                .accessibilityElement(children: .combine)
            }
        }
        .padding(14)
        .plaque(tint: Theme.lemon.opacity(0.45))
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("fair_card")
    }
}

/// Progress towards the next fair rank.
struct RankBar: View {
    let points: Int

    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule().fill(Theme.ink.opacity(0.15))
                Capsule().fill(LinearGradient(colors: [Theme.mint, Theme.mintDeep], startPoint: .leading, endPoint: .trailing))
                    .frame(width: max(8, proxy.size.width * FairRank.progress(for: points)))
            }
            .overlay(Capsule().strokeBorder(Theme.ink, lineWidth: 1.5))
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Rank progress")
        .accessibilityValue("\(Int(FairRank.progress(for: points) * 100)) percent")
    }
}
