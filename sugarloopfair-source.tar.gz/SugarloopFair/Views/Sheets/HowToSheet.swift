import SwiftUI

struct HowToSheet: View {
    let onClose: () -> Void

    private struct Page: Identifiable {
        let id: String
        let title: String
        let art: String
        let text: String
    }

    private let pages: [Page] = [
        Page(id: "swap", title: "Swipe to match", art: "mech_match",
             text: "Swipe a candy onto its neighbour, or tap one and then the other. Line up a connected group of 3 or more to score. Swaps that make nothing slide back for free."),
        Page(id: "cascade", title: "Syrup Tide combos", art: "mech_syrup",
             text: "Matched candies pop, the rest tumble down and new ones drop in. Each extra cascade from one move raises the Syrup Tide and scores up to x3."),
        Page(id: "swirl", title: "Lollipop Swirl", art: "sym_lollipop",
             text: "Swap a lollipop with any candy to clear every candy of that kind on the board. Save it for the kind you have most of."),
        Page(id: "stampede", title: "Gummy Stampede", art: "mech_stampede",
             text: "Match 4 or more gummies of one kind and the herd tramples its whole row. Build gummy groups on purpose."),
        Page(id: "jam", title: "Sticky Jam & Sprinkles", art: "mech_jam",
             text: "Popped cells leave jam: a later match on jam scores x1.5. Sprinkles on the board when a move ends multiply its whole score."),
        Page(id: "cannon", title: "Candy Cannon", art: "mech_cannon",
             text: "Cascades charge the cannon. When it's full, tap Fire cannon, then any candy: its column is blasted away for free and the tumble that follows still scores."),
        Page(id: "rush", title: "Sugar Rush", art: "mech_meter",
             text: "Every cascade fills the Sweet Tooth Meter. When it's full, start a Sugar Rush: 3 free moves that score x1.5."),
        Page(id: "orders", title: "Fair-goer Orders", art: "mech_orders",
             text: "Three visitors want something special: a big match, a long combo, a swirl or a stampede. Serve orders for bonus coins and Sugar Points that raise your fair rank."),
        Page(id: "bakeoff", title: "Daily Bake-Off", art: "mech_bakeoff",
             text: "Once a day everyone gets the same board and the same drops. 15 free moves, 100 points per move cost scored. Beat your best and keep your streak."),
        Page(id: "round", title: "Rounds", art: "rank_rosette",
             text: "A round is 20 moves. Each move costs coins and scores coins, so plan the big ones. Virtual coins only: no real money, no prizes.")
    ]

    var body: some View {
        SheetScaffoldPaged(title: "How to play", art: "stall_howto", identifier: "howto_sheet", onClose: onClose) {
            TabView {
                ForEach(pages) { page in
                    VStack(spacing: 14) {
                        Image(page.art).resizable().scaledToFit().frame(maxHeight: 260).accessibilityHidden(true)
                        Text(page.title).font(Theme.display(26)).foregroundStyle(Theme.ink)
                        Text(page.text).font(Theme.body(16)).foregroundStyle(Theme.ink).multilineTextAlignment(.center)
                            .padding(16).plaque()
                        Spacer(minLength: 0)
                    }
                    .padding(.horizontal, 20).padding(.top, 8)
                    .tag(page.id)
                }
                payTablePage.tag("paytable")
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            .indexViewStyle(.page(backgroundDisplayMode: .always))
        }
    }

    private var payTablePage: some View {
        ScrollView {
            VStack(spacing: 8) {
                Text("Pay table").font(Theme.display(26)).foregroundStyle(Theme.ink)
                Text("Multiples of the move cost for connected groups of \(PayTable.matchTierLabels.joined(separator: " / ")) candies.")
                    .font(Theme.body(13)).foregroundStyle(Theme.ink.opacity(0.8)).multilineTextAlignment(.center)
                ForEach(Symbol.payingSymbols.reversed(), id: \.self) { symbol in
                    HStack(spacing: 10) {
                        Image(symbol.assetName).resizable().scaledToFit().frame(width: 38, height: 38).accessibilityHidden(true)
                        Text(symbol.displayName).font(Theme.body(14)).foregroundStyle(Theme.ink).frame(width: 96, alignment: .leading)
                        Spacer(minLength: 0)
                        Text(PayTable.matchRows(for: symbol).map { Self.format($0) }.joined(separator: "  "))
                            .font(.system(size: 12, weight: .bold, design: .monospaced)).foregroundStyle(Theme.ink)
                    }
                    .padding(.horizontal, 12).padding(.vertical, 4).plaque(radius: 12)
                }
                Text("Virtual coins only. No real money.")
                    .font(Theme.body(12)).foregroundStyle(Theme.ink.opacity(0.8)).padding(.top, 6)
                Color.clear.frame(height: 34)
            }
            .padding(.horizontal, 16).padding(.top, 8)
        }
    }

    private static func format(_ v: Double) -> String {
        v >= 10 ? String(format: "%.0f", v) : String(format: "%.2g", v)
    }
}

/// Like SheetScaffold, but the body manages its own scrolling (paged content).
struct SheetScaffoldPaged<Content: View>: View {
    let title: String
    let art: String
    let identifier: String
    let onClose: () -> Void
    @ViewBuilder var content: Content

    var body: some View {
        VStack(spacing: 0) {
            SheetHeader(title: title, art: art, onClose: onClose)
            content
        }
        .background(Theme.cream.ignoresSafeArea())
        .screenID(identifier)
        .preferredColorScheme(.light)
    }
}
