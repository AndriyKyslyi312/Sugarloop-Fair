import SwiftUI

struct SettingsSheet: View {
    @ObservedObject var store: ProfileStore
    @ObservedObject var settings: SettingsStore
    let onClose: () -> Void
    @State private var confirmReset = false
    @State private var name: String

    init(store: ProfileStore, settings: SettingsStore, onClose: @escaping () -> Void) {
        _store = ObservedObject(wrappedValue: store)
        _settings = ObservedObject(wrappedValue: settings)
        self.onClose = onClose
        self.name = store.playerName
    }

    var body: some View {
        SheetScaffold(title: "Settings", art: "stall_settings", identifier: "settings_sheet", onClose: onClose) {
            VStack(alignment: .leading, spacing: 6) {
                Text("Fair name").font(Theme.display(18)).foregroundStyle(Theme.ink)
                Text("Shown on your fair card and on future leaderboards.").font(Theme.body(12)).foregroundStyle(Theme.ink.opacity(0.75))
                TextField("Your name", text: Binding(get: { name }, set: { name = String($0.prefix(ProfileStore.nameLimit)) }))
                    .font(Theme.body(17))
                    .foregroundStyle(Theme.ink)
                    .textInputAutocapitalization(.words)
                    .autocorrectionDisabled()
                    .submitLabel(.done)
                    .padding(.horizontal, 12)
                    .frame(minHeight: Theme.minTarget)
                    .background(RoundedRectangle(cornerRadius: 12).fill(Theme.cream))
                    .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(Theme.ink, lineWidth: 2))
                    .onSubmit(commitName)
                    .accessibilityIdentifier("player_name")
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14).plaque()

            VStack(spacing: 4) {
                toggle("Sound effects", $settings.soundEnabled, AccessibilityID.soundToggle)
                toggle("Haptics", $settings.hapticsEnabled, AccessibilityID.hapticsToggle)
                toggle("Quick matches", $settings.quickSpin, AccessibilityID.quickToggle)
            }
            .padding(14).plaque()

            VStack(alignment: .leading, spacing: 8) {
                Text("About").font(Theme.display(18)).foregroundStyle(Theme.ink)
                Text("Sugarloop Fair is a puzzle game played with virtual coins for entertainment only. Coins cannot be bought, cashed out or exchanged for anything of real value.")
                    .font(Theme.body(14)).foregroundStyle(Theme.ink)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14).plaque()

            Button("Reset progress") { confirmReset = true }
                .buttonStyle(CandyButtonStyle(fill: Theme.grape, deep: Color(hex: 0x6B44A8)))
                .accessibilityIdentifier(AccessibilityID.resetButton)
        }
        .onDisappear(perform: commitName)
        .confirmationDialog("Reset all progress?", isPresented: $confirmReset, titleVisibility: .visible) {
            Button("Reset everything", role: .destructive) { store.resetProgress() }
                .accessibilityIdentifier(AccessibilityID.resetConfirm)
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Your coins, stats and rosettes will be erased. Your fair name stays.")
        }
    }

    private func commitName() {
        store.setPlayerName(name)
        name = store.playerName
    }

    private func toggle(_ title: String, _ binding: Binding<Bool>, _ id: String) -> some View {
        Toggle(isOn: binding) {
            Text(title).font(Theme.body(17)).foregroundStyle(Theme.ink)
        }
        .tint(Theme.mintDeep)
        .frame(minHeight: Theme.minTarget)
        .accessibilityIdentifier(id)
    }
}
