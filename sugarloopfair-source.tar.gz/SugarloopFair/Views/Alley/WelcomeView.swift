import SwiftUI

/// First-launch screen: what the game is and that coins are virtual.
struct WelcomeView: View {
    let onStart: () -> Void

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                Image("logo_wordmark").resizable().scaledToFit().frame(maxWidth: 320).padding(.top, 30)
                    .accessibilityLabel("Sugarloop Fair")
                VStack(alignment: .leading, spacing: 12) {
                    point("sym_lollipop", "Choose two neighboring candies and swap them to make a match.")
                    point("sym_sprinkle", "Connected groups of 3 or more pop and start cascading drops.")
                    point("sym_bear", "Plan your swaps to earn the most points in 20 moves.")
                }
                .padding(16)
                .plaque()
                Text("Sugarloop Fair is a puzzle game with virtual coins for entertainment only. Coins have no cash value and cannot be bought, cashed out or exchanged for real money.")
                    .font(Theme.body(14))
                    .foregroundStyle(Theme.ink)
                    .padding(14)
                    .plaque(tint: Theme.lemon.opacity(0.85), radius: 16)
                Button("Enter the fair", action: onStart)
                    .buttonStyle(CandyButtonStyle())
                    .accessibilityIdentifier(AccessibilityID.welcomeStart)
                    .padding(.bottom, 30)
            }
            .padding(.horizontal, 20)
            .frame(maxWidth: 560)
            .frame(maxWidth: .infinity)
        }
        .artBackground("bg_fair_day")
        .preferredColorScheme(.light)
    }

    private func point(_ art: String, _ text: String) -> some View {
        HStack(spacing: 12) {
            Image(art).resizable().scaledToFit().frame(width: 44, height: 44).accessibilityHidden(true)
            Text(text).font(Theme.body(16)).foregroundStyle(Theme.ink)
        }
    }
}
