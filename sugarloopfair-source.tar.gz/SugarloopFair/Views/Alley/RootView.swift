import SwiftUI

enum AlleySheet: String, Identifiable {
    case jars, booths, tickets, howto, settings, bakeOff, topPlayers
    var id: String { rawValue }
}

/// What the full-screen game cover should open.
struct GameLaunch: Identifiable {
    let id = UUID()
    let mode: GameMode
}

/// The fairground alley: one stall per section, walked top to bottom.
struct RootView: View {
    let dependencies: AppDependencies
    @ObservedObject private var store: ProfileStore
    @ObservedObject private var online: OnlinePlayerService
    @State private var sheet: AlleySheet?
    @State private var launch: GameLaunch?
    @State private var pendingLaunch: GameLaunch?
    @State private var showWelcome: Bool

    init(dependencies: AppDependencies) {
        self.dependencies = dependencies
        _store = ObservedObject(wrappedValue: dependencies.store)
        _online = ObservedObject(wrappedValue: dependencies.online)
        self.showWelcome = !dependencies.store.welcomeSeen
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 18) {
                header
                playStall
                StallRow(art: "stall_bakeoff", title: "Bake-Off", detail: bakeOffDetail, id: AccessibilityID.stallBakeOff, side: .trailing) { sheet = .bakeOff }
                StallRow(art: "stall_jars", title: "Candy Jars", detail: "Free coin refills", id: AccessibilityID.stallJars, side: .leading) { sheet = .jars }
                StallRow(art: "stall_booths", title: "Booths", detail: "Pick your board glaze", id: AccessibilityID.stallBooths, side: .trailing) { sheet = .booths }
                StallRow(art: "stall_tickets", title: "Tickets", detail: "Stats and rosettes", id: AccessibilityID.stallTickets, side: .leading) { sheet = .tickets }
                StallRow(art: "rank_rosette", title: "TOP PLAYERS", detail: "Fair standings", id: "stall_top_players", side: .trailing) { sheet = .topPlayers }
                StallRow(art: "stall_howto", title: "How to play", detail: "Swaps, swirls and stampedes", id: AccessibilityID.stallHowTo, side: .trailing) { sheet = .howto }
                StallRow(art: "stall_settings", title: "Settings", detail: "Sound, haptics, reset", id: AccessibilityID.stallSettings, side: .leading) { sheet = .settings }
                Text("Virtual coins only. No real money or prizes.")
                    .font(Theme.body(13))
                    .foregroundStyle(Theme.ink)
                    .padding(.horizontal, 14).padding(.vertical, 6)
                    .plaque(radius: 14)
                    .padding(.top, 6)
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 40)
            .frame(maxWidth: Theme.maxContentWidth)
            .frame(maxWidth: .infinity)
        }
        .artBackground("bg_fair_day")
        .screenID(AccessibilityID.alley)
        .sheet(item: $sheet, onDismiss: {
            if let pending = pendingLaunch {
                pendingLaunch = nil
                launch = pending
            }
        }) { item in
            sheetContent(item)
                .sheetSize(allowsMedium: !(item == .howto || item == .bakeOff))
        }
        .fullScreenCover(item: $launch) { item in
            GameView(dependencies: dependencies, mode: item.mode) { launch = nil }
        }
        .fullScreenCover(isPresented: $showWelcome) {
            WelcomeView {
                store.markWelcomeSeen()
                showWelcome = false
            }
        }
        .preferredColorScheme(.light)
        .onChange(of: store.playerName) { name in
            guard online.hasConsent else { return }
            Task { await online.updateName(name) }
        }
        .onAppear {
            // Tour helper: jump straight into a board for screenshots.
            guard dependencies.isUITesting else { return }
            let args = ProcessInfo.processInfo.arguments
            if args.contains("--open-game"), launch == nil {
                launch = GameLaunch(mode: .classic)
            } else if args.contains("--open-bakeoff-game"), launch == nil {
                launch = GameLaunch(mode: .bakeOff(store.todayBakeOff))
            } else if let raw = args.first(where: { $0.hasPrefix("--open-sheet=") }),
                      let item = AlleySheet(rawValue: String(raw.dropFirst("--open-sheet=".count))) {
                sheet = item
            }
        }
    }

    private var header: some View {
        VStack(spacing: 6) {
            HStack(spacing: 10) {
                CoinBadge(amount: store.coins)
                Spacer(minLength: 0)
                rankBadge
            }
            Image("logo_wordmark")
                .resizable().scaledToFit()
                .frame(maxWidth: 340)
                .padding(.top, 14)
                .accessibilityLabel("Sugarloop Fair")
        }
        .padding(.top, 36)
    }

    private var bakeOffDetail: String {
        let best = store.bakeOffBest(for: store.todayBakeOff)
        return best > 0 ? "Today's best: \(Formatters.coins(best))" : "Same board for everyone"
    }

    private var rankBadge: some View {
        let points = store.profile.sugarPoints
        return HStack(spacing: 6) {
            Image("rank_rosette").resizable().scaledToFit().frame(width: 34, height: 34)
            VStack(alignment: .leading, spacing: 3) {
                Text(store.rankTitle).font(Theme.display(13)).foregroundStyle(Theme.ink).lineLimit(1).minimumScaleFactor(0.7)
                RankBar(points: points).frame(width: 96, height: 8)
            }
        }
        .padding(.horizontal, 10)
        .frame(minHeight: Theme.minTarget)
        .plaque(radius: 22)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Fair rank: \(store.rankTitle)")
        .accessibilityValue("\(Formatters.coins(points)) Sugar Points")
        .accessibilityIdentifier("rank_badge")
    }

    private var playStall: some View {
        Button { launch = GameLaunch(mode: .classic) } label: {
            VStack(spacing: 4) {
                Image("stall_play").resizable().scaledToFit().frame(width: 230, height: 230)
                Text("PLAY")
                    .font(Theme.display(34))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 44)
                    .frame(minHeight: 64)
                    .background(Capsule().fill(LinearGradient(colors: [Theme.raspberry, Theme.raspberryDeep], startPoint: .top, endPoint: .bottom)))
                    .overlay(Capsule().strokeBorder(Theme.ink, lineWidth: 4))
                    .shadow(color: Theme.ink.opacity(0.22), radius: 3, x: 0, y: 3)
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Play")
        .accessibilityIdentifier(AccessibilityID.stallPlay)
    }

    @ViewBuilder
    private func sheetContent(_ item: AlleySheet) -> some View {
        switch item {
        case .jars: JarsSheet(store: store) { sheet = nil }
        case .booths: BoothsSheet(store: store) { sheet = nil }
        case .tickets: TicketsSheet(store: store) { sheet = nil }
        case .topPlayers: TopPlayersSheet(store: store, online: dependencies.online) { sheet = nil }
        case .howto: HowToSheet { sheet = nil }
        case .settings: SettingsSheet(store: store, settings: dependencies.settings) { sheet = nil }
        case .bakeOff:
            BakeOffSheet(store: store) {
                pendingLaunch = GameLaunch(mode: .bakeOff(store.todayBakeOff))
                sheet = nil
            } onClose: { sheet = nil }
        }
    }
}

struct StallRow: View {
    enum Side { case leading, trailing }

    let art: String
    let title: String
    let detail: String
    let id: String
    let side: Side
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                if side == .leading { image; sign } else { sign; image }
            }
            .frame(maxWidth: .infinity, alignment: side == .leading ? .leading : .trailing)
            .padding(side == .leading ? .trailing : .leading, 30)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(title)
        .accessibilityHint(detail)
        .accessibilityIdentifier(id)
    }

    private var image: some View {
        Image(art).resizable().scaledToFit().frame(width: 150, height: 150)
    }

    private var sign: some View {
        VStack(alignment: side == .leading ? .leading : .trailing, spacing: 2) {
            Text(title).font(Theme.display(22)).foregroundStyle(Theme.ink)
            Text(detail).font(Theme.body(14)).foregroundStyle(Theme.ink.opacity(0.8))
        }
        .multilineTextAlignment(side == .leading ? .leading : .trailing)
        .padding(.horizontal, 14).padding(.vertical, 10)
        .plaque(radius: 16)
    }
}
