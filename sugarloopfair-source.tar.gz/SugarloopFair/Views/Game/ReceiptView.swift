import SwiftUI

/// A match result printed like a paper fair ticket.
struct ReceiptView: View {
    let receipt: SpinReceipt
    let onClose: () -> Void

    var body: some View {
        VStack(spacing: 14) {
            Image("logo_wordmark").resizable().scaledToFit().frame(height: 64).accessibilityHidden(true)
            Text(receipt.newRankTitle != nil ? "RANK UP RECEIPT" : (receipt.orders.isEmpty ? "BEST MOVE RECEIPT" : "ORDER RECEIPT"))
                .font(Theme.display(18)).foregroundStyle(Theme.ink)
            dashed
            VStack(spacing: 8) {
                if receipt.bet > 0 { line("Move cost", Formatters.coins(receipt.bet)) }
                line("Match score", Formatters.coins(receipt.basePayout))
                line("Cascades", "\(receipt.cascades)")
                if receipt.stampedes > 0 { line("Gummy stampedes", "\(receipt.stampedes)") }
                if receipt.bombTotal > 0 { line("Sprinkles", "x\(receipt.bombTotal)") }
                if receipt.usedCannon { line("Candy Cannon", "fired") }
                ForEach(receipt.orders) { order in
                    HStack(spacing: 8) {
                        Image(order.customer.assetName).resizable().scaledToFit().frame(width: 28, height: 28)
                        Text("\(order.customer.name): \(order.goal.text)").font(Theme.body(14)).foregroundStyle(Theme.ink)
                            .lineLimit(1).minimumScaleFactor(0.7)
                        Spacer()
                    }
                }
                if receipt.orderCoins > 0 { line("Order bonus", "+\(Formatters.coins(receipt.orderCoins))") }
                if receipt.sugarPoints > 0 { line("Sugar Points", "+\(receipt.sugarPoints)") }
            }
            dashed
            HStack {
                Text("TOTAL").font(Theme.display(22)).foregroundStyle(Theme.ink)
                Spacer()
                Text(Formatters.coins(receipt.total))
                    .font(Theme.display(32)).foregroundStyle(Theme.raspberryDeep)
                    .minimumScaleFactor(0.6).lineLimit(1)
                    .accessibilityIdentifier("receipt_total")
            }
            if let rank = receipt.newRankTitle {
                HStack(spacing: 8) {
                    Image("rank_rosette").resizable().scaledToFit().frame(width: 36, height: 36)
                    Text("New rank: \(rank)").font(Theme.display(17)).foregroundStyle(Theme.ink)
                }
                .padding(.horizontal, 14).padding(.vertical, 6)
                .background(Capsule().fill(Theme.mint))
                .accessibilityIdentifier("receipt_rank_up")
            }
            ForEach(receipt.rosettes) { rosette in
                Text("Rosette: \(rosette.title)").font(Theme.body(14)).foregroundStyle(Theme.ink)
                    .padding(.horizontal, 12).padding(.vertical, 4)
                    .background(Capsule().fill(Theme.lemon))
            }
            Spacer(minLength: 0)
            Button("Collect") { onClose() }
                .buttonStyle(CandyButtonStyle())
                .accessibilityIdentifier(AccessibilityID.receiptClose)
        }
        .padding(20)
        .frame(maxWidth: 520)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Theme.paper.ignoresSafeArea())
        .screenID(AccessibilityID.receipt)
        .preferredColorScheme(.light)
    }

    private var dashed: some View {
        Rectangle()
            .stroke(Theme.ink.opacity(0.5), style: StrokeStyle(lineWidth: 2, dash: [8, 6]))
            .frame(height: 1)
    }

    private func line(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title).font(Theme.body(16)).foregroundStyle(Theme.ink)
            Spacer()
            Text(value).font(Theme.display(16)).foregroundStyle(Theme.ink)
        }
    }
}
