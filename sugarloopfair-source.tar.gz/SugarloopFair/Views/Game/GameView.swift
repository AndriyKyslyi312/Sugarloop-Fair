import SwiftUI

struct GameView: View {
    @StateObject private var vm: GameViewModel
    @ObservedObject private var store: ProfileStore
    private let onClose: () -> Void

    init(dependencies: AppDependencies, mode: GameMode = .classic, onClose: @escaping () -> Void) {
        _vm = StateObject(wrappedValue: GameViewModel(dependencies: dependencies, mode: mode))
        _store = ObservedObject(wrappedValue: dependencies.store)
        self.onClose = onClose
    }

    var body: some View {
        VStack(spacing: 8) {
            hud
            if vm.isBakeOff { bakeOffStrip } else { OrdersStrip(orders: vm.store.orders, bet: vm.bet) }
            statusStrip
            Spacer(minLength: 0)
            BoardView(vm: vm, booth: vm.store.booth)
            Spacer(minLength: 0)
            if !vm.isBakeOff { powerRow }
            if !vm.isBakeOff { betControl }
        }
        .padding(.horizontal, 12)
        .padding(.top, 6)
        .padding(.bottom, 10)
        .frame(maxWidth: 560)
        .frame(maxWidth: .infinity)
        .artBackground(vm.rushMoves > 0 ? "bg_fair_dusk" : "bg_fair_day")
        .animation(.easeInOut(duration: 0.5), value: vm.rushMoves > 0)
        .overlay(alignment: .top) {
            if let toast = vm.toast {
                ToastView(text: toast)
                    .padding(.top, 64)
                    .task(id: toast) {
                        try? await Task.sleep(ms: 3200)
                        if vm.toast == toast { withAnimation { vm.toast = nil } }
                    }
            }
        }
        .overlay {
            if let win = vm.bigWin {
                BigWinOverlay(win: win) { vm.dismissBigWin() }
                    .transition(.opacity.combined(with: .scale(scale: 1.1)))
            }
        }
        .animation(.candy(0.35), value: vm.toast)
        .animation(.candy(0.4), value: vm.bigWin)
        .sheet(item: $vm.receipt) { receipt in
            ReceiptView(receipt: receipt) { vm.receipt = nil }
                .sheetSize(allowsMedium: true)
        }
        .sheet(item: $vm.roundSummary) { summary in
            RoundSummaryView(summary: summary, rankPoints: vm.store.profile.sugarPoints) {
                vm.roundSummary = nil
                vm.newBoard()
            } onExit: {
                vm.roundSummary = nil
                vm.close()
                onClose()
            }
            .sheetSize(allowsMedium: false)
            .interactiveDismissDisabled()
        }
        .overlay(alignment: .topLeading) {
            // Machine-readable state for UI tests and assistive tech: Ready, Busy, Round complete or Done.
            Color.clear.frame(width: 1, height: 1)
                .accessibilityElement()
                .accessibilityLabel("Game state")
                .accessibilityValue(stateText)
                .accessibilityIdentifier("game_state")
        }
        .screenID(AccessibilityID.gameScreen)
        .preferredColorScheme(.light)
    }

    private var stateText: String {
        switch vm.phase {
        case .busy: "Busy"
        case .finished: "Done"
        case .idle: vm.movesRemaining == 0 ? "Round complete" : "Ready"
        }
    }

    // MARK: HUD

    private var hud: some View {
        HStack(spacing: 10) {
            Button {
                vm.close()
                onClose()
            } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 20, weight: .heavy))
                    .foregroundStyle(Theme.ink)
                    .frame(width: 50, height: 50)
                    .background(Circle().fill(Theme.cream))
                    .overlay(Circle().strokeBorder(Theme.ink, lineWidth: 3))
            }
            .accessibilityLabel("Back to the alley")
            .accessibilityIdentifier(AccessibilityID.gameClose)

            if vm.isBakeOff {
                plaqueValue(title: "BAKE-OFF", value: vm.bakeOffDay?.key ?? "", id: "bakeoff_day")
            } else {
                CoinBadge(amount: vm.shownCoins, identifier: AccessibilityID.gameBalance)
            }
            Spacer(minLength: 0)
            plaqueValue(title: vm.isBakeOff ? "POINTS" : "ROUND", value: Formatters.coins(vm.roundScore), id: "round_score")
        }
    }

    private func plaqueValue(title: String, value: String, id: String) -> some View {
        VStack(alignment: .trailing, spacing: 0) {
            Text(title).font(Theme.body(11)).foregroundStyle(Theme.ink.opacity(0.7))
            Text(value)
                .font(Theme.display(18)).foregroundStyle(Theme.ink)
                .numericTransition()
                .minimumScaleFactor(0.6).lineLimit(1)
        }
        .padding(.horizontal, 12)
        .frame(minWidth: 84, minHeight: Theme.minTarget)
        .plaque(radius: 22)
        .animation(.candy(0.4), value: value)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(title.capitalized)
        .accessibilityValue(value)
        .accessibilityIdentifier(id)
    }

    // MARK: Strips

    private var bakeOffStrip: some View {
        HStack(spacing: 10) {
            Image("icon_cake").resizable().scaledToFit().frame(width: 40, height: 40).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text("Daily Bake-Off").font(Theme.display(15)).foregroundStyle(Theme.ink)
                Text("Same board for everyone today. Free moves, 100 points per move cost scored.")
                    .font(Theme.body(11)).foregroundStyle(Theme.ink.opacity(0.8))
                    .lineLimit(2).minimumScaleFactor(0.8)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 12).padding(.vertical, 6)
        .plaque(radius: 16)
    }

    private var statusStrip: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(vm.movesRemaining > 0 ? "\(vm.movesRemaining) moves left" : "Round complete")
                        .font(Theme.display(14)).foregroundStyle(Theme.ink)
                        .numericTransition()
                    if vm.rushMoves > 0 {
                        Text("RUSH x1.5 · \(vm.rushMoves) free")
                            .font(Theme.display(11)).foregroundStyle(.white)
                            .padding(.horizontal, 7).padding(.vertical, 2)
                            .background(Capsule().fill(Theme.raspberry))
                            .accessibilityIdentifier("rush_badge")
                    }
                }
                GeometryReader { proxy in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Theme.ink.opacity(0.15))
                        Capsule().fill(LinearGradient(colors: [Theme.mint, Theme.mintDeep], startPoint: .leading, endPoint: .trailing))
                            .frame(width: proxy.size.width * CGFloat(vm.movesRemaining) / CGFloat(vm.totalMoves))
                    }
                    .overlay(Capsule().strokeBorder(Theme.ink, lineWidth: 2))
                    .animation(.candy(0.4), value: vm.movesRemaining)
                }
                .frame(height: 10)
            }
            Spacer(minLength: 4)
            Text("Swipe or tap\ntwo neighbours")
                .font(Theme.body(11)).foregroundStyle(Theme.ink.opacity(0.75))
                .multilineTextAlignment(.trailing)
        }
        .padding(.horizontal, 14)
        .frame(minHeight: Theme.minTarget + 4)
        .plaque(radius: 18)
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("moves_status")
        .accessibilityValue("\(vm.movesRemaining) moves left")
    }

    // MARK: Power-ups

    private var powerRow: some View {
        HStack(spacing: 10) {
            meterButton
            cannonButton
        }
    }

    private var meterButton: some View {
        let full = vm.store.meterIsFull
        return Button { vm.startSugarRush() } label: {
            HStack(spacing: 8) {
                Image("sym_lollipop").resizable().scaledToFit().frame(width: 30, height: 30).accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 4) {
                    Text(full ? "Start Sugar Rush!" : "Sweet Tooth")
                        .font(Theme.display(13)).foregroundStyle(Theme.ink).lineLimit(1).minimumScaleFactor(0.7)
                    GeometryReader { proxy in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Theme.ink.opacity(0.15))
                            Capsule().fill(LinearGradient(colors: [Theme.raspberry, Theme.pink], startPoint: .leading, endPoint: .trailing))
                                .frame(width: proxy.size.width * CGFloat(vm.store.meter) / CGFloat(ProfileStore.meterMax))
                        }
                        .overlay(Capsule().strokeBorder(Theme.ink, lineWidth: 2))
                        .animation(.candy(0.5, bounce: 0.4), value: vm.store.meter)
                    }
                    .frame(height: 10)
                }
            }
            .padding(.horizontal, 10)
            .frame(maxWidth: .infinity, minHeight: 54)
            .plaque(tint: full ? Theme.lemon : Theme.paper, radius: 18)
        }
        .buttonStyle(PressSquishStyle())
        .disabled(!vm.canStartRush)
        .accessibilityLabel("Sweet Tooth Meter")
        .accessibilityHint("When full, starts a Sugar Rush: three free moves that score one and a half times.")
        .accessibilityValue("\(vm.store.meter) of \(ProfileStore.meterMax)")
        .accessibilityIdentifier(AccessibilityID.meterButton)
    }

    private var cannonButton: some View {
        let ready = vm.store.cannonIsReady
        return Button { vm.cannonTapped() } label: {
            HStack(spacing: 8) {
                ZStack {
                    Circle().trim(from: 0, to: CGFloat(vm.store.cannonCharge) / CGFloat(ProfileStore.cannonMax))
                        .stroke(Theme.raspberry, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .animation(.candy(0.5), value: vm.store.cannonCharge)
                    Image("icon_cannon").resizable().scaledToFit().padding(8)
                        .rotationEffect(.degrees(vm.cannonArmed ? -14 : 0))
                        .animation(.candy(0.3, bounce: 0.6), value: vm.cannonArmed)
                }
                .frame(width: 42, height: 42)
                Text(vm.cannonArmed ? "Pick a column" : (ready ? "Fire cannon!" : "Cannon \(vm.store.cannonCharge)/\(ProfileStore.cannonMax)"))
                    .font(Theme.display(13)).foregroundStyle(Theme.ink).lineLimit(1).minimumScaleFactor(0.7)
            }
            .padding(.horizontal, 10)
            .frame(maxWidth: .infinity, minHeight: 54)
            .plaque(tint: vm.cannonArmed ? Theme.raspberry.opacity(0.35) : (ready ? Theme.lemon : Theme.paper), radius: 18)
        }
        .buttonStyle(PressSquishStyle())
        .disabled(!vm.canFireCannon)
        .accessibilityLabel("Candy Cannon")
        .accessibilityHint("Charged by cascades. Fire it, then tap a candy to clear its column for free.")
        .accessibilityValue(ready ? (vm.cannonArmed ? "Loaded" : "Ready") : "\(vm.store.cannonCharge) of \(ProfileStore.cannonMax)")
        .accessibilityIdentifier(AccessibilityID.cannonButton)
    }

    // MARK: Move cost

    private var betControl: some View {
        HStack(spacing: 8) {
            VStack(alignment: .leading, spacing: 0) {
                Text("MOVE COST").font(Theme.body(12)).foregroundStyle(Theme.ink.opacity(0.7))
                Text(vm.rushMoves > 0 ? "Rush moves are free" : "Scores scale with it")
                    .font(Theme.body(11)).foregroundStyle(Theme.ink.opacity(0.6))
            }
            Spacer(minLength: 0)
            stepper("minus", enabled: vm.canLowerBet, label: "Lower move cost", id: AccessibilityID.betMinus, action: vm.lowerBet)
            Text(Formatters.coins(vm.bet))
                .font(Theme.display(20)).foregroundStyle(Theme.ink)
                .frame(minWidth: 56)
                .minimumScaleFactor(0.7).lineLimit(1)
                .accessibilityLabel("Move cost")
                .accessibilityValue("\(vm.bet)")
                .accessibilityIdentifier(AccessibilityID.betValue)
            stepper("plus", enabled: vm.canRaiseBet, label: "Raise move cost", id: AccessibilityID.betPlus, action: vm.raiseBet)
        }
        .padding(.horizontal, 12).padding(.vertical, 6)
        .plaque(radius: 20)
    }

    private func stepper(_ symbol: String, enabled: Bool, label: String, id: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .heavy))
                .foregroundStyle(Theme.ink)
                .frame(width: Theme.minTarget, height: Theme.minTarget)
                .background(Circle().fill(Theme.cream))
                .overlay(Circle().strokeBorder(Theme.ink, lineWidth: 2.5))
        }
        .buttonStyle(PressSquishStyle())
        .disabled(!enabled)
        .opacity(enabled ? 1 : 0.4)
        .accessibilityLabel(label)
        .accessibilityIdentifier(id)
    }
}

/// Buttons that squash a little when pressed.
struct PressSquishStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(x: configuration.isPressed ? 1.05 : 1, y: configuration.isPressed ? 0.92 : 1)
            .animation(.candy(0.2, bounce: 0.6), value: configuration.isPressed)
    }
}

// MARK: - Orders

struct OrdersStrip: View {
    let orders: [FairOrder]
    let bet: Int

    var body: some View {
        HStack(spacing: 6) {
            ForEach(Array(orders.enumerated()), id: \.element.id) { index, order in
                VStack(spacing: 3) {
                    HStack(spacing: 5) {
                        Image(order.customer.assetName).resizable().scaledToFit().frame(width: 34, height: 34)
                        Text("+\(Formatters.coins(Int((Double(bet) * order.rewardMultiple).rounded())))")
                            .font(Theme.display(15)).foregroundStyle(Theme.mintDeep)
                            .lineLimit(1).minimumScaleFactor(0.7)
                        Spacer(minLength: 0)
                    }
                    Text(order.goal.text).font(Theme.body(13)).foregroundStyle(Theme.ink)
                        .lineLimit(2).minimumScaleFactor(0.8)
                        .multilineTextAlignment(.leading)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(7)
                .frame(maxWidth: .infinity, minHeight: 82, alignment: .top)
                .plaque(radius: 12)
                .transition(.asymmetric(insertion: .scale(scale: 0.4).combined(with: .opacity), removal: .move(edge: .top).combined(with: .opacity)))
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("\(order.customer.name) wants: \(order.goal.text)")
                .accessibilityIdentifier("order_card_\(index)")
            }
        }
        .animation(.candy(0.5, bounce: 0.4), value: orders)
    }
}

// MARK: - Big win

struct BigWinOverlay: View {
    let win: BigWin
    let onTap: () -> Void
    @State private var turn = 0.0
    @State private var popped = false

    var body: some View {
        ZStack {
            Theme.ink.opacity(0.55).ignoresSafeArea()
            Canvas { context, size in
                let c = CGPoint(x: size.width / 2, y: size.height / 2)
                let r = max(size.width, size.height)
                for i in 0..<16 where i % 2 == 0 {
                    let a0 = Double(i) / 16 * 2 * .pi, a1 = Double(i + 1) / 16 * 2 * .pi
                    var p = Path()
                    p.move(to: c)
                    p.addLine(to: CGPoint(x: c.x + r * cos(a0), y: c.y + r * sin(a0)))
                    p.addLine(to: CGPoint(x: c.x + r * cos(a1), y: c.y + r * sin(a1)))
                    p.closeSubpath()
                    context.fill(p, with: .color(Theme.lemon.opacity(0.22)))
                }
            }
            .rotationEffect(.degrees(turn))
            .ignoresSafeArea()

            VStack(spacing: 14) {
                HStack(spacing: -10) {
                    ForEach(0..<3, id: \.self) { i in
                        Image(["sym_lollipop", "sym_sprinkle", "sym_tart"][i]).resizable().scaledToFit()
                            .frame(width: 70, height: 70)
                            .rotationEffect(.degrees(popped ? Double(i - 1) * 18 : 0))
                            .offset(y: popped ? (i == 1 ? -16 : 0) : 40)
                    }
                }
                Text(win.title)
                    .font(Theme.display(win.tier == .mega ? 50 : 44))
                    .foregroundStyle(Theme.lemon)
                    .shadow(color: Theme.ink.opacity(0.55), radius: 3, x: 0, y: 2)
                    .minimumScaleFactor(0.5)
                    .lineLimit(1)
                Text(win.label)
                    .font(Theme.display(28)).foregroundStyle(Theme.ink)
                    .padding(.horizontal, 22).padding(.vertical, 8)
                    .background(Capsule().fill(Theme.paper))
                    .overlay(Capsule().strokeBorder(Theme.ink, lineWidth: 3))
                Text("Tap to continue").font(Theme.body(13)).foregroundStyle(.white.opacity(0.85))
            }
            .padding(24)
            .scaleEffect(popped ? 1 : 0.4)
        }
        .contentShape(Rectangle())
        .onTapGesture(perform: onTap)
        .onAppear {
            withAnimation(.candy(0.55, bounce: 0.55)) { popped = true }
            withAnimation(.linear(duration: 2.2)) { turn = 40 }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(win.title) \(win.label)")
        .accessibilityAddTraits(.isButton)
        .accessibilityIdentifier("big_win")
    }
}

// MARK: - Round / Bake-Off summary

struct RoundSummaryView: View {
    let summary: RoundSummary
    let rankPoints: Int
    let onNext: () -> Void
    let onExit: () -> Void

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                Image(summary.isBakeOff ? "icon_cake" : "rank_rosette").resizable().scaledToFit().frame(height: 110)
                    .accessibilityHidden(true)
                Text(summary.isBakeOff ? "DAILY BAKE-OFF" : "ROUND COMPLETE").font(Theme.display(22)).foregroundStyle(Theme.ink)
                if summary.isBakeOff {
                    Text(summary.dayKey).font(Theme.body(14)).foregroundStyle(Theme.ink.opacity(0.7))
                }
                Text(Formatters.coins(summary.score))
                    .font(Theme.display(56)).foregroundStyle(Theme.raspberryDeep)
                    .numericTransition()
                    .accessibilityLabel("Score \(summary.score)")
                    .accessibilityIdentifier("summary_score")
                Text(summary.isBakeOff ? "points" : "coins scored this round").font(Theme.body(14)).foregroundStyle(Theme.ink.opacity(0.75))
                if summary.isNewBest {
                    Text(summary.isBakeOff ? "Best score today!" : "New personal best round!")
                        .font(Theme.display(16)).foregroundStyle(Theme.ink)
                        .padding(.horizontal, 14).padding(.vertical, 6)
                        .background(Capsule().fill(Theme.lemon))
                        .overlay(Capsule().strokeBorder(Theme.ink, lineWidth: 2.5))
                        .accessibilityIdentifier("summary_new_best")
                }
                VStack(spacing: 6) {
                    row(summary.isBakeOff ? "Best today" : "Best round", Formatters.coins(summary.best))
                    if summary.isBakeOff {
                        row("Streak", summary.streak == 1 ? "1 day" : "\(summary.streak) days")
                    } else {
                        row("Orders served", "\(summary.ordersServed)")
                    }
                    row("Sugar Points", "+\(summary.sugarPoints)")
                    HStack {
                        Text(FairRank.title(for: rankPoints)).font(Theme.body(14)).foregroundStyle(Theme.ink)
                        Spacer()
                        RankBar(points: rankPoints).frame(width: 140, height: 10)
                    }
                }
                .padding(14)
                .plaque()
                if summary.isBakeOff {
                    Text("Everyone plays the same board today, so this score is directly comparable with other players.")
                        .font(Theme.body(13)).foregroundStyle(Theme.ink.opacity(0.8)).multilineTextAlignment(.center)
                } else {
                    Button("Play another round", action: onNext)
                        .buttonStyle(CandyButtonStyle())
                        .accessibilityIdentifier("round_next")
                }
                Button("Back to the alley", action: onExit)
                    .buttonStyle(CandyButtonStyle(fill: Theme.mint, deep: Theme.mintDeep, foreground: Theme.ink))
                    .accessibilityIdentifier("round_exit")
            }
            .padding(20)
            .frame(maxWidth: 520)
            .frame(maxWidth: .infinity)
        }
        .background(Theme.paper.ignoresSafeArea())
        .screenID("round_summary")
        .preferredColorScheme(.light)
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title).font(Theme.body(15)).foregroundStyle(Theme.ink)
            Spacer()
            Text(value).font(Theme.display(15)).foregroundStyle(Theme.ink)
        }
    }
}
