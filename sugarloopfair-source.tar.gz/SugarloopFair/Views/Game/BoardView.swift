import SwiftUI

extension Symbol {
    /// Confetti colour for bursts.
    var tint: Color {
        switch self {
        case .mint: Theme.mint
        case .lemon: Theme.lemon
        case .grape: Theme.grape
        case .honey: Theme.caramel
        case .tart: Theme.raspberry
        case .bear: Color(hex: 0xFF5A5F)
        case .fox: Color(hex: 0xFF8A3D)
        case .frog: Color(hex: 0x7ED957)
        case .lollipop: Theme.pink
        case .sprinkle: Theme.sky
        }
    }
}

struct CellView: View {
    let cell: Cell
    let size: CGFloat
    let highlighted: Bool
    let popping: Bool
    let hasJam: Bool

    var body: some View {
        ZStack {
            Image("tile_cell").resizable().scaledToFit()
            if hasJam {
                Image("tile_jam").resizable().scaledToFit().opacity(0.9).padding(size * 0.04)
            }
            Image(cell.symbol.assetName)
                .resizable()
                .scaledToFit()
                .padding(size * 0.05)
            if cell.symbol == .sprinkle {
                Text("x\(cell.multiplier)")
                    .font(Theme.display(size * 0.3))
                    .foregroundStyle(Theme.ink)
                    .minimumScaleFactor(0.6)
                    .padding(.horizontal, 5)
                    .background(Capsule().fill(Theme.paper.opacity(0.95)))
                    .overlay(Capsule().strokeBorder(Theme.ink, lineWidth: 2))
            }
        }
        .frame(width: size, height: size)
        .scaleEffect(popping ? 0.15 : (highlighted ? 1.14 : 1))
        .rotationEffect(.degrees(popping ? 30 : 0))
        .opacity(popping ? 0 : 1)
        .shadow(color: highlighted ? Theme.lemon.opacity(0.9) : .clear, radius: highlighted ? 8 : 0)
        .animation(.candy(0.25, bounce: 0.55), value: highlighted)
    }
}

/// Wobbles the whole board each time `animatableData` crosses to the next integer.
struct ShakeEffect: GeometryEffect {
    var animatableData: CGFloat

    func effectValue(size: CGSize) -> ProjectionTransform {
        let x = sin(animatableData * .pi * 6) * 9
        let y = cos(animatableData * .pi * 4) * 3 * sin(animatableData * .pi)
        return ProjectionTransform(CGAffineTransform(translationX: x, y: y))
    }
}

struct BoardView: View {
    @ObservedObject var vm: GameViewModel
    let booth: Booth

    /// One swipe per finger: set once a drag has triggered a swap, cleared when the finger lifts.
    @State private var dragConsumed = false

    // Spacing and frame padding scale with the cell, so the board keeps one aspect ratio on every phone.
    private static let spacingRatio: CGFloat = 0.06
    private static let paddingRatio: CGFloat = 0.16
    private static let widthUnits = CGFloat(Board.cols) + CGFloat(Board.cols - 1) * spacingRatio + 2 * paddingRatio
    private static let heightUnits = CGFloat(Board.rows) + CGFloat(Board.rows - 1) * spacingRatio + 2 * paddingRatio

    private struct Metrics {
        let cell: CGFloat
        var spacing: CGFloat { cell * BoardView.spacingRatio }
        var padding: CGFloat { cell * BoardView.paddingRatio }
        var step: CGFloat { cell + spacing }

        func point(col: Double, row: Double) -> CGPoint {
            CGPoint(x: padding + CGFloat(col) * step + cell / 2, y: padding + CGFloat(row) * step + cell / 2)
        }
    }

    var body: some View {
        GeometryReader { proxy in
            content(Metrics(cell: proxy.size.width / Self.widthUnits))
        }
        .aspectRatio(Self.widthUnits / Self.heightUnits, contentMode: .fit)
        .modifier(ShakeEffect(animatableData: CGFloat(vm.shakeToken)))
        .animation(.linear(duration: 0.45), value: vm.shakeToken)
    }

    private func content(_ m: Metrics) -> some View {
        ZStack(alignment: .topLeading) {
            RoundedRectangle(cornerRadius: m.cell * 0.45, style: .continuous)
                .fill(LinearGradient(colors: [booth.glaze, booth.glazeDeep], startPoint: .top, endPoint: .bottom))
            RoundedRectangle(cornerRadius: m.cell * 0.45, style: .continuous)
                .strokeBorder(vm.cannonArmed ? Theme.lemon : Theme.ink, lineWidth: vm.cannonArmed ? 5 : 3)

            grid(m)
                .padding(m.padding)
                .accessibilityElement(children: .contain)
                .accessibilityLabel("Candy board, 6 columns by 5 rows")
                .accessibilityIdentifier(AccessibilityID.board)

            ParticleLayer(bursts: vm.bursts) { index in
                m.point(col: Double(Board.col(of: index)), row: Double(Board.row(of: index)))
            }
            .allowsHitTesting(false)

            ForEach(vm.popups) { popup in
                PopupLabel(popup: popup)
                    .position(m.point(col: popup.col, row: popup.row))
                    .allowsHitTesting(false)
            }

            if let banner = vm.banner {
                BannerView(banner: banner).id(banner.id).allowsHitTesting(false)
                    .frame(maxWidth: .infinity)
                    .padding(.top, m.padding + 4)
            }
        }
        .shadow(color: Theme.ink.opacity(0.18), radius: 4, x: 0, y: 3)
    }

    private func grid(_ m: Metrics) -> some View {
        VStack(spacing: m.spacing) {
            ForEach(0..<Board.rows, id: \.self) { row in
                HStack(spacing: m.spacing) {
                    ForEach(0..<Board.cols, id: \.self) { col in
                        slot(Board.index(col: col, row: row), m)
                    }
                }
            }
        }
    }

    /// Offset for a cell that is part of the sliding swap pair.
    private func slideOffset(_ index: Int, _ m: Metrics) -> CGSize {
        guard let pair = vm.swapPair, index == pair.0 || index == pair.1 else { return .zero }
        let other = index == pair.0 ? pair.1 : pair.0
        let dx = CGFloat(Board.col(of: other) - Board.col(of: index)) * m.step * vm.swapProgress
        let dy = CGFloat(Board.row(of: other) - Board.row(of: index)) * m.step * vm.swapProgress
        return CGSize(width: dx, height: dy)
    }

    private func slot(_ index: Int, _ m: Metrics) -> some View {
        let item = vm.board[index]
        let selected = vm.selectedCells.contains(index)
        let hinted = vm.hintCells.contains(index)
        let cell = m.cell
        return ZStack {
            CellView(
                cell: item,
                size: cell,
                highlighted: vm.highlighted.contains(index),
                popping: vm.popping.contains(index),
                hasJam: vm.jam.contains(index)
            )
            .id(vm.tokens[index])
            .transition(.asymmetric(
                insertion: .offset(y: -cell * 1.8).combined(with: .scale(scale: 0.7, anchor: .bottom)).combined(with: .opacity),
                removal: .scale(scale: 0.3).combined(with: .opacity)
            ))
            if selected {
                RoundedRectangle(cornerRadius: cell * 0.22).strokeBorder(Theme.raspberry, lineWidth: 3.5)
                    .padding(1).shadow(color: Theme.lemon, radius: 5)
            }
        }
        .frame(width: cell, height: cell)
        .scaleEffect(selected ? 1.08 : (hinted ? 1.12 : 1))
        .rotationEffect(.degrees(hinted ? 7 : 0))
        .offset(x: vm.wobbleCells.contains(index) ? 7 : 0)
        .offset(slideOffset(index, m))
        .zIndex(vm.swapPair.map { $0.0 == index ? 3 : ($0.1 == index ? 2 : 0) } ?? (selected ? 1 : 0))
        .animation(.candy(0.3, bounce: 0.75), value: vm.wobbleCells)
        .animation(.candy(0.26, bounce: 0.6), value: hinted)
        .animation(.candy(0.25, bounce: 0.5), value: selected)
        .contentShape(Rectangle())
        .onTapGesture { vm.selectCell(index) }
        .simultaneousGesture(
            DragGesture(minimumDistance: 8)
                .onChanged { value in
                    // Swap as soon as the finger has clearly picked a direction, like a physical nudge.
                    let t = value.translation
                    guard !dragConsumed, max(abs(t.width), abs(t.height)) > cell * 0.35 else { return }
                    dragConsumed = true
                    if abs(t.width) > abs(t.height) {
                        vm.swipe(from: index, dx: t.width > 0 ? 1 : -1, dy: 0)
                    } else {
                        vm.swipe(from: index, dx: 0, dy: t.height > 0 ? 1 : -1)
                    }
                }
                .onEnded { _ in dragConsumed = false }
        )
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(item.symbol.displayName), row \(Board.row(of: index) + 1), column \(Board.col(of: index) + 1)")
        .accessibilityValue(selected ? "Selected" : "Not selected")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction { vm.selectCell(index) }
        .accessibilityIdentifier("candy_cell_\(index)")
    }
}

/// "+120" that pops in and floats upwards.
struct PopupLabel: View {
    let popup: ScorePopup
    @State private var risen = false

    var body: some View {
        Text(popup.text)
            .font(Theme.display(popup.isBig ? 22 : 17))
            .foregroundStyle(Theme.raspberryDeep)
            .padding(.horizontal, 7)
            .padding(.vertical, 1)
            .background(Capsule().fill(Theme.paper.opacity(0.92)))
            .shadow(color: Theme.ink.opacity(0.2), radius: 2, x: 0, y: 1)
            .scaleEffect(risen ? 1 : 0.3)
            .offset(y: risen ? -26 : 0)
            .onAppear { withAnimation(.candy(0.45, bounce: 0.55)) { risen = true } }
            .accessibilityHidden(true)
    }
}

/// Sprinkle confetti. The timeline pauses when there is nothing to draw, so idle screens stay idle.
struct ParticleLayer: View {
    let bursts: [ParticleBurst]
    let center: (Int) -> CGPoint

    private static let life: Double = 0.85

    var body: some View {
        TimelineView(.animation(minimumInterval: 1 / 60, paused: bursts.isEmpty)) { timeline in
            Canvas { context, _ in
                for burst in bursts {
                    let age = timeline.date.timeIntervalSince(burst.start)
                    guard age >= 0, age < Self.life else { continue }
                    let fade = 1 - age / Self.life
                    var seed = UInt64(truncatingIfNeeded: burst.id.hashValue)
                    for (i, index) in burst.cells.enumerated() {
                        let origin = center(index)
                        let color = (i < burst.symbols.count ? burst.symbols[i] : .mint).tint
                        for p in 0..<8 {
                            seed = seed &* 6364136223846793005 &+ 1442695040888963407
                            let angle = Double(seed >> 40 & 0xFFFF) / 65535 * 2 * .pi
                            let speed = 70 + Double(seed >> 20 & 0xFF) / 255 * 120
                            let spin = Double(seed & 0xFF) / 255 * 8
                            let x = origin.x + CGFloat(cos(angle) * speed * age)
                            let y = origin.y + CGFloat(sin(angle) * speed * age + 420 * age * age)
                            var piece = context
                            piece.opacity = fade
                            piece.translateBy(x: x, y: y)
                            piece.rotate(by: .radians(angle + spin * age))
                            let rect = CGRect(x: -6, y: -2.5, width: 12, height: 5)
                            piece.fill(Path(roundedRect: rect, cornerRadius: 2.5), with: .color(p % 3 == 0 ? .white : color))
                            piece.stroke(Path(roundedRect: rect, cornerRadius: 2.5), with: .color(Theme.ink.opacity(0.5)), lineWidth: 1)
                        }
                    }
                }
            }
        }
    }
}

struct BannerView: View {
    let banner: Banner

    private var colors: (Color, Color) {
        switch banner.kind {
        case .win: (Theme.lemon, Theme.ink)
        case .info: (Theme.paper, Theme.ink)
        case .bomb: (Theme.grape, .white)
        case .stampede: (Theme.mint, Theme.ink)
        case .fair: (Theme.raspberry, .white)
        }
    }

    var body: some View {
        Text(banner.text)
            .font(Theme.display(21))
            .foregroundStyle(colors.1)
            .minimumScaleFactor(0.6)
            .lineLimit(1)
            .padding(.horizontal, 18)
            .padding(.vertical, 6)
            .background(Capsule().fill(colors.0))
            .overlay(Capsule().strokeBorder(Theme.ink, lineWidth: 2))
            .shadow(color: Theme.ink.opacity(0.18), radius: 3, x: 0, y: 2)
            .padding(.horizontal, 14)
            .transition(.scale(scale: 0.5).combined(with: .opacity))
            .accessibilityLabel(banner.text)
            .accessibilityIdentifier(AccessibilityID.banner)
    }
}
