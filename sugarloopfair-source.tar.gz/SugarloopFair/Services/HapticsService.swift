import UIKit

enum HapticKind: Sendable {
    case tap, win, bigWin, warning
}

/// Own enum instead of UIKit feedback types so callers need no UIKit import.
@MainActor
final class HapticsService {
    private let settings: SettingsStore

    init(settings: SettingsStore) { self.settings = settings }

    func play(_ kind: HapticKind) {
        guard settings.hapticsEnabled else { return }
        switch kind {
        case .tap: UIImpactFeedbackGenerator(style: .light).impactOccurred()
        case .win: UINotificationFeedbackGenerator().notificationOccurred(.success)
        case .bigWin: UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
        case .warning: UINotificationFeedbackGenerator().notificationOccurred(.warning)
        }
    }
}
