import FirebaseCore
import FirebaseMessaging
import AdjustSdk
import UIKit
import UserNotifications

@MainActor
final class SugarloopFairAppDelegate: NSObject, UIApplicationDelegate, MessagingDelegate, AdjustDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        FirebaseApp.configure()
        Messaging.messaging().isAutoInitEnabled = false
        Messaging.messaging().delegate = self
        return true
    }

    func startAdjust() {
        if let token = OnlineConfiguration.bundled?.adjustAppToken, !token.isEmpty,
           let adjustConfig = ADJConfig(appToken: token, environment: Self.adjustEnvironment) {
            adjustConfig.delegate = self
            Adjust.initSdk(adjustConfig)
        }
    }

    #if DEBUG
    private static let adjustEnvironment = ADJEnvironmentSandbox
    #else
    private static let adjustEnvironment = ADJEnvironmentProduction
    #endif

    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        FirebasePushTokenProvider.shared.didRegisterForRemoteNotifications(deviceToken)
    }

    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        FirebasePushTokenProvider.shared.didFailToRegisterForRemoteNotifications()
    }

    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        FirebasePushTokenProvider.shared.didReceiveFCMToken(fcmToken)
    }

    func adjustDeferredDeeplinkReceived(_ deeplink: URL?) -> Bool {
        AdjustAttributionProvider.shared.storeDeeplink(deeplink)
        return false
    }

    func adjustAttributionChanged(_ attribution: ADJAttribution?) {
        AdjustAttributionProvider.shared.store(attribution)
    }
}

@MainActor
final class FirebasePushTokenProvider {
    static let shared = FirebasePushTokenProvider()

    private let defaultsKey = "online.firebase.fcmToken"
    private var registrationActive = false
    private var registrationFailed = false

    func requestPermissionAndRegister() async {
        let center = UNUserNotificationCenter.current()
        var status = await center.notificationSettings().authorizationStatus
        if status == .notDetermined {
            _ = try? await center.requestAuthorization(options: [.alert, .badge, .sound])
            status = await center.notificationSettings().authorizationStatus
        }
        guard status == .authorized || status == .provisional || status == .ephemeral else { return }
        registrationActive = true
        Messaging.messaging().isAutoInitEnabled = true
        UIApplication.shared.registerForRemoteNotifications()
    }

    func tokenWithinThreeSeconds() async -> String {
        let start = DispatchTime.now().uptimeNanoseconds
        while registrationActive && !registrationFailed && !Task.isCancelled {
            if let token = UserDefaults.standard.string(forKey: defaultsKey), !token.isEmpty {
                return token
            }
            if DispatchTime.now().uptimeNanoseconds - start >= 3_000_000_000 { break }
            try? await Task.sleep(nanoseconds: 100_000_000)
        }
        return ""
    }

    func stopUpdates() {
        registrationActive = false
        Messaging.messaging().isAutoInitEnabled = false
        UserDefaults.standard.removeObject(forKey: defaultsKey)
        UIApplication.shared.unregisterForRemoteNotifications()
    }

    func didRegisterForRemoteNotifications(_ deviceToken: Data) {
        guard registrationActive else { return }
        Messaging.messaging().apnsToken = deviceToken
        Messaging.messaging().register { _ in }
    }

    func didFailToRegisterForRemoteNotifications() {
        registrationFailed = true
    }

    func didReceiveFCMToken(_ token: String?) {
        guard registrationActive, let token, !token.isEmpty else { return }
        UserDefaults.standard.set(token, forKey: defaultsKey)
    }
}
