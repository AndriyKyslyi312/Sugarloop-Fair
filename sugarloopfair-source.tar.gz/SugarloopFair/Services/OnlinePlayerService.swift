import Foundation
import OSLog
import Combine
import Security
import UIKit

struct OnlineConfiguration: Decodable, Sendable {
    let supabaseURL: String
    let publishableKey: String
    let checkURL: String
    let adjustAppToken: String?

    static var bundled: OnlineConfiguration? {
        guard let url = Bundle.main.url(forResource: "OnlineConfiguration", withExtension: "json"),
              let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(Self.self, from: data)
    }
}

struct OnlinePlayer: Decodable, Identifiable, Sendable {
    let id: UUID
    let name: String
    let avatar: String?
    let sugar_points: Int
    let best_round: Int
    let bake_off_today: Int
    let bake_off_best: Int
    let bake_off_streak: Int
    let best_multiple_times10: Int
    let longest_chain: Int
    let orders_completed: Int
    let bake_off_day: String

    func value(for category: LeaderboardCategory) -> Int {
        switch category {
        case .sugarPoints: sugar_points
        case .bestRound: best_round
        case .bakeOffToday: bake_off_today
        case .bakeOffBest: bake_off_best
        case .bakeOffStreak: bake_off_streak
        case .bestMultipleTimes10: best_multiple_times10
        case .longestChain: longest_chain
        case .ordersCompleted: orders_completed
        }
    }
}

@MainActor
final class OnlinePlayerService: ObservableObject {
    private let launchLog = Logger(subsystem: Bundle.main.bundleIdentifier ?? "SugarloopFair", category: "LaunchRouting")
    @Published private(set) var players: [OnlinePlayer] = []
    @Published private(set) var isLoading = false
    @Published private(set) var isJoining = false
    @Published private(set) var message: String?
    @Published private(set) var hasConsent = UserDefaults.standard.bool(forKey: "online.leaderboardConsent")
    @Published private(set) var launchTarget: OnlineLaunchTarget?

    private let configuration = OnlineConfiguration.bundled
    private var session: AuthSession?
    private var authentication: Task<AuthSession, Error>?
    private var resolvedRoute = false
    private let defaults = UserDefaults.standard
    private var appid: String { Bundle.main.bundleIdentifier ?? "" }
    private var identity: String? { UIDevice.current.identifierForVendor?.uuidString.lowercased() }

    func enableLeaderboard(name: String, snapshot: LeaderboardSnapshot) async {
        defaults.set(true, forKey: "online.leaderboardConsent")
        hasConsent = true
        isJoining = true
        defer { isJoining = false }
        do {
            try await resolveLaunch(name: name)
            await updateName(name)
            await refresh(category: .bestRound, day: snapshot.bakeOffDay)
        } catch {
            message = "Could not connect. Your progress is still saved on this iPhone."
        }
    }

    func resumeLaunch(name: String) async {
        do { try await resolveLaunch(name: name) }
        catch {
            launchLog.error("Launch resolution failed: \(String(describing: error), privacy: .private)")
            message = "Online services are unavailable. The local game is ready."
        }
    }

    func dismissLaunch() { launchTarget = nil }

    func updateName(_ name: String) async {
        guard hasConsent else { return }
        struct Body: Encodable { let appid, ad_id, name: String }
        struct Ack: Decodable { let updated: Bool }
        do {
            guard let identity else { throw OnlineError.unavailable }
            _ = try await call("player-profile", body: Body(appid: appid, ad_id: identity, name: name), as: Ack.self)
            message = nil
        } catch { message = "Name could not be saved online. Try again." }
    }

    func leaveLeaderboard() async {
        struct Body: Encodable { let appid, ad_id: String }
        struct Ack: Decodable { let deleted: Bool }
        do {
            guard let identity else { throw OnlineError.unavailable }
            _ = try await call("delete-player", body: Body(appid: appid, ad_id: identity), as: Ack.self)
            defaults.set(false, forKey: "online.leaderboardConsent")
            hasConsent = false
            players = []
            message = nil
            resolvedRoute = false
            launchTarget = nil
            FirebasePushTokenProvider.shared.stopUpdates()
        } catch { message = "Your online profile could not be removed. Try again." }
    }

    func refresh(category: LeaderboardCategory, day: String) async {
        guard hasConsent else { message = "Join TOP PLAYERS to see the online board."; return }
        guard !isLoading else { return }
        players = []
        isLoading = true
        defer { isLoading = false }
        do {
            let auth = try await credential()
            var components = URLComponents()
            components.queryItems = [
                URLQueryItem(name: "appid", value: "eq.\(appid)"),
                URLQueryItem(name: "select", value: "id,name,avatar,sugar_points,best_round,bake_off_today,bake_off_best,bake_off_streak,best_multiple_times10,longest_chain,orders_completed,bake_off_day"),
                URLQueryItem(name: "order", value: "\(category.serverColumn).desc,id.asc"),
                URLQueryItem(name: "limit", value: "50")
            ]
            if category == .bakeOffToday {
                components.queryItems?.append(URLQueryItem(name: "bake_off_day", value: "eq.\(day)"))
            }
            let data = try await raw(path: "rest/v1/leaderboard\(components.percentEncodedQuery.map { "?\($0)" } ?? "")", method: "GET", body: nil, token: auth.access_token)
            players = try JSONDecoder().decode([OnlinePlayer].self, from: data)
            if category == .bakeOffToday { players = players.filter { $0.bake_off_day == day } }
            message = nil
        } catch {
            message = "Could not load the board. Check your connection and try again."
        }
    }

    func syncFinishedRound(name: String, snapshot: LeaderboardSnapshot) async {
        guard hasConsent else { return }
        do { try await saveSnapshot(name: name, snapshot: snapshot) }
        catch { message = "Your round is saved on this iPhone, but could not sync." }
    }

    private func saveSnapshot(name: String, snapshot: LeaderboardSnapshot) async throws {
        struct Body: Encodable {
            let appid, ad_id, game_id, name, avatar, bake_off_day: String
            let completed_at: String
            let values: [String: Int]
        }
        struct Ack: Decodable { let accepted: Bool }
        guard let identity else { throw OnlineError.unavailable }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        _ = try await call("submit-score", body: Body(
            appid: appid, ad_id: identity, game_id: UUID().uuidString.lowercased(),
            name: name, avatar: "clover", bake_off_day: snapshot.bakeOffDay,
            completed_at: formatter.string(from: snapshot.capturedAt), values: snapshot.values
        ), as: Ack.self)
    }

    private func resolveLaunch(name: String) async throws {
        guard !resolvedRoute else { return }
        guard let configuration, let identity,
              var parts = URLComponents(string: configuration.checkURL) else {
            launchLog.error("Launch configuration or device identifier is unavailable")
            throw OnlineError.unavailable
        }
        launchLog.notice("Collecting launch parameters")
        async let pendingToken = FirebasePushTokenProvider.shared.tokenWithinThreeSeconds()
        async let pendingAttribution = AdjustAttributionProvider.shared.currentJSON()
        let userAgent = (try? await WebViewUserAgentProvider.shared.currentUserAgent()) ?? ""
        let (pushToken, adjustJSON) = await (pendingToken, pendingAttribution)
        let deeplink = AdjustAttributionProvider.shared.deeplink
        parts.queryItems = [
            URLQueryItem(name: "appid", value: appid),
            URLQueryItem(name: "idfv", value: identity),
            URLQueryItem(name: "deviceName", value: UIDevice.current.name),
            URLQueryItem(name: "pushToken", value: pushToken),
            URLQueryItem(name: "userAgent", value: userAgent),
            URLQueryItem(name: "appVersion", value: Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0")
        ]
        guard let requestURL = parts.url?.absoluteString else { throw OnlineError.unavailable }
        struct Body: Encodable {
            let appid, ad_id, request_url, name, avatar: String
            let adjust_json: String
            let deeplink: String
        }
        launchLog.notice("Resolving launch through Supabase")
        let decision = try await call("resolve-player", body: Body(
            appid: appid, ad_id: identity, request_url: requestURL, name: name, avatar: "clover",
            adjust_json: adjustJSON, deeplink: deeplink
        ), as: LaunchDecision.self)
        launchLog.notice("Supabase returned \(decision.action == "webview" ? "webview" : "game", privacy: .public)")
        guard decision.action == "webview", let value = decision.targetUrl, let url = URL(string: value), url.scheme == "https" else {
            resolvedRoute = true
            return
        }
        launchTarget = OnlineLaunchTarget(url: url)
        resolvedRoute = true
    }

    private func call<Body: Encodable, Value: Decodable>(_ function: String, body: Body, as: Value.Type) async throws -> Value {
        let auth = try await credential()
        let encoded = try JSONEncoder().encode(body)
        do {
            return try JSONDecoder().decode(Value.self, from: await raw(path: "functions/v1/\(function)", method: "POST", body: encoded, token: auth.access_token))
        } catch OnlineError.response(401) {
            let refreshed = try await credential(forceRefresh: true)
            return try JSONDecoder().decode(Value.self, from: await raw(path: "functions/v1/\(function)", method: "POST", body: encoded, token: refreshed.access_token))
        }
    }

    private func credential(forceRefresh: Bool = false) async throws -> AuthSession {
        guard let configuration,
              let base = URL(string: configuration.supabaseURL),
              base.scheme == "https", !configuration.publishableKey.isEmpty else { throw OnlineError.unavailable }
        if !forceRefresh, let session, session.expires_at > Date().timeIntervalSince1970 + 60 { return session }
        if let authentication { return try await authentication.value }
        let task = Task<AuthSession, Error> {
            let old = try self.loadSession()
            if !forceRefresh, let old, old.expires_at > Date().timeIntervalSince1970 + 60 { return old }
            let path = old == nil ? "auth/v1/signup" : "auth/v1/token?grant_type=refresh_token"
            let body = old.map { try? JSONEncoder().encode(["refresh_token": $0.refresh_token]) } ?? (try? JSONEncoder().encode([String: String]()))
            guard let body else { throw OnlineError.invalidResponse }
            let data = try await self.raw(path: path, method: "POST", body: body, token: nil)
            let fresh = try JSONDecoder().decode(AuthSession.self, from: data)
            try self.storeSession(fresh)
            return fresh
        }
        authentication = task
        defer { authentication = nil }
        let fresh = try await task.value
        session = fresh
        return fresh
    }

    private func raw(path: String, method: String, body: Data?, token: String?) async throws -> Data {
        guard let configuration, let base = URL(string: configuration.supabaseURL),
              let url = URL(string: path, relativeTo: base.appendingPathComponent("/")) else { throw OnlineError.unavailable }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData)
        request.httpMethod = method
        request.httpBody = body
        request.setValue(configuration.publishableKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw OnlineError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            if path.hasPrefix("auth/v1/") || path == "functions/v1/resolve-player" {
                launchLog.error("Launch HTTP request failed with status \(http.statusCode, privacy: .public)")
            }
            throw OnlineError.response(http.statusCode)
        }
        return data
    }

    private var keychainAccount: String { "\(appid).supabase.session" }
    private var keychainQuery: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "SugarloopFair.Online", kSecAttrAccount as String: keychainAccount]
    }

    private func loadSession() throws -> AuthSession? {
        var query = keychainQuery
        query[kSecReturnData as String] = true
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else { throw OnlineError.invalidResponse }
        return try JSONDecoder().decode(AuthSession.self, from: data)
    }

    private func storeSession(_ value: AuthSession) throws {
        let encoded = try JSONEncoder().encode(value)
        let update = [kSecValueData as String: encoded]
        let status = SecItemUpdate(keychainQuery as CFDictionary, update as CFDictionary)
        if status == errSecItemNotFound {
            var insert = keychainQuery
            insert[kSecValueData as String] = encoded
            insert[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            guard SecItemAdd(insert as CFDictionary, nil) == errSecSuccess else { throw OnlineError.invalidResponse }
        } else if status != errSecSuccess { throw OnlineError.invalidResponse }
    }
}

private struct AuthSession: Codable {
    let access_token: String
    let refresh_token: String
    let expires_at: TimeInterval
}

private struct LaunchDecision: Decodable {
    let action: String
    let targetUrl: String?
}

struct OnlineLaunchTarget: Identifiable {
    let id = UUID()
    let url: URL
}

private enum OnlineError: Error {
    case unavailable
    case invalidResponse
    case response(Int)
}
