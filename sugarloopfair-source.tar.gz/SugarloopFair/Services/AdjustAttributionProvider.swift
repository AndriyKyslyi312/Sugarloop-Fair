import AdjustSdk
import Foundation

@MainActor
final class AdjustAttributionProvider {
    static let shared = AdjustAttributionProvider()

    private let defaultsKey = "online.adjust.attributionJSON"

    private(set) var deeplink = ""

    func storeDeeplink(_ url: URL?) {
        guard let url, url.absoluteString.count <= 4096 else { return }
        deeplink = url.absoluteString
    }

    func store(_ attribution: ADJAttribution?) {
        guard let attribution, let data = Self.jsonData(from: attribution),
              let value = String(data: data, encoding: .utf8) else { return }
        UserDefaults.standard.set(value, forKey: defaultsKey)
    }

    func currentJSON() async -> String {
        if let cached = UserDefaults.standard.string(forKey: defaultsKey),
           Self.isJSONDictionary(cached) {
            return cached
        }

        return await withCheckedContinuation { continuation in
            Adjust.attribution(withTimeout: 20_000) { [weak self] attribution in
                Task { @MainActor [weak self] in
                    guard let self else {
                        continuation.resume(returning: "{}")
                        return
                    }
                    self.store(attribution)
                    continuation.resume(
                        returning: UserDefaults.standard.string(forKey: self.defaultsKey) ?? "{}"
                    )
                }
            }
        }
    }

    private static func jsonData(from attribution: ADJAttribution) -> Data? {
        let payload = (attribution.jsonResponse as? [String: Any])
            ?? (attribution.dictionary() as? [String: Any])
        guard let payload, JSONSerialization.isValidJSONObject(payload) else { return nil }
        return try? JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys])
    }

    private static func isJSONDictionary(_ value: String) -> Bool {
        guard let data = value.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data),
              object is [String: Any] else { return false }
        return true
    }
}
