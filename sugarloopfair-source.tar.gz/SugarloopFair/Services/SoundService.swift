import AVFoundation

enum SoundEffect: String, CaseIterable, Sendable {
    case tap, drop, win, bomb, stampede, cannon, fair, coin
}

/// Small pool of AVAudioPlayers per effect. Missing files are skipped silently.
@MainActor
final class SoundService {
    private let settings: SettingsStore
    private var pools: [SoundEffect: [AVAudioPlayer]] = [:]

    init(settings: SettingsStore) {
        self.settings = settings
        try? AVAudioSession.sharedInstance().setCategory(.ambient, options: [.mixWithOthers])
        for effect in SoundEffect.allCases {
            guard let url = Bundle.main.url(forResource: "sfx_\(effect.rawValue)", withExtension: "wav") else { continue }
            pools[effect] = (0..<3).compactMap { _ in
                let p = try? AVAudioPlayer(contentsOf: url)
                p?.prepareToPlay()
                return p
            }
        }
    }

    func play(_ effect: SoundEffect) {
        guard settings.soundEnabled, let pool = pools[effect] else { return }
        if let free = pool.first(where: { !$0.isPlaying }) ?? pool.first {
            free.currentTime = 0
            free.play()
        }
    }
}
