import Foundation

/// JSON persistence for the save file (iOS 15 compatible). In-memory storage is used by tests.
final class ProfileStorage {
    private let url: URL?
    private var memory: Data?

    private init(url: URL?) { self.url = url }

    static func inMemory() -> ProfileStorage { ProfileStorage(url: nil) }

    static func onDisk(fileName: String = "sugarloop-save.json") throws -> ProfileStorage {
        let folder = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        return ProfileStorage(url: folder.appendingPathComponent(fileName))
    }

    func load() -> SaveFile? {
        let data: Data?
        if let url { data = try? Data(contentsOf: url) } else { data = memory }
        guard let data else { return nil }
        return try? JSONDecoder().decode(SaveFile.self, from: data)
    }

    func save(_ file: SaveFile) {
        guard let data = try? JSONEncoder().encode(file) else { return }
        if let url {
            try? data.write(to: url, options: .atomic)
        } else {
            memory = data
        }
    }
}
