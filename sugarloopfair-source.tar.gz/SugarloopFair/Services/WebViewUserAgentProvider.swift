import WebKit

@MainActor
final class WebViewUserAgentProvider: NSObject, WKNavigationDelegate {
    static let shared = WebViewUserAgentProvider()

    private var webView: WKWebView?
    private var continuation: CheckedContinuation<String, Error>?

    func currentUserAgent() async throws -> String {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<String, Error>) in
            self.continuation = continuation
            let webView = WKWebView(frame: .zero)
            webView.navigationDelegate = self
            self.webView = webView
            webView.loadHTMLString("<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width\"></head><body></body></html>", baseURL: nil)
            Task { @MainActor [weak self] in
                try? await Task.sleep(nanoseconds: 8_000_000_000)
                guard self?.continuation != nil else { return }
                self?.finish(.failure(UserAgentError.unavailable))
            }
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        webView.evaluateJavaScript("navigator.userAgent") { [weak self] value, error in
            Task { @MainActor in
                guard let self else { return }
                if let value = value as? String, !value.isEmpty {
                    self.finish(.success(value))
                } else {
                    self.finish(.failure(error ?? UserAgentError.unavailable))
                }
            }
        }
    }

    private func finish(_ result: Result<String, Error>) {
        guard let continuation else { return }
        self.continuation = nil
        webView?.navigationDelegate = nil
        webView = nil
        continuation.resume(with: result)
    }
}

private enum UserAgentError: Error {
    case unavailable
}
