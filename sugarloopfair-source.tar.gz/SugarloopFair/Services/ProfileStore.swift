import Foundation
import Combine

enum ProfileError: LocalizedError, Equatable {
    case insufficientCoins
    case jarNotReady(seconds: Int)
    case boothLocked(spinsNeeded: Int)

    var errorDescription: String? {
        switch self {
        case .insufficientCoins: "Not enough coins. Visit the Candy Jars."
        case .jarNotReady(let s): "This jar refills in \(Formatters.countdown(TimeInterval(s)))."
        case .boothLocked(let n): "Play \(n) more moves to unlock this booth."
        }
    }
}

/// Timed refills in the Candy Jar Shop. Everything is virtual currency.
enum Jar: String, CaseIterable, Identifiable, Sendable {
    case small, medium, large

    var id: String { rawValue }

    var title: String {
        switch self {
        case .small: "Pocket Jar"
        case .medium: "Daily Jar"
        case .large: "Weekly Jar"
        }
    }

    var reward: Int {
        switch self {
        case .small: 400
        case .medium: 3_000
        case .large: 20_000
        }
    }

    var cooldown: TimeInterval {
        switch self {
        case .small: 3_600
        case .medium: 86_400
        case .large: 604_800
        }
    }

    var assetName: String { "jar_\(rawValue)" }
}

/// What one finished spin (including any Fair Rounds) did to the player's stats.
struct SpinSummary: Sendable {
    var bet: Int
    var payout: Int
    var cascades: Int
    var jamHits: Int
    var stampedes: Int
    var bombTotal: Int
    var fairRounds: Int
    var usedCannon: Bool
}

@MainActor
final class ProfileStore: ObservableObject {
    static let bets = [20, 50, 100, 200, 500, 1_000]
    static let meterMax = 40
    static let cannonMax = 10
    static let historyLimit = 50
    static let rescueGrant = 500

    private let storage: ProfileStorage
    private let now: () -> Date
    @Published private(set) var profile: PlayerProfile
    private var records: [SpinRecord]

    private var rng: GameRNG

    init(storage: ProfileStorage, now: @escaping () -> Date = Date.init, seed: UInt64? = nil) {
        self.storage = storage
        self.now = now
        rng = GameRNG(seed: seed)
        let file = storage.load() ?? SaveFile()
        profile = file.profile
        records = file.records
        bootstrapV2()
    }

    /// Fills fields added in v2 for profiles created before them.
    private func bootstrapV2() {
        if profile.playerName.isEmpty { profile.playerName = Self.defaultName(for: profile.playerID) }
        let goals = orders.map(\.goal)
        let distinct = goals.enumerated().allSatisfy { i, g in !goals[..<i].contains(g) }
        if orders.count != OrderBook.slots || !distinct { setOrders(OrderBook.fresh(using: &rng)) }
        save()
    }

    static func defaultName(for id: String) -> String {
        let digits = id.unicodeScalars.reduce(UInt32(7)) { ($0 &* 31) &+ $1.value } % 10_000
        return String(format: "Guest-%04d", digits)
    }

    private func save() { storage.save(SaveFile(profile: profile, records: records)) }

    // MARK: Bet and balance

    var coins: Int { profile.coins }

    var bet: Int { Self.bets[min(max(profile.betIndex, 0), Self.bets.count - 1)] }

    func raiseBet() { setBetIndex(profile.betIndex + 1) }
    func lowerBet() { setBetIndex(profile.betIndex - 1) }

    private func setBetIndex(_ index: Int) {
        profile.betIndex = min(max(index, 0), Self.bets.count - 1)
        save()
    }

    func debit(_ amount: Int) throws {
        guard amount >= 0, profile.coins >= amount else { throw ProfileError.insufficientCoins }
        profile.coins -= amount
        save()
    }

    func credit(_ amount: Int) {
        profile.coins += max(0, amount)
        save()
    }

    /// Gives a small refill when the player cannot afford the lowest bet. Returns the amount, if any.
    @discardableResult
    func rescueIfBroke() -> Int? {
        guard profile.coins < Self.bets[0] else { return nil }
        profile.coins += Self.rescueGrant
        save()
        return Self.rescueGrant
    }

    // MARK: Meter and cannon

    var meter: Int { profile.meter }
    var meterIsFull: Bool { profile.meter >= Self.meterMax }
    var cannonCharge: Int { profile.cannonCharge }
    var cannonIsReady: Bool { profile.cannonCharge >= Self.cannonMax }

    func addProgress(meter: Int, cannon: Int) {
        profile.meter = min(Self.meterMax, profile.meter + max(0, meter))
        profile.cannonCharge = min(Self.cannonMax, profile.cannonCharge + max(0, cannon))
        save()
    }

    func spendCannon() {
        profile.cannonCharge = 0
        profile.cannonShots += 1
        save()
    }

    func spendMeter() {
        profile.meter = 0
        profile.meterCashIns += 1
        save()
    }

    // MARK: Settling spins

    /// Credits the payout, updates stats, appends history and returns newly earned rosettes.
    @discardableResult
    func settle(_ s: SpinSummary) -> [Achievement] {
        let before = Set(earnedAchievements)
        profile.coins += s.payout
        profile.totalSpins += 1
        profile.totalWagered += s.bet
        profile.totalWon += s.payout
        profile.biggestWin = max(profile.biggestWin, s.payout)
        if s.bet > 0 {
            profile.bestMultipleTimes10 = max(profile.bestMultipleTimes10, Int((Double(s.payout) / Double(s.bet) * 10).rounded()))
        }
        profile.bestCascadeChain = max(profile.bestCascadeChain, s.cascades)
        profile.stampedes += s.stampedes
        profile.jamHits += s.jamHits
        profile.highestBombTotal = max(profile.highestBombTotal, s.bombTotal)
        if s.fairRounds > 0 { profile.fairRuns += 1 }

        records.append(SpinRecord(date: now(), bet: s.bet, payout: s.payout, cascades: s.cascades, isFair: s.fairRounds > 0, bombTotal: s.bombTotal))
        if records.count > Self.historyLimit { records.removeFirst(records.count - Self.historyLimit) }
        save()
        return refreshAchievements(before: before)
    }

    /// Newest first.
    func recentRecords(limit: Int = 20) -> [SpinRecord] {
        Array(records.sorted { $0.date > $1.date }.prefix(limit))
    }

    var earnedAchievements: [Achievement] { Achievement.allCases.filter { $0.isEarned(by: profile) } }

    // MARK: Jars

    private func lastClaim(_ jar: Jar) -> Date? {
        switch jar {
        case .small: profile.lastSmallJar
        case .medium: profile.lastMediumJar
        case .large: profile.lastLargeJar
        }
    }

    /// Seconds until the jar can be claimed, 0 when it is ready.
    func secondsUntilReady(_ jar: Jar) -> Int {
        guard let last = lastClaim(jar) else { return 0 }
        return max(0, Int((last.addingTimeInterval(jar.cooldown).timeIntervalSince(now())).rounded(.up)))
    }

    @discardableResult
    func claim(_ jar: Jar) throws -> Int {
        let wait = secondsUntilReady(jar)
        guard wait == 0 else { throw ProfileError.jarNotReady(seconds: wait) }
        let stamp = now()
        switch jar {
        case .small: profile.lastSmallJar = stamp
        case .medium: profile.lastMediumJar = stamp
        case .large: profile.lastLargeJar = stamp
        }
        profile.coins += jar.reward
        save()
        return jar.reward
    }

    // MARK: Booths

    var booth: Booth { Booth(rawValue: profile.boothRaw) ?? .honey }

    func isUnlocked(_ booth: Booth) -> Bool { profile.totalSpins >= booth.unlockSpins }

    func select(_ booth: Booth) throws {
        guard isUnlocked(booth) else { throw ProfileError.boothLocked(spinsNeeded: booth.unlockSpins - profile.totalSpins) }
        profile.boothRaw = booth.rawValue
        save()
    }

    private func refreshAchievements(before: Set<Achievement>) -> [Achievement] {
        let now = earnedAchievements
        profile.achievementsRaw = now.map(\.rawValue)
        save()
        return now.filter { !before.contains($0) }
    }

    // MARK: Identity

    var playerName: String { profile.playerName }

    static let nameLimit = 16

    /// Letters, digits, spaces, dashes and underscores only; empty input restores the guest name.
    static func sanitizedName(_ raw: String) -> String {
        let allowed = raw.filter { $0.isLetter || $0.isNumber || $0 == " " || $0 == "-" || $0 == "_" }
        let collapsed = allowed.split(separator: " ", omittingEmptySubsequences: true).joined(separator: " ")
        return String(collapsed.prefix(nameLimit))
    }

    func setPlayerName(_ raw: String) {
        let clean = Self.sanitizedName(raw)
        profile.playerName = clean.isEmpty ? Self.defaultName(for: profile.playerID) : clean
        save()
    }

    // MARK: Orders and Sugar Points

    var orders: [FairOrder] {
        guard let data = profile.ordersJSON.data(using: .utf8),
              let list = try? JSONDecoder().decode([FairOrder].self, from: data) else { return [] }
        return list
    }

    private func setOrders(_ list: [FairOrder]) {
        if let data = try? JSONEncoder().encode(list), let text = String(data: data, encoding: .utf8) {
            profile.ordersJSON = text
        }
    }

    var rankLevel: Int { FairRank.level(for: profile.sugarPoints) }
    var rankTitle: String { FairRank.title(for: profile.sugarPoints) }

    struct ServeRewards: Equatable {
        var completed: [FairOrder]
        var orderCoins: Int
        var points: Int
        var rankBefore: Int
        var rankAfter: Int
        var rosettes: [Achievement]

        var rankedUp: Bool { rankAfter > rankBefore }
    }

    /// Orders and Sugar Points for one classic move. Order coins are credited here.
    @discardableResult
    func applyServe(_ outcome: ServeOutcome, bet: Int) -> ServeRewards {
        let before = Set(earnedAchievements)
        let rankBefore = rankLevel
        let resolution = OrderBook.resolve(orders, with: outcome, using: &rng)
        setOrders(resolution.next)
        let coins = resolution.completed.reduce(0) { $0 + Int((Double(bet) * $1.rewardMultiple).rounded()) }
        let points = FairRank.points(for: outcome) + resolution.completed.reduce(0) { $0 + $1.sugarPoints }
        profile.coins += coins
        profile.sugarPoints += points
        profile.ordersCompleted += resolution.completed.count
        let gained = refreshAchievements(before: before)
        return ServeRewards(completed: resolution.completed, orderCoins: coins, points: points, rankBefore: rankBefore, rankAfter: rankLevel, rosettes: gained)
    }

    // MARK: Rounds and Sugar Rush

    static let rushMovesPerRush = 3
    static let rushBetFactor = 1.5

    var rushMoves: Int { profile.rushMoves }

    /// Spends a full Sweet Tooth Meter on a Sugar Rush: free moves that score 1.5x.
    func startSugarRush() -> Bool {
        guard meterIsFull else { return false }
        spendMeter()
        profile.rushMoves += Self.rushMovesPerRush
        save()
        return true
    }

    func useRushMove() {
        profile.rushMoves = max(0, profile.rushMoves - 1)
        save()
    }

    /// Records a finished 20-move round. Returns true for a new personal best.
    @discardableResult
    func recordRound(score: Int) -> Bool {
        profile.roundsPlayed += 1
        let best = score > profile.bestRoundScore
        profile.bestRoundScore = max(profile.bestRoundScore, score)
        save()
        return best
    }

    // MARK: Daily Bake-Off

    struct BakeOffRecord: Equatable {
        var score: Int
        var todayBest: Int
        var allTimeBest: Int
        var isTodayBest: Bool
        var isAllTimeBest: Bool
        var streak: Int
        var rosettes: [Achievement]
    }

    var todayBakeOff: BakeOffDay { BakeOffDay.on(now()) }

    func bakeOffBest(for day: BakeOffDay) -> Int { profile.bakeOffDay == day.key ? profile.bakeOffTodayBest : 0 }
    func bakeOffAttempts(for day: BakeOffDay) -> Int { profile.bakeOffDay == day.key ? profile.bakeOffAttemptsToday : 0 }

    /// Streak that still counts today: it lapses if neither today nor yesterday was played.
    var liveBakeOffStreak: Int {
        let today = todayBakeOff.key
        return profile.bakeOffDay == today || profile.bakeOffDay == Self.previousKey(today) ? profile.bakeOffStreak : 0
    }

    @discardableResult
    func recordBakeOff(score: Int, day: BakeOffDay) -> BakeOffRecord {
        let before = Set(earnedAchievements)
        if profile.bakeOffDay != day.key {
            profile.bakeOffStreak = profile.bakeOffDay == Self.previousKey(day.key) ? profile.bakeOffStreak + 1 : 1
            profile.bakeOffDaysPlayed += 1
            profile.bakeOffDay = day.key
            profile.bakeOffTodayBest = 0
            profile.bakeOffAttemptsToday = 0
        }
        profile.bakeOffAttemptsToday += 1
        let isTodayBest = score > profile.bakeOffTodayBest
        let isAllTimeBest = score > profile.bakeOffAllTimeBest
        profile.bakeOffTodayBest = max(profile.bakeOffTodayBest, score)
        profile.bakeOffAllTimeBest = max(profile.bakeOffAllTimeBest, score)
        profile.sugarPoints += score / 50
        let gained = refreshAchievements(before: before)
        return BakeOffRecord(score: score, todayBest: profile.bakeOffTodayBest, allTimeBest: profile.bakeOffAllTimeBest,
                             isTodayBest: isTodayBest, isAllTimeBest: isAllTimeBest, streak: profile.bakeOffStreak, rosettes: gained)
    }

    static func previousKey(_ key: String) -> String {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "UTC") ?? TimeZone(secondsFromGMT: 0)!
        let parts = key.split(separator: "-").compactMap { Int($0) }
        guard parts.count == 3,
              let date = calendar.date(from: DateComponents(year: parts[0], month: parts[1], day: parts[2])),
              let prev = calendar.date(byAdding: .day, value: -1, to: date) else { return "" }
        return BakeOffDay.key(for: prev)
    }

    // MARK: Leaderboard

    func snapshot() -> LeaderboardSnapshot {
        let today = todayBakeOff
        let values: [LeaderboardCategory: Int] = [
            .sugarPoints: profile.sugarPoints,
            .bestRound: profile.bestRoundScore,
            .bakeOffToday: bakeOffBest(for: today),
            .bakeOffBest: profile.bakeOffAllTimeBest,
            .bakeOffStreak: liveBakeOffStreak,
            .bestMultipleTimes10: profile.bestMultipleTimes10,
            .longestChain: profile.bestCascadeChain,
            .ordersCompleted: profile.ordersCompleted
        ]
        return LeaderboardSnapshot(
            playerID: profile.playerID,
            playerName: profile.playerName,
            rankLevel: rankLevel,
            rankTitle: rankTitle,
            bakeOffDay: today.key,
            values: Dictionary(uniqueKeysWithValues: values.map { ($0.key.rawValue, $0.value) }),
            capturedAt: now()
        )
    }

    // MARK: Misc

    var welcomeSeen: Bool { profile.welcomeSeen }

    func markWelcomeSeen() {
        profile.welcomeSeen = true
        save()
    }

    func resetProgress() {
        records = []
        var fresh = PlayerProfile()
        fresh.welcomeSeen = true
        fresh.playerID = profile.playerID
        fresh.playerName = profile.playerName
        profile = fresh
        setOrders(OrderBook.fresh(using: &rng))
        save()
    }

    /// Tour helper for store screenshots: a believable seasoned player.
    func seedDemoProfile() {
        profile.playerName = "Candy Lark"
        profile.sugarPoints = 2_640
        profile.bestRoundScore = 4_820
        profile.bestMultipleTimes10 = 186
        profile.bestCascadeChain = 6
        profile.ordersCompleted = 27
        profile.roundsPlayed = 41
        profile.totalSpins = 820
        profile.stampedes = 12
        profile.cannonShots = 9
        profile.jamHits = 140
        profile.bakeOffDay = todayBakeOff.key
        profile.bakeOffTodayBest = 1_260
        profile.bakeOffAttemptsToday = 2
        profile.bakeOffAllTimeBest = 1_640
        profile.bakeOffDaysPlayed = 9
        profile.bakeOffStreak = 4
        profile.achievementsRaw = earnedAchievements.map(\.rawValue)
        save()
    }

    /// Test and tour helper: starts from a known state.
    func seed(coins: Int? = nil, meterFull: Bool = false, cannonReady: Bool = false, spins: Int? = nil, points: Int? = nil) {
        if let points { profile.sugarPoints = points }
        if let coins { profile.coins = coins }
        if meterFull { profile.meter = Self.meterMax }
        if cannonReady { profile.cannonCharge = Self.cannonMax }
        if let spins { profile.totalSpins = spins }
        save()
    }
}
