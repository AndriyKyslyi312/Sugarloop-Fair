import Foundation
import Combine

@MainActor
final class SettingsStore: ObservableObject {
    private let defaults: UserDefaults

    @Published var soundEnabled: Bool { didSet { defaults.set(soundEnabled, forKey: "sound") } }
    @Published var hapticsEnabled: Bool { didSet { defaults.set(hapticsEnabled, forKey: "haptics") } }
    @Published var quickSpin: Bool { didSet { defaults.set(quickSpin, forKey: "quick") } }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        soundEnabled = defaults.object(forKey: "sound") as? Bool ?? true
        hapticsEnabled = defaults.object(forKey: "haptics") as? Bool ?? true
        quickSpin = defaults.object(forKey: "quick") as? Bool ?? false
    }
}
